package March20;

import java.util.*;

class Marketplace {
    private Set<Product> productCatalog;
    private Map<String, Set<String>> orderHistory;
    private Map<String, Set<String>> customerWishlist;

    public Marketplace() {
        productCatalog = new HashSet<>();
        orderHistory = new HashMap<>();
        customerWishlist = new HashMap<>();
    }

    public void addProduct(String productID, String productName, double price, int quantityInStock) {
        Product product = new Product(productID, productName, price, quantityInStock);
        productCatalog.add(product);
    }

    public void removeProduct(String productID) {
        productCatalog.removeIf(product -> product.getProductID().equals(productID));
    }

    public void placeOrder(String customerID, Set<String> productIDs) {
        orderHistory.put(customerID, productIDs);
    }

    public void addToWishlist(String customerID, String productID) {
        customerWishlist.computeIfAbsent(customerID, k -> new HashSet<>()).add(productID);
    }

    public void removeFromWishlist(String customerID, String productID) {
        customerWishlist.getOrDefault(customerID, new HashSet<>()).remove(productID);
    }

    public List<Product> getProductsInStock() {
        return productCatalog.stream()
                .filter(product -> product.getQuantityInStock() > 0)
                .toList();
    }

    public List<String> getOrdersByCustomer(String customerID) {
        return orderHistory.getOrDefault(customerID, Collections.emptySet())
                .stream()
                .toList();
    }

    public List<String> getWishlistByCustomer(String customerID) {
        return customerWishlist.getOrDefault(customerID, Collections.emptySet())
                .stream()
                .toList();
    }

    public List<Product> searchProductsByName(String keyword) {
        return productCatalog.stream()
                .filter(product -> product.getProductName().contains(keyword))
                .toList();
    }

    static class Product {
        private String productID;
        private String productName;
        private double price;
        private int quantityInStock;

        public Product(String productID, String productName, double price, int quantityInStock) {
            this.productID = productID;
            this.productName = productName;
            this.price = price;
            this.quantityInStock = quantityInStock;
        }

        public String getProductID() {
            return productID;
        }

        public String getProductName() {
            return productName;
        }

        public double getPrice() {
            return price;
        }

        public int getQuantityInStock() {
            return quantityInStock;
        }
    }

    public static void main(String[] args) {
        Marketplace marketplace = new Marketplace();

        marketplace.addProduct("1", "laptop", 350000.0, 10);
        marketplace.addProduct("2", "mobile", 10000.0, 20);
        marketplace.addProduct("3", "headphones", 1500.0, 30);

        Set<String> order1 = new HashSet<>(Arrays.asList("1", "2"));
        marketplace.placeOrder("customer1", order1);

        Set<String> order2 = new HashSet<>(Collections.singletonList("3"));
        marketplace.placeOrder("customer2", order2);

        marketplace.addToWishlist("customer1", "3");
        marketplace.addToWishlist("customer2", "1");

        System.out.println("Products in stock:");
        List<Marketplace.Product> products = marketplace.getProductsInStock();
        for (Marketplace.Product product : products) {
            System.out.println(product.getProductName());
        }

        System.out.println("\nSearch results for mobile:");
        List<Marketplace.Product> searchResults = marketplace.searchProductsByName("mobile");
        for (Marketplace.Product product : searchResults) {
            System.out.println(product.getProductName());
        }

        System.out.println("\nOrders placed by customer1:");
        List<String> ordersByCustomer1 = marketplace.getOrdersByCustomer("customer1");
        System.out.println(ordersByCustomer1);

        System.out.println("\nWishlist of customer2:");
        List<String> wishlistByCustomer2 = marketplace.getWishlistByCustomer("customer2");
        System.out.println(wishlistByCustomer2);
    }
}
