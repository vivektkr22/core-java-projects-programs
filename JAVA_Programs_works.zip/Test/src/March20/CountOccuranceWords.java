package March20;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CountOccuranceWords {
    public static void main(String[] args) {
        String[] words = {"apple", "banana", "banana", "orange", "apple", "mango", "banana"};

               Map<String, Long> wordCounts = Arrays.stream(words)
                .flatMap(str -> Arrays.stream(str.split(" ")))
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        wordCounts.forEach((word, count) -> System.out.println(word + ": " + count));
    	
//    	String[] words = {"apple", "banana", "banana", "orange", "apple", "mango", "banana"};
    	
    }
}

