package March20;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

record Product(String name, Double price) {
	
}
public class ProductMain {

	public static void main(String[] args) {
		List<Product> list = new ArrayList<>();
		list.add(new Product("laptop",25000.0));
		list.add(new Product("mobile",15000.0));
		list.add(new Product("desktop",20000.0));
		list.add(new Product("Keyboad",500.0));
		
		List<Product> s = list.stream().filter(x -> x.price()>10000).collect(Collectors.toList());
		
		System.out.println(s);
		
	}

}
