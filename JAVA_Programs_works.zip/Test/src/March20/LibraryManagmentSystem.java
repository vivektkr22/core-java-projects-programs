package March20;

import java.util.*;

public class LibraryManagmentSystem {
    private static Map<String, Book> inventory = new HashMap<>();

    public static class Book {
        private String ISBN;
        private String title;
        private String author;
        private boolean available;

        public Book(String ISBN, String title, String author) {
            this.ISBN = ISBN;
            this.title = title;
            this.author = author;
            this.available = true;
        }

        public String getTitle() {
            return title;
        }

        public String getAuthor() {
            return author;
        }

        public boolean isAvailable() {
            return available;
        }

        public void setAvailable(boolean available) {
            this.available = available;
        }

        @Override
        public String toString() {
            return "Book{" +
                    "ISBN='" + ISBN + '\'' +
                    ", title='" + title + '\'' +
                    ", author='" + author + '\'' +
                    ", available=" + available +
                    '}';
        }
    }

    public static void addBook(String ISBN, String title, String author) {
        inventory.put(title, new Book(ISBN, title, author));
    }

    public static void borrowBook(String title) {
        Book book = inventory.get(title);
        if (book != null && book.isAvailable()) {
            book.setAvailable(false);
            System.out.println("Book " + title + " borrowed.");
        } else {
            System.out.println("Book " + title + " is not available for borrowing.");
        }
    }

    public static void returnBook(String title) {
        Book book = inventory.get(title);
        if (book != null && !book.isAvailable()) {
            book.setAvailable(true);
            System.out.println("Book " + title + " is returned.");
        } else {
            System.out.println("Book " + title + " is available.");
        }
    }

    public static List<String> searchBooksByAuthor(String author) {
        return inventory.values().stream()
                .filter(book -> book.getAuthor().equals(author))
                .map(Book::getTitle)
                .toList();
    }

    public static List<String> searchAvailableBooks() {
        return inventory.values().stream()
                .filter(Book::isAvailable)
                .map(Book::getTitle)
                .toList();
    }

    public static void main(String[] args) {

        addBook("1234567890", "Java Programming", "James Gosling");
        addBook("0987654321", "C", "Kanetkar");
        addBook("5432109876", "C++", "ABC");

        borrowBook("Java Programming");
        borrowBook("Python Basics");
        returnBook("Java Programming");

        System.out.println("Books by James Gosling: " + searchBooksByAuthor("James Gosling"));
        System.out.println("Books by ABC: " + searchBooksByAuthor("ABC"));

        System.out.println("Available books: " + searchAvailableBooks());
    }
}


