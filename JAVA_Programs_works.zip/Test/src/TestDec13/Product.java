package TestDec13;

public class Product {
private String productName;
private int productCode;
private int price;


public Product(String productName, int productCode, int price) {
	super();
	this.productName = productName;
	this.productCode = productCode;
	this.price = price;
}

public Product(Product p) {
	this.productName = p.productName;
	this.productCode = p.productCode;
	this.price = p.price;
}

public String getProductName() {
	return productName;
}

public int getProductCode() {
	return productCode;
}

public int getPrice() {
	return price;
}

public void setProductName(String productName) {
	this.productName = productName;
}

public void changePrice(int price) {
	this.price = price;
}

@Override
public String toString() {
	return "Product [productName=" + productName + ", productCode=" + productCode + ", price=" + price + "]";
}



}
