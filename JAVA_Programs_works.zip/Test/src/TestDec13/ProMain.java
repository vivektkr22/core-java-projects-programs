package TestDec13;

public class ProMain {

	public static void main(String[] args) {
		Product p = new Product("Laptop",1001,25000);
		Product p1 = new Product(p);
		
		System.out.println(p);
		System.out.println(p1);
		System.out.println("=========================================================");
		p1.changePrice(30000);
		System.out.println(p);
		System.out.println(p1);
	}

}
