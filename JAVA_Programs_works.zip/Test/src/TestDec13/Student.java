package TestDec13;

public class Student {
    private String studentName;
    private int studentId;
    private int marksInEng;
    private int marksInMath;
    private int marksInHis;
    
    public Student(String studentName, int studentId, int marksInEng, int marksInMath, int marksInHis ){
        this.studentName = studentName;
        this.studentId = studentId;
        this.marksInEng = marksInEng;
        this.marksInMath = marksInMath;
        this.marksInHis = marksInHis;
    }
    
    public int calculateAverage(){
        int avg = (marksInEng + marksInMath + marksInHis)/3;
        return avg;
    }

	public String getStudentName() {
		return studentName;
	}

	public int getStudentId() {
		return studentId;
	}

	@Override
	public String toString() {
		return "Student [studentName=" + studentName + ", studentId=" + studentId + ", marksInEng=" + marksInEng
				+ ", marksInMath=" + marksInMath + ", marksInHis=" + marksInHis + "]";
	}

    
    
    
}
