package TestDec13;

public class MainClass {
public static void main(String[] args) {
	Student st = new Student("Raj",101,80,90,75);
	Institute i = new Institute("NareshIt","Hyd",st);
	System.out.println(st);
	System.out.println("Student grade is: "+i.calGrade());
}
}
