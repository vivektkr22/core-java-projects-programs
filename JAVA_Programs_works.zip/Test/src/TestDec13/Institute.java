package TestDec13;

public class Institute {
  private String name;
  private String address;
  private Student student;


 Institute(String name, String address, Student student) {
	this.name = name;
	this.address = address;
	this.student = student;
}

public String calGrade() {
	String grade="";
	if(student.calculateAverage()>90) {
		grade = "A";
		
	}
	else if(student.calculateAverage()>80) {
		grade = "B";
		
	}
	else if(student.calculateAverage()>70) {
		grade = "C";
		
	}
	else if(student.calculateAverage()>60) {
		grade = "D";
		
	}
	else if(student.calculateAverage()>50) {
		grade = "E";
		
	}
	else if(student.calculateAverage()<50) {
		grade = "F";
		
	}
	return grade;
}

@Override
public String toString() {
	return "Institute [name=" + name + ", address=" + address + ", student=" + student + "]";
}




}

