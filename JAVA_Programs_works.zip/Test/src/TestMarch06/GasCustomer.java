package TestMarch06;

public class GasCustomer {
  private int customerId;
  private String customerName;
  private String cutomerAddress;
  private String cutomerPhone;
  
public GasCustomer(int customerId, String customerName, String cutomerAddress, String cutomerPhone) {
	super();
	this.customerId = customerId;
	this.customerName = customerName;
	this.cutomerAddress = cutomerAddress;
	this.cutomerPhone = cutomerPhone;
}

public int getCustomerId() {
	return customerId;
}

public String getCustomerName() {
	return customerName;
}

public String getCutomerAddress() {
	return cutomerAddress;
}

public String getCutomerPhone() {
	return cutomerPhone;
}

public void setCustomerId(int customerId) {
	this.customerId = customerId;
}

public void setCustomerName(String customerName) {
	this.customerName = customerName;
}

public void setCutomerAddress(String cutomerAddress) {
	this.cutomerAddress = cutomerAddress;
}

public void setCutomerPhone(String cutomerPhone) {
	this.cutomerPhone = cutomerPhone;
}


  
  
}
