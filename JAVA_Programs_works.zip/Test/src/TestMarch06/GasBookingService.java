package TestMarch06;

import java.util.ArrayList;

public class GasBookingService {
  private ArrayList<GasCustomer> al;

public GasBookingService() {
	al = new ArrayList<>();
}

public void bookGas(GasCustomer gc) {
	al.add((GasCustomer) gc);
}

public boolean isFirstTimeCustomer(GasCustomer cc) {
    for (GasCustomer gc : al) {
        if (gc.getCutomerPhone().equals(cc.getCutomerPhone())) {
            return true; 
        }
    }
    return false; 
}

public int calculateBill(GasCustomer gc) {
	if(isFirstTimeCustomer(gc)) {
		return 800;
	}
	else return 200;
}

public void printBill(Object gc) {
	System.out.println("Total bill is: "+ calculateBill((GasCustomer) gc));
}
  
}
