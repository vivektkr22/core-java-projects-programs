package TestMarch06;

import java.util.HashSet;
import java.util.Set;

public class SetExample {


	public static void main(String[] args) {
		Set<Integer>  set1 = new HashSet<>();
		set1.add(1);
		set1.add(2);
		set1.add(3);
		set1.add(4);
		set1.add(5);
		
		Set<Integer>  set2 = new HashSet<>();
		set2.add(3);
		set2.add(4);
		set2.add(5);
		set2.add(6);
		set2.add(7);
		
		Set<Integer> union = new HashSet<>();
		union.addAll(set1); union.addAll(set2);
		System.out.println(union);
		
		Set<Integer> intersection = new HashSet<>();
		for(Integer i : set1) {
			if(set1.contains(set2)) {
				intersection.add(i);
			}
		}
		System.out.println(intersection);
			
			
		Set<Integer> diff = new HashSet<>();
		for(Object obj : set2) {
			if(set2.contains(set1)){
				diff.add((Integer) obj);
			}
		}
		System.out.println(diff);
	}

}
