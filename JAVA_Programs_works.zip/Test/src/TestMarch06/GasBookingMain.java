package TestMarch06;

public class GasBookingMain {

	public static void main(String[] args) {
		GasBookingService gbs = new GasBookingService();
		GasCustomer g1 = new GasCustomer(1, "Virat", "hyd", "4646464");
		GasCustomer g2 = new GasCustomer(2, "Rohit", "Bang", "4646464");
		
		gbs.bookGas(g1);
		System.out.println(gbs.isFirstTimeCustomer(g2));
		gbs.bookGas(g2);
		
		
		
		System.out.println(gbs.calculateBill(g1));
		System.out.println("Second customer bill "+ gbs.calculateBill(g2));
		
		gbs.printBill(g2);
	}

}
