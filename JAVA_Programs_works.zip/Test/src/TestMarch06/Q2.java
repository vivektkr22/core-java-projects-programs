package TestMarch06;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashSet;
import java.util.Set;

public class Q2 {

	public static void main(String[] args) throws ClassNotFoundException {
		Set<Object> set = new HashSet<>();
		set.add(1);
		set.add(2);
		set.add(3);
		set.add(4);
		
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("data.txt"));
			oos.writeObject(set);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		System.out.println("Set Object Stored in file");
		
		
		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream("data.txt"));
			System.out.println("Reading the data in a file");
				System.out.println(ois.readObject());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}
