package Test;

class Test17 {
private double re, im;
public Test17(double re, double im) {
this.re = re;
this.im = im;
}
Test17(Test17 c) {
System.out.println("Copy constructor called");
re = c.re;
im = c.im;
}
public String toString() {
return "(" + re + " + " + im + ")";
}


class Main {
public static void main(String[] args) {
	Test17 c1 = new Test17(10, 15);
	Test17 c2 = new Test17(c1);
	Test17 c3 = c1;
System.out.println(c2);
}
}
}
