package Test;

public class Product {
	public int num;
	public void call(Product ref) {
	ref.num++;
	}
}
