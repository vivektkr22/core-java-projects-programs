package Test;


public class Book {
     private String title;
     private String author;
     private int price;
     
     public void setBookDetails(String title, String author, int price) {
    	 this.title = title;
    	 this.author = author;
    	 this.price = price;
     }
     public void calculateDiscountedPrice (int disPer) {
    	int dis = (price*disPer)/100;
    	 price = price - dis;
     }
     
     public String getBookInfo(){
    	 return "Title is: "+title+", Author is: "+author+", price is: "+price;
     }
     
	public static void main(String[] args) {
         Book b1 = new Book();
         b1.setBookDetails("C language", "Kanetkar", 250);
         b1.calculateDiscountedPrice(5);
         System.out.println(b1.getBookInfo());
	}

}

