package Test;

public class User {
	private String userName;
	private int age;
    private String status;
    
    
	public User(String userName, int age, String status) {
		super();
		this.userName = userName;
		this.age = age;
		this.status = status;
	}
	
	public void updateStatus(String status) {
		this.status = status;
	}
	
	public String displayProfileInfo() {
		return "User name: "+userName+", Age: "+age+", status:"+status;
	}
	

	public static void main(String[] args) {
		User a1 = new User("Raj",20,"Healthy");
		System.out.println(a1.displayProfileInfo());
		a1.updateStatus("Un-helathy");
		System.out.println(a1.displayProfileInfo());
        
	}

}
