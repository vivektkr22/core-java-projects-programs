package TestFab21;

public class CuncurrentThread implements Runnable{
	int s;
	int e;
	
	public CuncurrentThread(int s, int e) {
		super();
		this.s = s;
		this.e = e;
	}

	@Override
	public void run() {
			try {
				for(int i=s; i<=e; i++) {
					System.out.println(i+" ");
				Thread.sleep(1000);
				}
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		
	}

	public static void main(String[] args) {
	  CuncurrentThread p1 = new CuncurrentThread(1,10);
	  CuncurrentThread p2 = new CuncurrentThread(10,20);
	  
	  Thread t1 = new Thread(p1);
	  Thread t2 = new Thread (p2);
	  
	  t1.start(); t2.start();
	}

	

}
