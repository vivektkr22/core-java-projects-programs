package TestFab21;

public class DeadlockProgram implements Runnable{
	
	@Override
	public void run() {
		
			try {
				for(int i=0; i<10; i++) {
				Thread.currentThread().join();
				System.out.println("Deadlock");
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		
	}

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Main thread started");
		DeadlockProgram d = new DeadlockProgram();
		Thread t = new Thread(d);
		
		t.start();
		Thread.currentThread().join();
		System.out.println("main thread ended");
	}

	
}
