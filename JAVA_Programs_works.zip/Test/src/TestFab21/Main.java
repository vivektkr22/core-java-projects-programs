package TestFab21;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Welcome to the Education Institute App!");

        System.out.print("Enter the number of courses: ");
        int numCourses = sc.nextInt();
        Course[] courses = new Course[numCourses];

        for (int i = 0; i < numCourses; i++) {
            System.out.println("Enter details for Course " + (i + 1) + ":");
            System.out.print("Course Name: ");
            String courseName = sc.next();
            System.out.print("Course Fee: ");
            double courseFee = sc.nextDouble();

            courses[i] = new Course(i + 1, courseName, courseFee);
        }

        System.out.print("Enter the number of offers: ");
        int numOffers = sc.nextInt();
        Offer[] offers = new Offer[numOffers];

        for (int i = 0; i < numOffers; i++) {
            System.out.println("Enter details for Offer " + (i + 1) + ":");
            System.out.print("Offer Text: ");
            String offerText = sc.next();
            sc.nextLine(); 

            offers[i] = new Offer(offerText);
        }

        EducationInstitute institute = new EducationInstitute(courses, offers);

        Student virat = new Student("Virat", institute);
        Student rohit = new Student("Rohit", institute);

        Thread viratThread = new Thread(() -> {
            synchronized (institute) {
                virat.viewCoursesAndFees();
                virat.viewOffers();
                System.out.print("\nVirat, enter the course ID to enroll: ");
                int viratCourseId = sc.nextInt();
                virat.enrollInCourse(viratCourseId);
            }
        });

        Thread rohitThread = new Thread(() -> {
            synchronized (institute) {
                rohit.viewCoursesAndFees();
                rohit.viewOffers();
                System.out.print("\nRohit, enter the course ID to enroll: ");
                int rohitCourseId = sc.nextInt();
                rohit.enrollInCourse(rohitCourseId);
            }
        });

        viratThread.start();
        rohitThread.start();

        try {
            viratThread.join();
            rohitThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            sc.close();
        }
    }
}

