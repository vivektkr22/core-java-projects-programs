package TestFab21;

public class Test {
public static void main(String[] args) throws InterruptedException {
	Bank b = new Bank();
	Thread t1 = new Thread();
	t1.start();
	b.withdraw(500);
	t1.join();
	b.deposite(800);
}
}
