package TestFab21;

public class Bank extends Thread {
  private static int initialBalnce = 1000;



public void withdraw(int amt) throws InterruptedException {
	if(initialBalnce>amt) {
		Thread.sleep(1000);
		initialBalnce -=amt;
		System.out.println("After withdraw balance is: "+ initialBalnce);
	}
	else {
		System.out.println("can't withdraw");
	}
}

public void deposite(int amt) throws InterruptedException {
	Thread.sleep(1000);
	initialBalnce += amt;
	System.out.println("After deposite balance is: "+initialBalnce);
}
}
