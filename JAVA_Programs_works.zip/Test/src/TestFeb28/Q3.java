package TestFeb28;

import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

class Student1 implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer studentId;
    private String studentName;
    private Double studentFees;
    private Date dateOfAdmission;

    public Student1(Integer studentId, String studentName, Double studentFees, Date dateOfAdmission) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentFees = studentFees;
        this.dateOfAdmission = dateOfAdmission;
    }

    public static Student1 getStudentObject() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter Student ID: ");
        Integer studentId = scanner.nextInt();

        System.out.print("Enter Student Name: ");
        String studentName = scanner.next();

        System.out.print("Enter Student Fees: ");
        Double studentFees = scanner.nextDouble();

        // For simplicity, consider the date of admission as the current date
        Date dateOfAdmission = new Date();

        return new Student1(studentId, studentName, studentFees, dateOfAdmission);
    }

    @Override
    public String toString() {
        return "Student [studentId=" + studentId + ", studentName=" + studentName + ", studentFees=" + studentFees
                + ", dateOfAdmission=" + dateOfAdmission + "]";
    }
}


