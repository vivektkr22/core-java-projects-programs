package TestFeb28;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

class Duplicate {
    private List<Object> numberList;

    public Duplicate() {
        numberList = new ArrayList<>();
    }

    public Duplicate(List<Object> numberList) {
        this.numberList = numberList;
    }

    public List<Object> getNumberList() {
        return numberList;
    }

    public void setNumberList(List<Object> numberList) {
        this.numberList = numberList;
    }

    public void getDuplicate() {
        Set<Object> uniqueElements = new HashSet<>();
        Set<Object> duplicateElements = new HashSet<>();

        for (Object element : numberList) {
            if (!uniqueElements.add(element)) {
                // If the element is not added to the set, it's a duplicate
                duplicateElements.add(element);
            }
        }

        // Print or handle duplicate elements
        if (!duplicateElements.isEmpty()) {
            System.out.println("Duplicate elements: " + duplicateElements);
        } else {
            System.out.println("No duplicates found.");
        }
    }

    @Override
    public String toString() {
        return "Duplicate [numberList=" + numberList + "]";
    }
}

public class Q1 {
    public static void main(String[] args) {
        List<Object> l = new ArrayList<>();
        l.add(33);
        l.add(45);
        l.add(67);
        l.add(89);
        l.add(33);
        l.add(47);
        l.add(21);
        l.add(45);

        Duplicate d = new Duplicate(l);

        // Find and print duplicate elements
        d.getDuplicate();
    }
}

