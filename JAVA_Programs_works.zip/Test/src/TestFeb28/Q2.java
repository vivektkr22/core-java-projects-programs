package TestFeb28;

import java.util.ArrayList;
import java.util.List;

public class Q2 {

	public static void main(String[] args) {
		List<String> l = new ArrayList<>();
		l.add("red");
		l.add("green");
		l.add("orange");
		l.add("white");
		l.add("black");
		System.out.println(l);
		l.remove("orange");
		System.out.println("After removing third element:");
		System.out.println(l);
		
	}

}
