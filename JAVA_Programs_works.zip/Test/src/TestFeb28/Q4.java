package TestFeb28;

import java.util.ArrayList;
import java.util.List;

class Student{
	private String name;
	private int grade;
	
	public Student(String name, int grade) {
		super();
		this.name = name;
		this.grade = grade;
	}
	

	public String getName() {
		return name;
	}


	public int getGrade() {
		return grade;
	}

	@Override
	public String toString() {
		return "Student [name=" + name + ", grade=" + grade + "]";
	}
	
	
}

public class Q4 {

	public static void main(String[] args) {
		List<Object> list = new ArrayList<>();
		Student s = null;
		list.add(new Student("John",85));
		list.add(new Student("Alice",92));
		list.add(new Student("Bob",88));
		list.add(new Student("Charlie",85));
		list.add(new Student("Emily",90));
		System.out.println("Student with the highest grade: ");
		int max = 0;
		for(Object o : List) {
			
		}
	}

}
