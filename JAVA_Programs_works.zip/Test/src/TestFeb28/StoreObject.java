package TestFeb28;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class StoreObject {
    public static void main(String[] args) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("Student.txt"))) {
            List<Student1> studentList = new ArrayList<>();

            // Reading Student objects with user choice
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the number of students: ");
            int numberOfStudents = scanner.nextInt();

            for (int i = 0; i < numberOfStudents; i++) {
                Student1 student = Student1.getStudentObject();
                studentList.add(student);
            }

            // Writing the Student objects to file
            oos.writeObject(studentList);
            System.out.println("Serialization completed");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
