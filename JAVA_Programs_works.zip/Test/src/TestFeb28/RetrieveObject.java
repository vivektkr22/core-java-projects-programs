package TestFeb28;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.List;

class RetrieveObject {
    public static void main(String[] args) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("Student.txt"))) {
            // Reading Student objects from file
            List<Student1> retrievedStudentList =  (List<Student1>) ois.readObject();

            // Printing Student information data
            for (Student1 student : retrievedStudentList) {
                System.out.println(student);
            }

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}