package TestDec20;

public class Electronics extends Product{
  private String brand;

public Electronics(String name, double price, String brand) {
	super(name, price);
	this.brand = brand;
}
  
  public void displayInfo() {
	  System.out.println("Product brand: "+brand);
  }

@Override
public String toString() {
	return "Electronics [brand=" + brand + ", name=" + name + ", price=" + price + "]";
}
  
}


