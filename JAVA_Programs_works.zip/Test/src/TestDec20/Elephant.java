package TestDec20;

public class Elephant extends Animal {
  private float tuskLength;

public Elephant(String name, int age, float tuskLength) {
	super(name, age);
	this.tuskLength = tuskLength;
}
  
  public void makeSound() {
	  System.out.println("The elephant trumpets.");
  }
  
  public void tuskLength() {
	  System.out.println("Tusk length: "+tuskLength);
  }

@Override
public String toString() {
	return "Elephant [tuskLength=" + tuskLength + ", toString()=" + super.toString() + "]";
}
  
  
}
