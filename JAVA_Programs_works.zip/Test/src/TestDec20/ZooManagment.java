package TestDec20;

public class ZooManagment {

	public static void main(String[] args) {
		Lion l = new Lion("Lion", 8, 3);
		Elephant e = new Elephant("Elephant",10,10);
		
		System.out.println(l);
		l.makeSound();
		System.out.println(e);
		e.makeSound();
	}

}
