package TestDec20;

public class OnlineShopping {
  public static void main(String[] args) {
	Electronics e = new Electronics("Mobile",15000,"Realme");
	Clothing c = new Clothing("Shirt",500,"XL");
	
	System.out.println(e);
	System.out.println("Total cost pf product is: "+e.calculateTotalCost(2));
	
	System.out.println(c);
	System.out.println("Total cost of products is: "+c.calculateTotalCost(3));
}
}
