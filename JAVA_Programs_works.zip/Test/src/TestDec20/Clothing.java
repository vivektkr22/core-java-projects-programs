package TestDec20;

public class Clothing extends Product {
    private String size;

	public Clothing(String name, double price, String size) {
		super(name, price);
		this.size = size;
	}
    
    public void displayInfo() {
    	System.out.println("Size: "+size);
    }

	@Override
	public String toString() {
		return "Clothing [size=" + size + ", name=" + name + ", price=" + price + "]";
	}
    
}
