package TestDec20;

public class Product {
   protected String name;
   protected double price;
   
   
public Product(String name, double price) {
	super();
	this.name = name;
	this.price = price;
}
 
public void displayInfo() {
	System.out.println("Product name: "+name);
	System.out.println("Price: "+price);
}

public double calculateTotalCost(int qty) {
	return qty*price;
}

@Override
public String toString() {
	return "Product [name=" + name + ", price=" + price + "]";
}  

}
