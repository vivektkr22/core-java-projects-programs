package TestDec20;

public class Lion extends Animal {
   private int maneLength;

public Lion(String name, int age, int maneLength) {
	super(name, age);
	this.maneLength = maneLength;
}
   
public void makeSound() {
	System.out.println("The lion roars loudly.");
}
public void maneLength() {
	System.out.println("Mane length: "+maneLength);
}

@Override
public String toString() {
	return "Lion [maneLength=" + maneLength + ", toString()=" + super.toString() + "]";
}


}
