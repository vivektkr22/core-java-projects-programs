package TestJan24;

import java.util.function.Supplier;

public class MyProgram {

	public static void main(String[] args) {
		Supplier<Double> sup = () -> Math.random();
	       System.out.println(sup.get());
	}

}
