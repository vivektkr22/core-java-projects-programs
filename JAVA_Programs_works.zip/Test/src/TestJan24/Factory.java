package TestJan24;

 abstract class Factory {
   String brand;
   String model;
   
   abstract void displayInfo();
}

 interface Engine{
	void startEngine();
}
 
 interface SaftyFeatures{
	 void activeAirBags();
 }
 
 class Car extends Factory implements Engine,SaftyFeatures{
	 int numDoors;
	 String fuelType;
	public Car(int numDoors, String fuelType) {
		super();
		this.numDoors = numDoors;
		this.fuelType = fuelType;
	}
	@Override
	public void activeAirBags() {
		System.out.println("Air Bag activated");
	}
	@Override
	public void startEngine() {
		System.out.println("Engine started");
	}
	@Override
	void displayInfo() {
		System.out.println("Number of doors: "+numDoors+"\n Fuel Type: "+fuelType);
	}
	 
	public class Factory{
		public static void main(String[] args) {
			Car bmw = new Car(4,"Petrol");
			bmw.displayInfo();
			bmw.startEngine();
			bmw.activeAirBags();
		}
	}
 }
