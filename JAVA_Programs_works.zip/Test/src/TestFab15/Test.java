package TestFab15;

public class Test {

	public static void main(String[] args) {
		Customer c1 = new Customer("Rohan",3);
		Customer c2 = new Customer("Virat",1);
		Customer c3 = new Customer("ROhit",6);
		
		MovieTickets m1 = new MovieTickets(c1);
		MovieTickets m2 = new MovieTickets(c2);
		MovieTickets m3 = new MovieTickets(c3);
		
		Thread t1 = new Thread(m1);
		Thread t2 = new Thread(m2);
		Thread t3 = new Thread(m3);
		
		t1.start(); t2.start(); t3.start();
	}

}
