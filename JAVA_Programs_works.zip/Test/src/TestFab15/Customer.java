package TestFab15;

public class Customer implements Runnable {
     String customerName;
     int desireTickets;
     
	public Customer(String customerName, int desireTickets) {
		super();
		this.customerName = customerName;
		this.desireTickets = desireTickets;
	}

	public String getCustomerName() {
		return customerName;
	}

	public int getDesireTickets() {
		return desireTickets;
	}

	@Override
	public void run() {
		System.out.println(customerName+" wants "+desireTickets+" tickets");
	}
    
     
}
