package TestFab15;

public class MovieTickets implements Runnable {
   
	int ticketAvailable = 5;
	Customer customer;
	
	
	public MovieTickets(Customer customer) {
		super();
		this.customer = customer;
	}

	@Override
	public void run() {
		String cutomerName=customer.getCustomerName();
		if(ticketAvailable>customer.desireTickets) {
			System.out.println("Movie tickets are alloted to "+cutomerName);
		}
		else {
			System.out.println("movie tickets are not available");
		}
		
	}
	
	public void movieTickets(int t) {
		
	}
	

}
