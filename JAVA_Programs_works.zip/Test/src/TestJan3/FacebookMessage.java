package TestJan3;

public class FacebookMessage extends SocialMediaMessage {
   String imageAttachment ;

public FacebookMessage(String imageAttachment) {
	super();
	this.imageAttachment = imageAttachment;
}

public String getImageAttachment() {
	return imageAttachment;
}

   @Override
	void encrypt() {
		System.out.println("Facebook encrypted message sended");
	}
    
    @Override
    	void decrypt() {
    	System.out.println("Face decrypted message sended");
    	}
    
    @Override
    	void displaySenderInfo() {
    		System.out.println("Imgage attachment: "+imageAttachment);
    	}
   
}
