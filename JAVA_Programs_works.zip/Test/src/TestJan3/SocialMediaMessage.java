package TestJan3;

public abstract class SocialMediaMessage {
     String sender;
     String content;
     
    
	abstract void encrypt();
     abstract void decrypt();
     
     abstract void displaySenderInfo();
     
     public String displayMessageInfo(){
    	 return "a message sended";
     }
}
