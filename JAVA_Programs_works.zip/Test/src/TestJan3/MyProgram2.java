package TestJan3;

public class MyProgram2 {

	public static void main(String[] args) {
		CurrentAccount c = new CurrentAccount(5);
		c.deposite();
		c.withdraw();
		c.displayAccountInfo();
		System.out.println("-----------------------------");
		SavingAccount s = new SavingAccount(7);
		s.deposite();
		s.withdraw();
		s.displayAccountInfo();
	}

}
