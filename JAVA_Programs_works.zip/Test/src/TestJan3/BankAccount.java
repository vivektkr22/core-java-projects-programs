package TestJan3;

public abstract class BankAccount {
	String accountHolder="JOhn";
	double balance=1000;
	
	abstract void deposite();
	abstract void withdraw();
	abstract void displayAccountInfo();
	
	  public void displayBalance() {
		  System.out.println(balance);
	  }
}
