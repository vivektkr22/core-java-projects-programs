package TestJan3;

public class SavingAccount extends BankAccount {
      double intrestRate;

	public SavingAccount(double intrestRate) {
		super();
		this.intrestRate = intrestRate;
	}
      
	@Override
	void deposite() {
		System.out.println("dispoite: "+1200);
	}
	@Override
	void withdraw() {
	   System.out.println("withdraw: "+1000);
	}
	
	@Override
	void displayAccountInfo() {
		System.out.println("Intrest rate: "+intrestRate+"\nAccount holder name: "+accountHolder);
	}
}
