package TestJan3;

public class MyProgram {

	public static void main(String[] args) {
		WhatsAppMessage w = new WhatsAppMessage();
		w.encrypt();
		w.decrypt();
		w.displaySenderInfo();
		System.out.println("------------------------------------");
		FacebookMessage f = new FacebookMessage("HDImage");
		f.encrypt();
		f.decrypt();
		f.displaySenderInfo();
	}

}
