package TestJan3;

public class CurrentAccount extends BankAccount {
	double intrestRate;
	
	
	public CurrentAccount(double intrestRate) {
		super();
		this.intrestRate = intrestRate;
	}
	@Override
	void deposite() {
		System.out.println("disposite: "+1100);
	}
	@Override
	void withdraw() {
	    System.out.println("withdraw: "+900);
	}
	
	@Override
	void displayAccountInfo() {
		System.out.println("Intrest rate: "+intrestRate+"\nAccount holder name: "+accountHolder);
	}
}
