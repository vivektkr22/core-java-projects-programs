package TestJan3;

public class WhatsAppMessage extends SocialMediaMessage {
    
        @Override
        void encrypt() {
        	System.out.println("Whatsapp encrypted message sended");
        }
        
        @Override
        void decrypt() {
          System.out.println("whtsapp decrypted message sended");
        }
        
        @Override
        void displaySenderInfo() {
         System.out.println("Sender: John "+"\n"+"Content: I am whatsapp");
        }
}
