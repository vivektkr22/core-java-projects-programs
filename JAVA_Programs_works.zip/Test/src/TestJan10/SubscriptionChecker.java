package TestJan10;

import java.util.function.Predicate;
import java.util.function.Supplier;

public class SubscriptionChecker {
	
	public static void main(String [] args) {
		Supplier<User> s = () ->  new User("john",true);
	    
        User u = new User("john",true);
        System.out.println("USer information :"+u);
        System.out.println("-----------------------------");
        Predicate<User> p = (isTrue) -> true;
        
        System.out.println("Is subscribed: "+u.isSubscribed);
   
	}
}
