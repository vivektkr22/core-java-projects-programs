package TestJan10;

public class ShoppingCart {
    double totalCost;
    
    public void addProduct(Product product) {
    	totalCost = product.quantity*product.price;
    }
    
    public void viewTotalCost()
    {
    	System.out.println("Total cost of product : "+totalCost);
    }
    
}
