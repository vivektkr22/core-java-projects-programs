package TestJan10;

public class User {
   String userName;
   boolean isSubscribed;
   
public User(String userName, boolean isSubscribed) {
	super();
	this.userName = userName;
	this.isSubscribed = isSubscribed;
}

@Override
public String toString() {
	return "User [userName=" + userName + ", isSubscribed=" + isSubscribed + "]";
}
   

}
