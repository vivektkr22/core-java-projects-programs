package TestJan10;

public class PayPalPayment implements PaymentMethod{
   
	public void processPayment(double amount) {
		if(amount>0) {
			System.out.println("payment successfull");
		}
		else {
			System.out.println("payment unsucessfull");
		}
	}
}
