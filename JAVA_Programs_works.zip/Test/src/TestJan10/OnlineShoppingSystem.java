package TestJan10;

public class OnlineShoppingSystem {

	public static void main(String[] args) {
		Product p = new Product("laptop",25000,1);
		
		System.out.println(p);
		
		CreditCardPayment c = new CreditCardPayment();
		c.processPayment(25000);
		PayPalPayment pp = new PayPalPayment();
	    pp.processPayment(25000);	
	    
	    ShoppingCart s = new ShoppingCart();
	    s.addProduct(p);
	    s.viewTotalCost();
	}

}
