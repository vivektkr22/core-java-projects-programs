package TestJan10;

public interface PaymentMethod {
     void processPayment(double amount);
}
