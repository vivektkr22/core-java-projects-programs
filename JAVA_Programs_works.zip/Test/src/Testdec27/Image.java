package Testdec27;

public class Image extends Media {
    private String resolution;

	public Image(String title, String resolution) {
		super(title, 0);
		this.resolution = resolution;
	}

	@Override
	public Image getDetails() {
		super.getDetails();
		System.out.println("Resolution: "+resolution);
		return this;
	}	
}
