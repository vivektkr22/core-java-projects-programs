package Testdec27;

public class MultimediaSystem {
	public static void main(String[] args) {
		
     Image i = new Image("Virat","500x600");
         i.getDetails();
         System.out.println("===========================");
     Video v = new Video("Harry Potter",1500,"mp4");
         v.getDetails();
	} 
}
