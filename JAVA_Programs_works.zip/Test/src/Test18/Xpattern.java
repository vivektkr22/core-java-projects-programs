package Test18;
import java.util.Scanner;
public class Xpattern {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number: ");
        int n = sc.nextInt();
        
        String s = PrintXPattern.getPattern(n);
        System.out.println(s);
        sc.close();

	}

}
