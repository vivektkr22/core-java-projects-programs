package Test18;

public class TestPrimeChecker {
    public static String getPrime(int n) {
        String str = "";
        int count = 0;
        int i = 2;
        while (count < n) {
            boolean isPrime = true;
            for (int c = 2; c * c <= i; c++) {
                if (i % c == 0) {
                    isPrime = false;
                    break;
                }
            }
            if (isPrime) {
                str = str + i + " ";
                count++;
            }
            i++;
        }
        return str;
    }
}
