package Test18;

public class PrintXPattern {
    public static String getPattern(int n) {
        String str = "";
         n = n*2-1;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == j || j == n-i-1) {
                    str += "*";
                } else {
                    str += " ";
                }
            }
            str += "\n";
        }
        return str;
    }
}
