package Fab7;

import java.io.Serializable;
import java.util.Scanner;


public class Student implements Serializable {
  private String studentName;
  private int studentID;
  private transient String  emailID;
  private String address;
  
public Student(String studentName, int studentID, String emailID, String address) {
	super();
	this.studentName = studentName;
	this.studentID = studentID;
	this.emailID = emailID;
	this.address = address;
}

public static Student getStudentObject() {
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter Student id: ");
	 Integer id = sc.nextInt();
	 System.out.print("Enter student name: ");
	 String name = sc.nextLine();
	 name = sc.nextLine();
	 System.out.print("Enter student emailID: ");
	 String email = sc.nextLine();
	 email = sc.nextLine();
	 System.out.print("Enter student address: ");
	 String address = sc.nextLine();
	 
	 
	 return new Student(name,id,email,address);
}

public String getStudentName() {
	return studentName;
}

public int getStudentID() {
	return studentID;
}

public String getEmailID() {
	return emailID;
}

public String getAddress() {
	return address;
}

public void setStudentName(String studentName) {
	this.studentName = studentName;
}

public void setStudentID(int studentID) {
	this.studentID = studentID;
}

public void setEmailID(String emailID) {
	this.emailID = emailID;
}

public void setAddress(String address) {
	this.address = address;
}

@Override
public String toString() {
	return "Student [studentName=" + studentName + ", studentID=" + studentID + ", address=" + address + "]";
}


  
}
