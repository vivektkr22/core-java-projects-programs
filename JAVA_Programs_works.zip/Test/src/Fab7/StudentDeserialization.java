package Fab7;

import java.io.FileInputStream;
import java.io.ObjectInputStream;



public class StudentDeserialization {

		 public static void main(String[] args) throws Exception {
				var fin = new FileInputStream("c:\\Batch27\\Student.txt");
				var ois = new ObjectInputStream(fin);
				
				try(fin ; ois){
					Student stu = null;
					while((stu = (Student)ois.readObject())!=null) {
						System.out.println(stu);
					}
				}
				catch(Exception e) {
					System.err.println("End of file reached:!!!");
				}
	}

}
