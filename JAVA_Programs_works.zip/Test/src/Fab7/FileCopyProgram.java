package Fab7;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileCopyProgram {

	public static void main(String s[]) throws IOException
    {  
	  

	   var fin = new FileInputStream("C:\\Batch27\\abc.txt");
	   
	   var fout = new FileOutputStream("C:\\Batch27\\abc2.txt");

	   try(fin; fout)
		 {
        while(true)
		 {
		     int i = fin.read();
			 if(i==-1) break;
			 System.out.print((char)i);
			 fout.write((byte)i);
		 }      
		 }
		 catch(IOException e)
		 {
			 e.printStackTrace();
		 }
    }
}
