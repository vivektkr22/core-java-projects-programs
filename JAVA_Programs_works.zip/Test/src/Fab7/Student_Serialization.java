package Fab7;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class Student_Serialization {

	public static void main(String[] args) throws IOException {
		var fout = new FileOutputStream("c:\\Batch27\\Student.txt");
		var oos = new ObjectOutputStream(fout);
		var sc = new Scanner(System.in);
		try(fout ; oos; sc){
			System.out.print("How many Student object you want to store: ");
		    Integer numberOfObj = sc.nextInt();
		    
		    for(int i=0; i<numberOfObj; i++) {
		    	Student obj = Student.getStudentObject();
		    	oos.writeObject(obj);
		    }
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		System.out.print("Student data stored successfully");
	}

}
