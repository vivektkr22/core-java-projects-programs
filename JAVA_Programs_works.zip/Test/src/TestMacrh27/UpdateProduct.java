package TestMacrh27;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Scanner;

public class UpdateProduct {
	public static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    public static final String USERNAME = "naresh";
    public static final String PASSWORD = "root";
    static Scanner sc = new Scanner(System.in);
    
      public static void main(String[] args) {
    	  try (Connection con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);){
    		  
    	  }
	}
}
