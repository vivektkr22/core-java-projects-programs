package March13;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

class Property {
	private Integer propertyId;
    private String propertyName;
    

    public Property(Integer propertyId, String propertyName) {
    	this.propertyId = propertyId;
        this.propertyName = propertyName;
    }

    public Integer getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(Integer propertyId) {
		this.propertyId = propertyId;
	}

	public String getPropertyName() {
        return propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }
 
}

class ConfigurationManagementSystem {
    Map<Integer, String> hm;

    ConfigurationManagementSystem() {
        this.hm = new HashMap<>();
    }

    public void addProperty(Property property) {
        hm.put(property.getPropertyId(), property.getPropertyName());
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder("ConfigurationManagementSystem [Property Data:\n");

        for (Entry<Integer, String> entry : hm.entrySet()) {
            result.append("Name: ").append(entry.getKey()).append("\n");
        }

        result.append("]");
        return result.toString();
    }
}

public class ConfigurationManagementSystemMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ConfigurationManagementSystem cms = new ConfigurationManagementSystem();

        while (true) {
            System.out.println("Options:\n1. Add Property\n2. Display Data\n3. Exit");
            System.out.print("Enter your choice: ");

            if (sc.hasNextInt()) {
                int choice = sc.nextInt();
                sc.nextLine(); 

                switch (choice) {
                    case 1: {
                    	System.out.print("Enter the property id: ");
                    	Integer id = sc.nextInt();
                        System.out.print("Enter the Property name: ");
                        String name = sc.next();
                        
                        Property property = new Property(id, name);
                        cms.addProperty(property);
                        break;
                    }
                    case 2: {
                        System.out.println(cms);
                        break;
                    }
                    case 3: {
                        System.out.println("Thank you for visiting us, Goodbye!");
                        System.exit(0);
                    }
                    default:
                        System.out.println("Invalid choice. Please select a valid option.");
                }
            } 
            else {
                System.out.println("Invalid input. Please enter a valid integer choice.");
                sc.next(); 
            }
        }
    }
}

