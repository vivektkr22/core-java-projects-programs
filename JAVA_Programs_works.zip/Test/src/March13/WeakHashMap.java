package March13;

import java.util.HashMap;
import java.util.Map;

public class WeakHashMap {
    public static void main(String[] args) {
  
        System.out.println("Using HashMap:");
        demoHashMap();

    
        System.out.println("\nUsing WeakHashMap:");
        demoWeakHashMap();
    }

    private static void demoHashMap() {
        Map hashMap = new HashMap();

        Object key = new String("HashMapKey");
        hashMap.put(key, "virat");

        System.out.println("Before setting key to null: " + hashMap);

        key = null;

    
        System.gc();

        System.out.println("After setting key to null: " + hashMap);
    }

    private static void demoWeakHashMap() {
        WeakHashMap weakHashMap = new WeakHashMap();

        Object key = new String("WeakHashMapKey");
        weakHashMap.put(key, "rohit");

        System.out.println("Before setting key to null: " + weakHashMap);

       
        key = null;

      
        System.gc();

        System.out.println("After setting key to null: " + weakHashMap);
    }

	private void put(Object key, String string) {
		// TODO Auto-generated method stub
		
	}
}

