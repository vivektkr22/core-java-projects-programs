package March13;

import java.util.HashMap;
import java.util.Scanner;

public class StudentManagementSystemMain {
    private static HashMap<String, Integer> studentDatabase = new HashMap<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Welcome to the Student Database!\n");

        while (true) {
            displayMenu();
            int choice = getChoice();

            switch (choice) {
                case 1:
                    addStudent();
                    break;
                case 2:
                    viewStudentInformation();
                    break;
                case 3:
                    System.out.println("Exiting program. Goodbye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.\n");
            }
        }
    }

    private static void displayMenu() {
        System.out.println("1. Add a student\n2. View student information\n3. Exit");
        System.out.print("Enter your choice: ");
    }

    private static int getChoice() {
        int choice = 0;
        try {
            choice = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
       
        }
        return choice;
    }

    private static void addStudent() {
        System.out.print("\nEnter student name: ");
        String name = scanner.nextLine();

        System.out.print("Enter student grade: ");
        int grade = 0;
        try {
            grade = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid grade. Please enter a valid integer.\n");
            return;
        }

        studentDatabase.put(name, grade);
        System.out.println("Student added successfully!\n");
    }

    private static void viewStudentInformation() {
        System.out.print("\nEnter student name to view information: ");
        String name = scanner.nextLine();

        if (studentDatabase.containsKey(name)) {
            int grade = studentDatabase.get(name);
            System.out.println("Student: " + name + ", Grade: " + grade + "\n");
        } else {
            System.out.println("Student not found in the database.\n");
        }
    }
}
