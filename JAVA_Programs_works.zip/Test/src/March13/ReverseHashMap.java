package March13;

import java.util.*;

public class ReverseHashMap {

    public static void main(String[] args) {
      
        HashMap<Integer, String> inputMap = new HashMap<>();
        inputMap.put(100, "Amit");
        inputMap.put(101, "Vijay");
        inputMap.put(102, "Rahul");

   
        List<Map.Entry<Integer, String>> entryList = new ArrayList<>(inputMap.entrySet());
        Collections.sort(entryList, Collections.reverseOrder(Map.Entry.comparingByKey()));

        for (Map.Entry<Integer, String> entry : entryList) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
    }
}

