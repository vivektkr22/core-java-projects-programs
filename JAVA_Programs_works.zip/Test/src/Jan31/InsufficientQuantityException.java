package Jan31;

public class InsufficientQuantityException extends RuntimeException {
    InsufficientQuantityException(){
    	
    }
    InsufficientQuantityException(String message){
    	super(message);
    }
}
