package Jan31;

public class Main {

	public static void main(String[] args) {
		Product p = new Product("Laptop",10,2500);
		p.processOrder(11, -2500);
	}

}
