package Jan31;

public class Product {
   private String name;
   private int availableQuantity;
   private double price;
   
public Product(String name, int availableQuantity, double price) {
	super();
	this.name = name;
	this.availableQuantity = availableQuantity;
	this.price = price;
}

public void processOrder(int qty, double amt) {
	try {
		if(qty*amt<0) {
			throw new InvalidAmountException("Enter valid amoumt");
		}
		else {
			System.out.println("Order successfull");
			this.availableQuantity -= qty;
		}
		try {
			if(qty>availableQuantity) {
				throw new InsufficientQuantityException("Insufficient quantity");
			}
			else {
				System.out.println("Order placed for "+qty+" units of laptop");
				System.out.println("remaining quantity: "+availableQuantity);
			}
		}
		catch(InsufficientQuantityException e) {
			System.out.println(e);
		}
	}
	catch(InvalidAmountException e) {
		System.out.println(e);
	}
	
}
   
}
