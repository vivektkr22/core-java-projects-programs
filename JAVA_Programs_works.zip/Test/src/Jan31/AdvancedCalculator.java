package Jan31;

public class AdvancedCalculator {
    public static void performCalculation(String input) {
    	try {
    		if(input == null) {
    			throw new NullPointerException();
    		}
    		else {
    			int c = Integer.parseInt(input);
    			System.out.println(c/2);
    		}
    	}
    	catch(NullPointerException | ArithmeticException e) {
    		System.out.println("Handled nullPiinter exception or arithmetic exception");
    	}
		
    }
}
