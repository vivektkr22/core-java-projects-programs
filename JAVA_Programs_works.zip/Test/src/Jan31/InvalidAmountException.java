package Jan31;

public class InvalidAmountException extends Exception {
   InvalidAmountException(){
	   
   }
   InvalidAmountException(String message){
	   super(message);
   }
}
