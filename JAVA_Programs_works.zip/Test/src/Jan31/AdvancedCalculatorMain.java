package Jan31;

public class AdvancedCalculatorMain {

	public static void main(String[] args) {
		AdvancedCalculator a = new AdvancedCalculator();
	    a.performCalculation("123");
	}

}
