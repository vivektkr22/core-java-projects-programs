package Fab22;

import java.util.Scanner;

public class ChangeCaseOfCharactor {
	public static String caseChange(String str) {
		String s ="";
	    for(int i=0; i<str.length(); i++) {
	    	char ch = str.charAt(i);
	    	if(ch>='a' && ch<='z') {
	    		ch-=32;
	    		s+=ch;
	    	}
	    	else if(ch>='A' && ch<='Z') {
	    		ch+=32;
	    		s+=ch;
	    	}
	    	else {
	    		s+=ch;
	    	}
	    }
	    return s;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a String: ");
		String s = sc.nextLine();
		String str = caseChange(s);
		System.out.print("Changed String is: "+str);
		
		sc.close();
	}

}
