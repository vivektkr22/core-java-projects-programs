/**
 * 
 */
/**
 * 
 */
module LogicalProgramming1 {
}