package March;
// WAP to reverse a string on the baases of words.
public class ReverseStringWords {
	
	public static String reverseWords(String s) {
		StringBuilder sb  =  new StringBuilder();

		String str[] = s.split(" ");
		
		for(int i=str.length-1; i>=0; i--) {
			sb.append(str[i]+" ");
		}
		return sb.toString().trim();
	}

	public static void main(String[] args) {
		String s = "java programming      is good for career";
		
		System.out.println("orignal string is:"+s+".");
		System.out.println("Reverse stirng is:"+reverseWords(s)+".");
		
		

	}

}
