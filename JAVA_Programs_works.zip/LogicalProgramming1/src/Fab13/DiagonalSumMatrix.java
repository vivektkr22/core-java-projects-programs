//package Fab13;
//
//import java.util.Scanner;
//
//public class DiagonalSumMatrix {
//	
//	public static void diagonalSum(int arr[][], int n) {
//		int s=0;
//		for(int i=0; i<n; i++) {
//			for(int j=0; j<n; j++) {
//				if(i==j && i+j==)
//			}
//		}
//	}
//
//	public static void main(String[] args) {
//		Scanner sc = new Scanner(System.in);
//		System.out.print("Enter the length of n*n matrix: ");
//		int n = sc.nextInt();
//		
//		int arr[][] = new int[n][n];
//		
//		System.out.print("Enter the elements into a matrix: ");
//		for(int i=0; i<n; i++) {
//			for(int j=0; j<n; j++) {
//				arr[i][j] = sc.nextInt();
//			}
//		}
//		
//		diagonalSum(arr,n);
//	}
//
//}
