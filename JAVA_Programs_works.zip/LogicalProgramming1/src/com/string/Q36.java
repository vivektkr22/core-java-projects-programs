package com.string;

import java.util.Scanner;

public class Q36 {

	public static void maxWordInString(String str) {
		String s[] = str.split(" ");
		int maxLen = 0; String maxWord="";
		for(int i=0; i<s.length; i++) {
			if(s[i].length()>maxLen) {
				maxLen = s[i].length();
				maxWord=s[i];
			}
		}
		System.out.println("Maximum length word is: "+maxWord);
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the sentence: ");
		String str = sc.nextLine();
		
		maxWordInString(str);
		sc.close();
	}

}
