package com.string;

import java.util.Scanner;

/* WAP to accept a string and display the potential value of stirng.
input: Apple is good.  1+16+16+12+5   9+19  7+15+15+4
Output: 50 + 28 + 41
	*/
public class Q44 {	
	
	public static void displayPotentialVlaue(String s) {
		String str = s.toLowerCase();
		int value = 0;
		for(int i=0; i<str.length(); i++) {
			if(str.charAt(i)>=97 && str.charAt(i)<=122) {
				value+= (int) (str.charAt(i)-96);
				System.out.println(value);
			}
		}
		System.out.println("Potential Value is: "+value);
	}
	

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string: ");
		String s = sc.nextLine();
		
		displayPotentialVlaue(s);
		sc.close();
	}

}
