package com.string;
/* WAP to accept 10 diffrent names and write them in ascending order. */
import java.util.Scanner;

public class Q32 {
	
	public static void ascendingOrder(String arr[]) {
	   for(int i=0; i<arr.length; i++) {
		   for(int j=i+1; j<arr.length; j++) {
			   if(arr[i]>arr[j]){
				   
			   }
		   }
	   }
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the length of an array: ");
		int n = sc.nextInt();
		String arr[] = new String[n];
		System.out.print("Enter the "+n+" diffrenct name in an array: ");
		for(int i=0; i<n; i++) {
			 arr[i] = sc.nextLine();
		}
		
		ascendingOrder(arr);
	}

}
