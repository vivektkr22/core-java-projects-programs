package com.string;

//WAP to input a string and encrypt in ceaser-cipher mode.
//rotate each charactor by 13 places.
//input: Apple
//Ouptut: NCCyr

import java.util.Scanner;
public class Q43 {
	public static void rotateCharacter(String str, int n) {
		String s = "";
		for(int i=0; i<str.length(); i++) {
			char ch = (char)(str.charAt(i)+n);
			if(ch>=90 && ch<=96) s+= (char)(str.charAt(i)+n+6);
			else if(ch>122) {
				s+= (char)(str.charAt(i)+n-58);
			}
			else if(str.charAt(i)==' ') s+= ' ';
			else {
				s+=(char)(str.charAt(i)+n);
			}
		    
		}
		System.out.println("rotated string is: "+s);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a string: ");
		String str  = sc.nextLine();
		
		System.out.print("Enter the number of place by rotate each char: ");
		int n = sc.nextInt();
		
		rotateCharacter(str,n);
		sc.close();
	}

}
