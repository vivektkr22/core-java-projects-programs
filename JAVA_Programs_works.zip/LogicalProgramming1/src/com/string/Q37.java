package com.string;

import java.util.Scanner;

public class Q37 {
	
	public static void printPalindromeWord(String str) {
		String s[] = str.split(" ");
		for(int i=0; i<s.length; i++) {
			if(isPalindrome(s[i])) {				
				System.out.println("Palindrome word is: "+s[i]);
			}
		}
	}
	public static boolean isPalindrome(String s) {
		for(int i=0; i<s.length(); i++) {
			if(s.charAt(i)!=s.charAt(s.length()-i-1)) {
				return false;
			}
		}
		return true;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the sentence: ");
		String str = sc.nextLine();
		
		printPalindromeWord(str);
		sc.close();
	}

}
