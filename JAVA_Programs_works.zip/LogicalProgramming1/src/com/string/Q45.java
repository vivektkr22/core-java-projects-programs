package com.string;

import java.util.Scanner;

public class Q45 {
	public static boolean isEmirp(int n) {
        if (!isPrime(n)) {
            return false;
        }
        int reversed = reverseNumber(n);
        return isPrime(reversed) && reversed != n;
    }
    public static boolean isPrime(int num) {
        if (num < 2) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
    public static int reverseNumber(int n) {
        int rev = 0;
        while (n != 0) {
            rev = rev * 10 + n % 10;
            n /= 10;
        }
        return rev;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a number: ");
        int number = sc.nextInt();

        if (isEmirp(number)) {
            System.out.println(number + " is an emirp number.");
        } else {
            System.out.println(number + " is not an emirp number.");
        }
        sc.close();
    }
}

