package com.string;
/* 7.Substring with single parameter
Wap to get the set of characters simultaneously from start index upto the last index of String excluding the character
 present at last index.
 */

import java.util.Scanner;


public class Q7 {
	public static void main(String[] args) {
	String str="naresh i Technologies";
	Scanner sc=new Scanner(System.in);
	System.out.println(" Enter starting index value from where you want to extract:");
	int startindex=sc.nextInt();
	System.out.println(" Enter last index value from where you want to extract:");
	int lastindex=sc.nextInt();
	String result=str.substring(startindex,lastindex);
	System.out.println(result);
	}
	}