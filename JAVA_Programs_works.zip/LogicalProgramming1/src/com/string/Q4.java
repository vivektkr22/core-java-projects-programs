package com.string;
// 4.Wap to search for the availability of character in a string Starting from given index.

import java.util.Scanner;
public class Q4 {
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println(" Enter a String : ");
		String str=sc.nextLine();
		System.out.println(" Enter index for setting starting position of search: ");
		int index=sc.nextInt();
		System.out.println(" Enter a character to search: ");
		char key=sc.next().charAt(0);
		boolean flag=false;
		for(int i=index;i<str.length();i++) {
			char ch=str.charAt(i);
			if(key==ch) {
				flag=true;
				break;
			}
		}
		if(flag==true)
		System.out.println(key+": is present");
		else {
			System.out.println(key+": is not present");
		}
	}
	}