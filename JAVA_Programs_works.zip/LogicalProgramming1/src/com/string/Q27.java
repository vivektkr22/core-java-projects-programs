package com.string;

import java.util.Scanner;
/*WAP to accept a string and display whther it is unique or not. A unique string is a string if none of the letters 
in string is repeated. */

public class Q27 {
	
	public static void checkUniqueString(String str) {
//		1st Mehtod
		/* boolean flag = false;
		String s = str.toLowerCase();
		for(int i=0; i<s.length(); i++) {
			for(int j=i+1; j<s.length()-1; j++) {
				if(s.charAt(i)==s.charAt(j)) {
					flag = true;
					break;
				}
			}
		}  
		*/
		
//		2nd method
		boolean flag = false;
		String s = str.toLowerCase();
		char ch[] = s.toCharArray();
		for(int i=0; i<ch.length-1; i++) {
			for(int j=i+1; j<ch.length; j++) {
				if(ch[i]==ch[j]) {
					flag = true;
					break;
				}
			}
		}
		if(flag==true) System.out.println(str+" is not unique String");
		else System.out.println(str+" is unique Stirng");	
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a string: ");
		String str = sc.nextLine();
		
		checkUniqueString(str);
		sc.close();
	}

}
