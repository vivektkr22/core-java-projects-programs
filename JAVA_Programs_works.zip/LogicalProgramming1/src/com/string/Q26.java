package com.string;
//WAP to accept a string and find the occurance of the given word in the string.

public class Q26 {

	public static void main(String[] args) {
		String string = "India is a part of asia. It is one of the"+" developing country.";
		String key = "asia";
		int count =0;
		String words[] = string.split(" ");
		for(int i=0; i<words.length; i++) {
			if(key.equals(words[i])) {
				count++;
			}
		}
		if(count>0) System.out.println(key+" occured "+count+" times");
		else System.out.println(key+" not available");
	}
}
