package com.string;

import java.util.Scanner;

//1.WAp to find the length of string without using predefind function; 
public class Q1 {
public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
System.out.println(" Enter a String : ");
	String str=sc.nextLine();
	System.out.print(" the length of string: ");  
////	1st method
//	char [] charArr = str.toCharArray();
//	int l=0;
//	for(char c : charArr) {
//		l++;
//	}
//	System.out.println(l);
	
//	2nd method
	int i=0;
	try {
		for(i=0; str.charAt(i)!='\0'; i++);
	}
	catch(Exception e) {
		
	}
	System.out.print(i);
}
}