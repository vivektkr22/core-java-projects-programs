package com.string;
/* 6.WAP TO EXTRACT  A set of characters simulatneously from a given string upto  the end of string including  the 
character at given substring
*/

import java.util.Scanner;

public class Q6 {
public static void main(String[] args) {
String str="naresh i Technologies";
Scanner sc=new Scanner(System.in);
System.out.println(" Enter index value from where you want to extract");
int index=sc.nextInt();
String result=str.substring(index);
System.out.println(result);
}
}