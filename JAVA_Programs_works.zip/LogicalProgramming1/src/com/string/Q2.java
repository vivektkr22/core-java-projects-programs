package com.string;

import java.util.Scanner;

//2.WAP to find the character from given index of the index.
public class Q2 {
public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
System.out.println(" Enter a String : ");
	String str=sc.nextLine();
	System.out.println(" Enter index value to get the character: ");
	int index=sc.nextInt();
	char ch=str.charAt(index);
	System.out.println("Character at "+index+":"+ch);
}
}
