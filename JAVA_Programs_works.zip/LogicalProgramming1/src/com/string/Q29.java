package com.string;

import java.util.Scanner;

/* WAP to accept a string and display a new string by removing all the duplicate charactors of string.
    Input: america
    Output: meric
    Hint: use 'toCharArray'
    */
public class Q29 {
	public static void removeDuplicateChar(String str) {
		String s = "";
		char s1[] = str.toCharArray();
		for(int i=0; i<s1.length; i++) {
			int c=0;
			for(int j=i+1; j<s1.length-1; j++) {
				if(s1[i]==s1[j]) {
					s1[j]=' ';
					c++;
				}
			}
			if(c==0 && s1[i]!=' ') s+=s1[i];
		}
		System.out.println("Orignal String: "+str);
		System.out.println("After remove duplicate String: "+s);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a string: ");
		String str = sc.nextLine();
		
		removeDuplicateChar(str);
		sc.close();
	}

}
