package com.string;
// WAP to check whether the set(pair) of braces are balanced or not.   {[i(n(d)i)a]}

import java.util.Scanner;
import java.util.Stack;

public class Q41 {
	public static boolean isValid(String s) {
        Stack <Character> stack = new Stack<>();
        char ch[] = s.toCharArray();
        
        for(char c : ch){
            if(c=='(' || c=='{' || c=='['){
                stack.push(c);
            }
            else if(c==')' || c=='}' || c==']'){
                if(stack.isEmpty()){
                return false;
                }
                char top = stack.pop();
                if(c==')' && top!='(' || c=='}' && top!='{' || c==']' && top!='['){
                    return false;
                }
            }
        }
        return stack.isEmpty();
    }

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string with braces: ");
		String str = sc.nextLine();
		System.out.println(isValid(str));

		
		sc.close();
	}

}
