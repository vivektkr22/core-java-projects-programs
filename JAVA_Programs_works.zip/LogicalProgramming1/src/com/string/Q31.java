package com.string;
import java.io.BufferedReader;
import java.io.InputStreamReader;
/* WAP to store names of 10 students and their contact number correspondingly in two diffrent arraay. Enter the name and search
 * whether its in the list or not. If it is present then display the name alongwith its corresponding contact number.
 */
import java.util.Scanner;
public class Q31 {
	public static void printData(String str, String[] student, long number[] ) {
		for(int i=0; i<student.length; i++) {
			if(student[i].equals(str)) {
				System.out.println("Student name is: "+str+" And Number is: "+number[i]);
				break;
			}
		}
	}
	public static void main(String[] args)throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the number of student data you want ot store: ");
		int n = sc.nextInt();
		String student[] = new String[n];
		long number [] = new long[n];
		
		for(int i=0; i<n; i++) {
			System.out.println("Enter the "+(i+1)+" student name");
			student[i] = br.readLine();
			System.out.println("Enter the "+(i+1)+" student number");
			number[i] = sc.nextLong();
		}
		
		System.out.print("Enter the student name which data you want to see: ");
		String str = sc.next();
		printData(str, student, number);
		sc.close();
	}

}
