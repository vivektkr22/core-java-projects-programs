package com.string;

import java.util.Scanner;

// WAP to accept a string and display it is palindrome or not
public class Q28 {
	public static void checkPalindromeString(String str) {
		boolean flag = true;
		for(int i=0; i<str.length(); i++) {
			if(str.charAt(i)!=str.charAt(str.length()-i-1)) {
				flag = false;
				break;
			}
		}
		if(flag) System.out.println("palindrome");
		else System.out.println("not palindrome");
		
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a string: ");
		String str = sc.nextLine();
		
		checkPalindromeString(str);
		sc.close();
	}

}
