package com.string;
// Alpha and Beta
// AaltpehBa
import java.util.Scanner;

public class Q42 {
	
	public static void printCombinationOfTwoString(String s1, String s2) {
		String s = "";
		int len = Math.max(s1.length(), s2.length());
		
		for(int i=0; i<len; i++) {
			if(i!=s1.length())
				s+=s1.charAt(i);
			if(i!=s2.length())
				s+=s2.charAt(s2.length()-i-1);
		}
		
		
		System.out.println("Combine String is: "+s);
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter first string: ");
		String str1 = sc.next();
		System.out.print("Enter second String: ");
		String str2 = sc.next();
		
		printCombinationOfTwoString(str1,str2);
		sc.close();
	}

}
