package com.string;
//WAP to input aname and display only its initials.
public class Q35 {
   
}
