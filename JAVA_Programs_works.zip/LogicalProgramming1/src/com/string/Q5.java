package com.string;
//5.WAP to find the index of Last occurrrance of a character in the String.

import java.util.Scanner;

public class Q5 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter a String : ");
		String str = sc.nextLine();
		System.out.println("Enter a character to find its last occurance:");
		char ch = sc.next().charAt(0);
		int lastoccurrance = str.lastIndexOf(ch);
		if (lastoccurrance >= 0)
			System.out.println("last occurrance of" + ch + " is to " + lastoccurrance);
		else {
			System.out.println(ch+"characater is not available:");
		}
	}
}
