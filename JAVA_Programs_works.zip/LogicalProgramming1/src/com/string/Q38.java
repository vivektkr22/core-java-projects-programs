package com.string;
//WAP to enter a sentence and 
public class Q38 {

	public static void main(String[] args) {
		
	}

}
