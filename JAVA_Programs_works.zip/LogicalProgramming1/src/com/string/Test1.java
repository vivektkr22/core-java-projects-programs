package com.string;

import java.util.Scanner;

// WAP to take input as in an array as a 200,500,510,650 output shoould be:- 002, 005, 015, 056
public class Test1 {
	public static String[] reverseElemnetInAnArray(int arr[]) {
		String str[] = new String[arr.length];
		for(int i=0;  i<arr.length; i++) {
			String s = String.valueOf(arr[i]);
			String s1 = "";
			for(int j=s.length()-1; j>=0; j--) {
				s1+=s.charAt(j);
			}
			str[i] = s1;
		}
		return str;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the length of an array: ");
		int n = sc.nextInt();
		int arr[] = new int[n];
		System.out.print("Enter the elements in an array: ");	
		for(int i=0; i<n; i++) {
			arr[i] = sc.nextInt();
		}
		String str[] = reverseElemnetInAnArray(arr);
		for(int i=0; i<str.length; i++) {
			System.out.println(str[i]);
		}
		
	}

}
