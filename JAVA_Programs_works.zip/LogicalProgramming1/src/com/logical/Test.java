
package com.logical;

import java.util.Scanner;

//1.WAp to find the length of string without using predefind function; 
//public class Test {
//public static void main(String[] args) {
//Scanner sc=new Scanner(System.in);
//System.out.println(" Enter a String : ");
//	String str=sc.nextLine();
//	System.out.println(" the length of string:");  
//	1st method
//	char [] charArr = str.toCharArray();
//	int l=0;
//	for(char c : charArr) {
//		l++;
//	}
//	2nd method
//	int i=0;
//	for(i=0; str.charAt(i)!='\0'; i++)
//	System.out.println(i);
//}
//}
	

//2.WAP to find the character from given index of the index.
//public class Str1 {
//public static void main(String[] args) {
//Scanner sc=new Scanner(System.in);
//System.out.println(" Enter a String : ");
//	String str=sc.nextLine();
//	System.out.println(" Enter index value to get the character: ");
//	int index=sc.nextInt();
//	char ch=str.charAt(index);
//	System.out.println("Character at "+index+":"+ch);
//}
//}


//3.WAP to find the first occurrrance of a character in the String.
//public class Str1 {
//public static void main(String[] args) {
//Scanner sc=new Scanner(System.in);
//System.out.println(" Enter a String : ");
//	String str=sc.nextLine();
//	System.out.println("Enter a character to find its first occurance:");
//	char ch=sc.nextLine().charAt(0);
//	int position=str.indexOf(ch);
//			if(position>=0)
//	System.out.println("First occurrance of:"+ch+":"+position);
//			else {
//				System.out.println("characater is not present:");
//			}
//}
//}


//4.Wap to search for the availability of character in a string Starting from given index.
//public class Str1 {
//	public static void main(String[] args) {
//	Scanner sc=new Scanner(System.in);
//	System.out.println(" Enter a String : ");
//		String str=sc.nextLine();
//		System.out.println(" Enter index for setting starting position of search: ");
//		int index=sc.nextInt();
//		System.out.println(" Enter a character to search: ");
//		char key=sc.next().charAt(0);
//		boolean flag=false;
//		for(int i=index;i<str.length();i++) {
//			char ch=str.charAt(i);
//			if(key==ch) {
//				flag=true;
//				break;
//			}
//		}
//		if(flag==true)
//		System.out.println(key+": is present");
//		else {
//			System.out.println(key+": is not present");
//		}
//	}
//	}


//5.WAP to find the index of Last occurrrance of a character in the String.
//public class Str1 {
//	public static void main(String[] args) {
//		Scanner sc = new Scanner(System.in);
//		System.out.println(" Enter a String : ");
//		String str = sc.nextLine();
//		System.out.println("Enter a character to find its last occurance:");
//		char ch = sc.next().charAt(0);
//		int lastoccurrance = str.lastIndexOf(ch);
//		if (lastoccurrance >= 0)
//			System.out.println("last occurrance of" + ch + " is to " + lastoccurrance);
//		else {
//			System.out.println(ch+"characater is not available:");
//		}
//	}
//}


//6.WAP TO EXTRACT  A set of characters simulatneously from a given string upto  the end of string including  the character at given.
//substring
//public class Str1 {
//public static void main(String[] args) {
//String str="naresh i Technologies";
//Scanner sc=new Scanner(System.in);
//System.out.println(" Enter index value from wher you want to extract");
//int index=sc.nextInt();
//String result=str.substring(index);
//System.out.println(result);
//}
//}


//7.Substring with single parameter
//Wap to get the set of characters simultaneously from start index upto the last index of String excluding the character present at last index.
//public class Str1 {
//	public static void main(String[] args) {
//	String str="naresh i Technologies";
//	Scanner sc=new Scanner(System.in);
//	System.out.println(" Enter starting index value from where you want to extract:");
//	int startindex=sc.nextInt();
//	System.out.println(" Enter last index value from where you want to extract:");
//	int lastindex=sc.nextInt();
//	String result=str.substring(startindex,lastindex);
//	System.out.println(result);
//	}
//	}


//8.Substring with different parameter
//Wap to convert a given string into lowercase.
//public class Str1 {
//	public static void main(String[] args) {
//		String s1 = "naresh i Technologies";
//		String s2 = s1.toLowerCase();
//		System.out.println("original" + s1);
//		System.out.println(" after convert to lowercase:" + s2);

//

//		String s1 = "java65";
//		String r = "";
//		for (int i = 0; i < s1.length(); i++) {
//			char ch = s1.charAt(i);
//			if (ch >= 'A' && ch <= 'Z') {
//				r = r + (char) (ch + 32);
//			} else {
//				r = r + ch;
//			}
//		}
//		System.out.println("original: " + s1);
//		System.out.println("after convert to lowercase:" + r);
//	}
//}


//9.tolowercase or without using method
//WAP to convert a given string into uppercase.
//public class Str1 {
//	public static void main(String[] args) {
/*
String s1 = "naresh i Technologies";
String s2 = s1.toUpperCase();
System.out.println("original" + s1);
System.out.println(" after convert to lowercase:" + s2);*/
//		String s1 = "java";
//		String r = "";
//		for (int i = 0; i < s1.length(); i++) {
//			char ch = s1.charAt(i);
//			if (ch >= 'a' && ch <= 'z') {
//				r = r + (char) (ch -32);
//			} else {
//				r = r + ch;
//			}
//		}
//		System.out.println("original: " + s1);
//		System.out.println("after convert to lowercase:" + r);
//	}
//}


//wap to store  a string convert the letter set present at even position into opposite case
//10.touppercase or without using method join character  a string .
//WAp to replace a character by another character  to replace a String by another string at all its occurrence
//in the given string.
//public class Str1 {
//	public static void main(String[] args) {
//		String s1="j*v*";
//		System.out.println("original: "+s1);
//	Scanner sc=new Scanner(System.in);
//	System.out.println(" Enter which charcter to be changed: ");
//		char oldchar=sc.next().charAt(0);
//		System.out.println(" Enter index value to get the character: ");
//		char newchar=sc.next().charAt(0);
//		String result="";
//		for(int i=0;i<s1.length();i++) {
//			char ch=s1.charAt(i);
//			if(ch==oldchar) {
//				result=result+newchar;
//			}else {
//				result+=ch;
//			}
//			}
//		System.out.println("original: " + s1);
//		System.out.println("after convert to lowercase: " + result);
//
//	}
//}


//11.Write a program from below requirement;
//a)Enter 2 integer form of string
//b)calculate and display the sum of the sum of the number
//class Str1 {
//	public static void main(String[] args) {
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter the first num:");
//		String n1 = sc.next();
//		System.out.println("Enter the second num");
//		String n2 = sc.next();
//		Integer i1=Integer.parseInt(n1);
//		Integer i2=Integer.parseInt(n2);
//		System.out.println(i1+i2);
//
//	}
//}


//12. Wap to join  the two String.
//public class Str1{
//	public static void main(String[] args) {
//		String s1="core";
//		String s2="java";
//		String s3=s1.concat(s2);
//		String s4=s1+s2;
//		System.out.println(s1);
//System.out.println(s3);
//System.out.println(s4);
//	}
//}
//


//13. wap a program to compare two string identical or not
//public class Str1{
//	public static void main(String[] args) {
//		String s1="Java";
//		String s2="java";
//		boolean result=s1.equals(s2);
//		if(result==true) {
//		System.out.println("String objects are identical");}
//		else {
//			System.out.println("String objects are not identical");
//		}
//		
//	}
//}
//


//14. wap a program to compare two string identical or not
//public class Str1{
//	public static void main(String[] args) {
//		String s1="Java";
//		String s2="java";
//		boolean result=s1.equalsIgnoreCase(s2);
//		if(result==true) {
//		System.out.println("String objects are identical");}
//		else {
//			System.out.println("String objects are not identical");
//		}
//		
//	}
//}



//15. Wap to remove leading and traveling blanks from a string.

//public class Str1{
//public static void main(String[] args) {
//	String s1="core   ";
//	String s2="   java";
//	System.out.println(s1+s2);
//	String s3=s1.trim();
//	String s4=s2.trim();
//	System.out.println(s3+s4);
//}
//}



//16. WAP to check whether a given string has a specified suffix or not.
//public class Str1 {
//	public static void main(String[] args) {
//		String str="naresh i Technologies";
//		String input="ameerpet";
//		boolean result=str.endsWith(input);
//		if(result==true) {
//		System.out.println(str+"String does endswith"+input);}
//		else {
//			System.out.println(str+"String does not endswith"+input);
//		}
//	}
//}


//17. wap to check whether  a given string is prefix of another.
//public class Str1 {
//	public static void main(String[] args) {
//		String str="ameerpet naresh i Technologies";
//		String input="ameerpet";
//		boolean result=str.startsWith(input);
//		if(result==true) {
//		System.out.println(str+" Starts with "+input);}
//		else {
//			System.out.println(str+"does not starts with"+input);
//		}
//	}
//}


//18. WAP to convert a string into different pdt of corresponding wrapper class.
//public class Str1 {
//	public static void main(String[] args) {
//		String s1 = "121";
//
//		// converting String to byte
//		byte a = Byte.parseByte(s1);
//		System.out.println("byte type"+a);
//		
//		// converting String to short
//		short b = Short.parseShort("short type"+s1);
//		System.out.println(b);
//		
//		
//		// converting String to int
//		int c = Integer.parseInt(s1);
//		System.out.println(c);

//		// converting String to long
//		long d = Long.parseLong(s1);
//		System.out.println(d);
//		
//		
//		// converting String to float
//		float e = Float.parseFloat(s1);
//		System.out.println(e);
//	
//		
//		// converting String to double
//		double f = Double.parseDouble(s1);
//		System.out.println(f);
//		
//		// converting String to boolean
//		boolean h = Boolean.parseBoolean(s1);
//		System.out.println(h);
//	}
//}

//19. Wap a program primitive type value into string.
//public class Str1 {
//	public static void main(String[] args) {
//		int n1 = 20, n2 = 24;
//		String s1 = Integer.toString(n1);
//		String s2 = Integer.toString(n2);
//		System.out.println(n1);
//		System.out.println("After conversion"+(n1+n2));
//	}
//}


//20. wap to diplay each letter of string separete lines.
//public class Str1{
//	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter a String: ");
//		String str=sc.nextLine();
//		int n=str.length();
//		for(int i=0;i<n;i++) {
//			char ch=str.charAt(i);
//			System.out.println(ch);
//		}
//	}
//}

//
//public class Str1 {
//	public static void main(String[] args) {
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter a String: ");
//		String str = sc.nextLine();
//		String c = str.toUpperCase();
//		//int vowelCount=0;
//		 int aCount=0,eCount=0,iCount=0,uCount=0,oCount = 0;
//		for (int i = 0; i < str.length(); i++) {
//			char ch = str.charAt(i);
////			if (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U') {
////				//vowelCount++;
////			}
//			if (ch == 'A') {
//				aCount++;
//			}
//			if (ch == 'E') {
//				eCount++;
//			}
//			if (ch == 'I') {
//				iCount++;
//			}
//			if (ch == 'O') {
//				oCount++;
//			}
//			if (ch == 'U') {
//				uCount++;
//			}
//		}
//	}
//}
//import java.util.Scanner;
//public class Str1 {
//	public static String replaceOldCharacter(String str, char o, char n) {
//		String r = "";
//		for (int i = 0; i < str.length(); i++) {
//			char Ch = str.charAt(i);
//			if (Ch == o) {
//				Ch = n;
//				r = r + Ch;
//			}
//			else {
//				r = r + Ch;
//			}
//		}
//		return r;
//	}
//
//	public static void main(String[] args) {
//		//String str="j*v*";
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter the string:");
//		String str=sc.nextLine();
//		System.out.println("old");
//		char old=sc.next().charAt(0);
//		System.out.println("new");
//		char newc=sc.next().charAt(0);
//		String result = replaceOldCharacter(str,old,newc);
//		System.out.println("replaceOldCharacter:        "+result);
//	}
//}


//Wap to accept a string and change the case of each letter of the String.
//import java.util.Scanner;
//public class Str1 {
//	public static String changecaseofchar(String str) {
//		String r ="";
//		for (int i = 0; i < str.length(); i++) {
//			char Ch = str.charAt(i);
//			if (Ch>=65&&Ch<=90) {//if (Ch>='A'&&Ch<='Z')
//				Ch +=32 ;          //CH=(char)(ch+32);
//				r+=Ch;
//			}
//			else if(Ch==32){
//				r+=" ";
//			}
//			else {
//				Ch -=32;
//				r+=Ch;
//			}
//		}
//		return r;
//	}
//
//	public static void main(String[] args) {
//		//String str="j*v*";
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter the string:");
//		String str=sc.nextLine();
//		String result = changecaseofchar(str);
//		System.out.println(result);
//	}
//}



//WAP  to accept a string





//
