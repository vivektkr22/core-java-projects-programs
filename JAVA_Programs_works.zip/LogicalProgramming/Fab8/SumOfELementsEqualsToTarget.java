package Fab8;

import java.util.Scanner;

public class SumOfELementsEqualsToTarget {
	
	public static int[] sumOfTwoElements(int arr[], int t) {
		int a[] = new int[2];
		for(int i=0; i<arr.length; i++) {
			for(int j=i+1; j< arr.length; j++) {
				if(arr[i]+arr[j]==t) {
					System.out.println("Elements are: "+arr[i]+" "+arr[j]);
					a[0] = i;
					a[1] = j;
					return a;
				}
			}
		}
		return new int[] {-1};
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the size of the array: ");
		int n = sc.nextInt();
		
		int arr [] = new int[n];
		
		System.out.print("Enter elemenst in an array:  ");
		for(int i =0; i<arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		System.out.print("Enter the target: ");
		int t = sc.nextInt();
		
		int a[] = sumOfTwoElements(arr,t);
	
		if(a[0] == -1) {
			System.out.print("Elements are not present in an array");
		}
		else {
			System.out.print("Array indexes is: ");
			for(int i=0; i<a.length; i++) {
				System.out.print(a[i]+" ");
			}
		}
		
		sc.close();
	}

}
