package Fab8;

import java.util.Scanner;

public class StoreElementsIn2DMatrix {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter row number: ");
		int row = sc.nextInt();
		System.out.print("Enter coloumn number: ");
		int column = sc.nextInt();
		
		int arr[][] = new int[row][column];
		for(int i=0; i<row; i++) {
			for(int j=0; j<column; j++) {
				System.out.print("Enter ("+i+", "+j+") Element: ");
				arr[i][j] = sc.nextInt();
			}
		}
		System.out.println(row+"x"+column+" matrix :");
		for(int i=0; i<row; i++) {
			for(int j=0; j<column; j++) {
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
		sc.close();
	}

}
