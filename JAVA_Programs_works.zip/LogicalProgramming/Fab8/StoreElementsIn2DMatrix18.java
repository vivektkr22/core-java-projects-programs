package Fab8;

import java.util.Scanner;

public class StoreElementsIn2DMatrix18 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int arr1[][] = new int[3][3];
		int arr2[][] = new int[3][3];
		
		System.out.println("Enter the elemets in first matrix: ");
		for(int i=0; i<3; i++) {
			for(int j=0; j<3; j++) {
				arr1[i][j] = sc.nextInt();
			}
		}
		System.out.println("Enter the elemets in Second matrix: ");
		for(int i=0; i<3; i++) {
			for(int j=0; j<3; j++) {
				arr2[i][j] = sc.nextInt();
			}
		}
		
		System.out.println("First array matrix: ");
		for(int i=0; i<arr1.length; i++) {
			for(int j=0; j<arr1.length; j++) {
				System.out.print(arr1[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println("Second array matrix: ");
		for(int i=0; i<arr2.length; i++) {
			for(int j=0; j<arr2.length; j++) {
				System.out.print(arr2[i][j]+" ");
			}
			System.out.println();
		}
		sc.close();
	}

}
