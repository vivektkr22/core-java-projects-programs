package Fab7;

import java.util.Scanner;

public class ReverseElementsInArrayOfCurrentPosition {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the size of the array: ");
		int n = sc.nextInt();
		
		int arr [] = new int[n];
		
		System.out.print("Enter element in an array:  ");
		for(int i =0; i<arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		
		for(int i=0; i<arr.length; i++) {
			int t = arr[i],rev =0;
			while(t!=0) {
				 rev = rev *10 + t%10;
				 t/=10;				
			}
			arr[i] = rev;
		}
		System.out.print("Reverse Elements in array: ");
		for(int i=0; i<arr.length; i++) {
			System.out.print(arr[i]+" ");
		}
		sc.close();
	}

}
