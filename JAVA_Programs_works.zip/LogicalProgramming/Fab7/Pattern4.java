package Fab7;

import java.util.Scanner;

public class Pattern4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number : ");
		int n = sc.nextInt();
		char c = 'a';
		for(int i=0; i<n; i++) {
		
			for(int j=0; j<n; j++) {
				System.out.print(c +" ");
			}
			c++;
			System.out.println();
		}	
		sc.close();
	}

}
