package Fab22;

import java.util.Scanner;

public class Q21 {
	public static String replaceOldCharacter(String str, char o, char n) {
		String r = "";
		for(int i=0; i<str.length(); i++) {
			char ch = str.charAt(i);
			if(ch==0) {
				ch=n;
				r=r+ch;
			}
			else {
				r=r+ch;
			}
		}
		return r;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String r = "J*v*";
		System.out.print("Enter the old charactor to replace:");
		char oldChar = sc.next().charAt(0);
		System.out.print("Enter the new charactor to replace: ");
		char newChar = sc.next().charAt(0);
		
		String str = replaceOldCharacter(r, oldChar, newChar);
		System.out.println("New String is: "+str);
	}

}
