package Fab22;

public class ChangeCaseOfCharactor {
	public static String caseChange(String str) {
		String s ="";
	    for(int i=0; i<str.length(); i++) {
	    	char ch = str.charAt(i);
	    	if(ch>=97 && ch<=122) {
	    		ch-=32;
	    		s+=ch;
	    	}
	    	else if(ch>=65 && ch<=90) {
	    		ch+=32;
	    		s+=ch;
	    	}
	    }
	    return s;
	}

	public static void main(String[] args) {
		String s = "gooD";
		String str = caseChange(s);
		System.out.print("Changed String is: "+str);
	}

}
