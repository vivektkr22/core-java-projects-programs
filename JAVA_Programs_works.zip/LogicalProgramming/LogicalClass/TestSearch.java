package LogicalClass;

import java.util.Scanner;

/* WAP to store 10 number, enter a number to be search in the array. if the number is vailabel in the array then display 
 * "Element is present" otherwise display "element not found"  */
public class TestSearch {
	
	public static void searchKey(int arr[], int k) {
		boolean flag = false;
		for(int i=0; i<arr.length; i++) {
			if(arr[i]==k) {
				flag = true; break;
			}
		}
		if(flag==true) {
			System.out.println("Element is present");
		}
		else {
			System.out.println("Element is not present");
		}
		
		
	}

	public static void main(String[] args) {
       int arr[] = new int[10];
       Scanner sc = new Scanner(System.in);
       System.out.println("Enter any 10 integers: ");
       for(int i =0; i<arr.length; i++) {
    	   arr[i] = sc.nextInt();
       }
       System.out.println("Enter the key to be search in array: ");
       int key = sc.nextInt();
       
       searchKey(arr,key);
	}

}




