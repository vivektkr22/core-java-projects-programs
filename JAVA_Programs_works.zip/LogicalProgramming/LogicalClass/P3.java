package LogicalClass;

public class P3 {
	
	public static void displayElements(int arr[]) {
		System.out.println("Elements stored in an array:");
		for(int i=0; i<arr.length; i++) {
			System.out.print(arr[i]+" ");
		}
	}
	
	public static void displayEvenNumbers(int arr[]) {
		System.out.println("\nEven numbers are stored in an array: ");
		for(int i=0; i<arr.length; i++)
			if(arr[i]%2==0) {
				System.out.print(arr[i]+" ");
			}
	}
	
	public static void displayOddNumbers(int arr[]) {
		System.out.println("\nOdd numbers are stored in an array: ");
		for(int i =0; i<arr.length; i++) {
			if(arr[i]%2!=0) {
				System.out.print(arr[i]+" ");
			}
		}
	}
	
	public static void displayNumberDivisibleByTwoAndThree(int arr[]) {
		System.out.println("\nNumbers divisible by two and three are stored in an array: ");
		for(int i =0; i<arr.length; i++) {
			if(arr[i]%2==0 && arr[i]%3==0) {
				System.out.print(arr[i]+" ");
			}
		}
	}
	
	public static void displayNumberDivisibleByFive(int arr[]) {
		System.out.println("\nNumbers divisible by five are stored in an array: ");
		for(int i =0; i<arr.length; i++) {
			if(arr[i]%5==0) {
				System.out.print(arr[i]+" ");
			}
		}
	}

	public static void main(String[] args) {
		int arr[] = {10,33,55,58,29,48,88,40,38,69};
		displayElements(arr);
		displayEvenNumbers(arr);
		displayOddNumbers(arr);
		displayNumberDivisibleByTwoAndThree(arr);
		displayNumberDivisibleByFive(arr);
}
}
