package LogicalClass;

import java.util.Scanner;

/* If element is present display its position 
 * if element is present at multiple location then also the position must be displayed.
 */
public class P5 {
	
	public static void displayElementPosition(int arr[]) {
		
	}

	public static void main(String[] args) {
		int arr[] = new int[10];
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the elements in an array: ");
		for(int i=0; i<arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		
		displayElementPosition(arr);
	}

}
