package LogicalClass;

import java.util.Scanner;

public class P4 {
	public static void findTotal(int arr[]) {
		int sum =0;
		for(int i=0; i<arr.length; i++) {
			sum+=arr[i];
		}
		System.out.println("total marks is: "+sum);
	}

	public static void main(String[] args) throws Exception {
		int subject [] = new int[6];
		Scanner sc = new Scanner(System.in);
		for(int i =0; i<subject.length; i++) {
			System.out.print("Enter a subject marks ");
			subject[i] = sc.nextInt();
		}
		
		findTotal(subject);
	}

}
