package Fab6;

import java.util.Scanner;

public class FactorsOfHundred {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the size of the array: ");
		int n = sc.nextInt();
		
		int arr [] = new int[n];
		
		System.out.print("Enter elemenst in an array:  ");
		for(int i =0; i<arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		
		System.out.print("Elements which are factors of hundred: ");
		for(int i =0; i<arr.length; i++) {
			if(100%arr[i]==0) {
				System.out.println(arr[i]);
			}
		}
		
		sc.close();
	}

}
