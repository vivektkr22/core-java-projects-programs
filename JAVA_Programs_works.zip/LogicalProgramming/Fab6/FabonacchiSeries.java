package Fab6;

import java.util.Scanner;

public class FabonacchiSeries {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);		
		
		System.out.print("Enter the number of terms in fabonacchi series which has to be store in an array:  ");
		int t = sc.nextInt();
		int arr [] = new int[t];
		
		int a=0,b=1;
		
		arr[0] = a;
		arr[1] = b;
		
		for(int i=2 ; i<arr.length; i++) {
			int temp = a+b;
			a = b;
			b = temp;
			arr[i] = b;
		}
		
		for(int i=0; i<arr.length; i++) {
			System.out.print(arr[i]+" ");
		}
		
		sc.close();
	}

}
