package Fab6;

import java.util.Scanner;

public class HighestAndLowestInArray {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the size of the array: ");
		int n = sc.nextInt();
		
		int arr [] = new int[n];
		
		System.out.print("Enter elemenst in an array:  ");
		for(int i =0; i<arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		
		int high = arr[0];
		int low = arr[0];
		
		for(int i=1; i<arr.length; i++) {
			if(arr[i]<high) {
				high = arr[i];
			}
			if(arr[i]>low) {
				low = arr[i];
			}
		}
		System.out.println("Highest is: "+ low);
		System.out.println("Lowest is: "+ high);
        sc.close();
	}

}
