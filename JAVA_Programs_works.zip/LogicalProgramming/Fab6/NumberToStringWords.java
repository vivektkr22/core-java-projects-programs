package Fab6;

import java.util.Scanner;

public class NumberToStringWords {

  public static String[] oneToNine = {"", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"};
  public static String[] elevenToNineteen = {"", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"};
  public static String[] tenToNinty = {"", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"};
    
    public static String numberToWords(int n) {
    	   if (n < 10) {
               return oneToNine[n];
           } else if (n < 20) {
               return elevenToNineteen[n - 10];
           } else if (n < 100) {
               return tenToNinty[n / 10] + " " + numberToWords(n % 10);
           } else if(n<1000){
               return oneToNine[n / 100] + " Hundred " + numberToWords(n % 100);
           }
           else if(n<10000){
           	return oneToNine[n/1000] + " Thousand " + numberToWords(n%1000);
           }
           else if(n<20000){
           	return elevenToNineteen[(n/1000)-10] + " Thousand " +numberToWords(n%1000);
           }
           else if(n<100000) {
           	return tenToNinty[(n/10000)] +" "+oneToNine[((n/1000)%10)]+ " Thousand " + numberToWords(n%1000);
           }
           else {
           	return "out of one lakh";
           }
    }

    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       System.out.print("Enter a number: ");
       int number = sc.nextInt();
       String result="";
       if(number==0) {
    	   result+="Zero";
       }else {
    	    result = numberToWords(number);
       }
        System.out.println(number + " : " + result);
        sc.close();
    }
}
