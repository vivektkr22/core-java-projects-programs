package Fab6;

import java.util.Scanner;

public class DescendingOrder {

		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.print("Enter the size of the array: ");
			int n = sc.nextInt();
			
			int arr [] = new int[n];
			
			System.out.print("Enter elemenst in an array:  ");
			for(int i =0; i<arr.length; i++) {
				arr[i] = sc.nextInt();
			}
			
			for(int i=0; i<arr.length-1; i++) {
				for(int j=i+1; j<arr.length; j++) {
					if(arr[i]<arr[j]) {
						int t = arr[i];
						arr[i] = arr[j];
						arr[j] = t;
					}
				}
			}
			System.out.print("Descending order of the elements store in the array: ");
			for(int i =0; i<arr.length; i++) {
				System.out.print(arr[i]+" ");
			}
			sc.close();
		}

	}


