package Fab6;

import java.util.Scanner;

public class PaytmBillGenerate {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Bill amount: ");
		int n = sc.nextInt();
		System.out.print("ENter amount to pay: ");
		int b = sc.nextInt();
		
		if(n==b) {
			int rev=0;
			while(b!=0) {
				rev = rev*10 + b%10;
				b/=10;
			}
			System.out.println("Inverse : "+ rev);
		}
		else System.out.println("Invalid amount entered");
		
		sc.close();
	}

}
