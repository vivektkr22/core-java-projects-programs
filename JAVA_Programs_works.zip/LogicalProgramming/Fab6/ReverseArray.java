package Fab6;

import java.util.Scanner;

public class ReverseArray {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the size of the array: ");
		int n = sc.nextInt();
		
		int arr [] = new int[n];
		int arr2[] = new int[n];
		
		System.out.print("Enter elemenst in an array:  ");
		for(int i =0; i<arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		
		for(int i = 0 ; i<arr2.length; i++) {
			arr2[arr2.length-i-1] = arr[i];
		}
		System.out.print("Reverse of the elements store in the array: ");
		for(int i=0; i<arr2.length; i++) {
			System.out.print(arr2[i]+" ");
		}
		
	}

}
