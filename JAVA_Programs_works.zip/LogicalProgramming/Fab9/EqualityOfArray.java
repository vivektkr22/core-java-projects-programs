package Fab9;

import java.util.Scanner;

public class EqualityOfArray {
	
	public static void checkArrayEquality(int arr[]) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the size of an arary: ");
		int n = sc.nextInt();
		int arr2 [] = new int[n];
		System.out.println("Enter the elements in an array: ");
		for(int i=0; i<n; i++) {
			arr2[i] = sc.nextInt();
		}
	   boolean flag = true;
	    for(int i=0; i<arr.length; i++) {
	    		if(arr.length!=arr2.length || arr[i]!=arr2[i]) flag = false;
	    	}
	    if(flag) System.out.print("Arrays are equals");
	    else System.out.print("Arrays are not equals");
	    
	    sc.close();
	}

	public static void main(String[] args) {
		int arr[] = {2, 4, 5, 4, 3, 5, 3, 6,};
		checkArrayEquality(arr);	    
	}
}
