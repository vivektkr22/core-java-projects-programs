package Fab9;

import java.util.Scanner;

public class StudentDemo {

	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        String stud[] = new String[5];
        System.out.println("Enter 5 student name: ");
		for(int i=0; i<stud.length; i++) {
			stud[i] = sc.nextLine();
		}
		
		System.out.println("ENter the student name of student of which you want data: ");
		String name = sc.nextLine();
		boolean flag = false;
		for(int i=0; i<stud.length; i++) {
			if(name.equals(stud[i])) {
				flag = true;
				break;
			}			
		}
		if(flag)
		System.out.println("data is present");
		else
		System.out.println("data is not present");
		
		sc.close();
	}

}
