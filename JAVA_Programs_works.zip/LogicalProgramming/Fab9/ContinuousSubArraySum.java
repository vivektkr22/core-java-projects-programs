package Fab9;

import java.util.Scanner;

public class ContinuousSubArraySum {
	
	public static void FindTargetSubArraySum(int arr[],int length, int target) {
		  System.out.println("Target sum of subarray is: ");
	        for(int i=0; i<length; i++) {
	        	int c=0;
	        	for(int j=i; j<length; j++) {
	        		c+=arr[j];
	        		if(c==target) {
	        			for(int k=i; k<=j; k++) {
	        				System.out.print(arr[k]+" ");
	        			}
	        			break;
	        		}
	        	}
	        }
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the size of an array: ");
        int length = sc.nextInt();
        int arr[] = new int[length];
        
        System.out.print("Enter the "+length+" elements in an array: ");
        for(int i=0; i<length; i++) {
        	arr[i] = sc.nextInt();
        }
        System.out.print("Enter the target subarray sum: ");
        int target = sc.nextInt();
        
        FindTargetSubArraySum(arr,length,target);
       sc.close();
	}

}
