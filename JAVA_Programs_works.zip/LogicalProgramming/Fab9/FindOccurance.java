package Fab9;

import java.util.Scanner;

public class FindOccurance {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the size of an array: ");
        int length = sc.nextInt();
        int arr[] = new int[length];
        
        System.out.print("Enter the "+length+" elements in an array: ");
        for(int i=0; i<length; i++) {
        	arr[i] = sc.nextInt();
        }
        
        for(int i=0; i<length-1; i++) {
        	int c=1;
        	for(int j=i+1; j<length; j++) {
        		if(arr[i]==arr[j] && arr[i]!= -1) {
        			 c++;
        			 arr[j] = -1;
        		}
        	}
        	if(arr[i] != -1) System.out.println("Element "+arr[i]+" occurance is: "+ c);
        }
        sc.close();
	}

}
