package Fab9;

import java.util.Scanner;

public class SeparateZeroFromArray {
	
	public static void separateZero(int arr[], int n) {   /* 5 8 0 5 0 4 6 0 3 */
		int k =0;
		for(int i=0; i<n; i++) {
			if(arr[i] !=0) {
				arr[k++] = arr[i];
			}
		}
		
		for(int i=0; i<n; i++) {
			if(k<n)
			arr[k++] = 0;
		}
		
		for(int i=0; i<n; i++){
			int t = arr[i];
	       arr[i] = arr[n-i-1];
	       arr[n-i-1] = t;
	    }
		
		System.out.println("Separated array elements are: ");
		for(int i=0; i<n; i++) {
			System.out.print(arr[i]+" ");
		}
	}
		
//		 second method
//		System.out.println("Separated array elements are: ");
//		int c =0;
//		for(int i=0; i<n; i++) {
//			if(arr[i]==0) c++;
//		}
//		
//		for(int i=0; i<n; i++) {
//			for(int j=i+1; j<n; j++) {
//				if(arr[j]==0) {
//					int t = arr[i];
//					arr[i] = arr[j];
//					arr[j] = t;
//				}
//			}
//		}
//		for(int i=0; i<n; i++) {
//			System.out.print(arr[i]+" ");
//		}		
//	}
	
// third method by using another array

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a size of an array: ");
        int n = sc.nextInt();
        int arr[] = new int[n];
        System.out.print("Enter the elements in an array: ");
        for(int i=0; i<n; i++) {
        	arr[i] = sc.nextInt();
        }
        
        separateZero(arr,n);
        sc.close();
	}

}
