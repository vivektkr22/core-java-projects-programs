package Fab9;

import java.util.Scanner;

public class FindTripletSum {
	
	public static void checkTriplet(int arr[], int n, int target) {    /* {-3, 7, -1, -5, 2, -9, 1} */
		for(int i=0; i<n; i++) {
			int c=0;
			for(int j=i+1; j<n; j++) {
				for(int k=j+1; k<n; k++) {
					c= arr[i]+arr[j]+arr[k];
					if(c==target) {
						
						System.out.println("["+arr[i]+", "+arr[j]+", "+arr[k]+"]");
					}
				}
			}
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a size of an array: ");
        int n = sc.nextInt();
        int arr[] = new int[n];
        System.out.print("Enter the elements in an array: ");
        for(int i=0; i<n; i++) {
        	arr[i] = sc.nextInt();
        }
        System.out.print("Enter the target element: ");
        int target = sc.nextInt();
        
        checkTriplet(arr,n,target);
        sc.close();
  }

}
