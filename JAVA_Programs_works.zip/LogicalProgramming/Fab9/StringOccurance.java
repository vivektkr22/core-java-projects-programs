package Fab9;

import java.util.Scanner;

public class StringOccurance {
	
	public static void checkOccurance(String str) {         /* aabbbccddaabbcddddaa  */
		
		
		char arr [] = new char[str.length()];
		for(int i=0; i<str.length(); i++) {
			arr[i] = str.charAt(i);
		}
		for(int i=0; i<arr.length; i++) {
			int c =1;
			for(int j=i+1; j<arr.length; j++) {
				if(arr[i]==arr[j]) {
					c++;
					arr[j] = '$';
				}
			}
			if(arr[i]!='$')System.out.println(arr[i]+" occured at "+c+" times");
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a String: ");
		String str = sc.nextLine();
		
		checkOccurance(str);
		sc.close();
	}

}
