package Fab13;

import java.util.Scanner;

public class FindMissingNumber {
	
	public static void missingNumber(int arr[], int n) {   //-3 -1 1 3 4 6 7 10 
		for(int i=1; i<n; i++) {
			if ((arr[i] - arr[i - 1]) > 1) {
	            for (int j = 1; j < arr[i] - arr[i - 1]; j++) {
	                System.out.print((arr[i - 1] + j) + " ");
	            }
	        }
	   }
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter array length: ");
		int n = sc.nextInt();
		int arr[]  =new int[n];
		System.out.println("Enter array elements: ");
		for(int i=0; i<n; i++) {
			 arr[i] = sc.nextInt();
		}
		
		missingNumber(arr,n);
		sc.close();
	}

}
