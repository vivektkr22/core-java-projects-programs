package Fab13;

import java.util.Scanner;

public class DisplayBoundryElementsInMatrix {
	
	public static void displayElements(int arr[][], int row, int column) {
	  for(int i=0; i<row; i++) {
		  for(int j=0; j<column; j++) {
			  if(i==0 || j==0 || i==row-1 || j==column-1) {
				  System.out.print(arr[i][j]+" ");
			  }
			  else {
				  System.out.print("  ");
			  }
		  }
		  System.out.println();
	  }
}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	    System.out.print("Enter row number: ");
	    int row = sc.nextInt();
	    System.out.print("Enter coloumn number: ");
	    int column = sc.nextInt();
	    
	    int arr[][] = new int[row][column];
	    
	    System.out.println("Enter elements in a matrix: ");
	    for(int i=0; i<row;  i++) {
	    	for(int j=0; j<column; j++) {
	    		arr[i][j] = sc.nextInt();
	    	}
	    }
	    
	    displayElements(arr,row,column);
	    sc.close();
	}

}
