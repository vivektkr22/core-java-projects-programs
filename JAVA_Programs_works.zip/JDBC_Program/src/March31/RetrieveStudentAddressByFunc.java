package March31;

import java.sql.*;

public class RetrieveStudentAddressByFunc {
    public static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    public static final String USERNAME = "naresh";
    public static final String PASSWORD = "root";

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
             CallableStatement cstmt = conn.prepareCall("{? = call getStudentAddress(?)}")) {
            int rollNo = 103;
            String address;

            cstmt.registerOutParameter(1, Types.VARCHAR);
            cstmt.setInt(2, rollNo);
            cstmt.execute();
            address = cstmt.getString(1);

            if (address != null) {
                System.out.println("Student's Address: " + address);
            } else {
                System.out.println("No address found for student with roll number " + rollNo);
            }
        } catch (SQLException se) {
           se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

