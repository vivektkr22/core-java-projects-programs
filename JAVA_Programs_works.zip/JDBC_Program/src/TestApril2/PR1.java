package TestApril2;

import java.sql.*;

public class PR1 {
    public static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    public static final String USERNAME = "naresh";
    public static final String PASSWORD = "root";

    public static void main(String[] args) throws Exception {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
             CallableStatement cstmt = conn.prepareCall("{? = call getEmployeeName(?)}")) {
            int empId = 333;
            String empName;

            cstmt.registerOutParameter(1, Types.VARCHAR);
            cstmt.setInt(2, empId);
            cstmt.execute();
            empName = cstmt.getString(1);

            System.out.println("Employee Name: " + empName);
 
        } 
    }
}

