package TestApril2;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class PR3 {

	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","naresh","root");
			Statement stm = conn.createStatement();
			ResultSet rs = stm.executeQuery("select * from player_info");
			rs.next();
			InputStream ip =  rs.getBinaryStream(3);
		
			try (FileOutputStream fos = new FileOutputStream("G:\\virat1.jpeg")) {
				while(ip.read()!=-1)
				{
					fos.write(ip.read());
				}
			}
				
			System.out.println("image Copied successfully..");
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
