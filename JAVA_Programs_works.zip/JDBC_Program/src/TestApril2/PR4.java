package TestApril2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class PR4 {

	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","naresh","root");
			
            Statement stmt = con.createStatement();
			
			stmt.addBatch("insert into employee_info values(10,'akash',35,16000.0)");
			stmt.addBatch("update employee_info set emp_salary = 25000.0 where emp_id = 10");
     		stmt.addBatch("delete from employee_info where emp_salary = (select min(emp_salary) from employee_info)");

			stmt.executeBatch();
			System.out.println("batch successfully executed");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
