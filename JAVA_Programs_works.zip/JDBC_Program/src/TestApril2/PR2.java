package TestApril2;

import java.io.FileInputStream;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class PR2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		try(sc)
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","naresh","root");
			PreparedStatement pstm = conn.prepareCall("insert into player_info values(?,?,?,?)");
		
			System.out.println("Enter Player id : ");
			int id = sc.nextInt(); pstm.setInt(1, id);
			
			System.out.println("Enter Player name : ");
			String name = sc.nextLine(); 
			name = sc.nextLine(); pstm.setString(2, name);
			
			System.out.println("Enter Player photo path : ");
			String path = sc.nextLine(); 
			   FileInputStream fin = new FileInputStream(path);
			    pstm.setBinaryStream(3, fin, fin.available());
			    pstm.setDate(4, null);
			
		    
			int n = pstm.executeUpdate();
			if(n>0)
				System.out.println("one record inserted successfully....");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
