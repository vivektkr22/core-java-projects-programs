package TestMArch27;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

public class Test {
	public static void main(String[] args) {
		try
		{
			Properties p = new Properties();
			FileReader fr = new FileReader("F:\\db.properties");
			p.load(fr);
			String uname = p.getProperty("user");
			String pass = p.getProperty("password");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",uname,pass);
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select *from product");
			while(rs.next()) {
				System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getDouble(3)+"\t"+rs.getInt(4));
				
			}
			System.out.println("\n All Record Retrieve successufully...!");

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
