package TestMArch27;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BookMain {
    public static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    public static final String USERNAME = "naresh";
    public static final String PASSWORD = "root";

    public static class Book {
        public int id;
        public String title;
        public String author;
        public int price;

        public Book(int id, String title, String author, int price) {
            this.id = id;
            this.title = title;
            this.author = author;
            this.price = price;
        }

        public int getId() {
            return id;
        }

        public String getTitle() {
            return title;
        }

        public String getAuthor() {
            return author;
        }

        public int getPrice() {
            return price;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        @Override
        public String toString() {
            return "Book [id=" + id + ", title=" + title + ", author=" + author + ", price=" + price + "]";
        }
    }

    // Method to process the title
    public static String processTitle(String title) {
        String[] words = title.split("\\s+");
        StringBuilder processedTitle = new StringBuilder();

        for (String word : words) {
            String reversedWord = new StringBuilder(word).reverse().toString();
            processedTitle.append(Character.toUpperCase(reversedWord.charAt(0)))
                          .append(reversedWord.substring(1, reversedWord.length() - 1))
                          .append(Character.toUpperCase(reversedWord.charAt(reversedWord.length() - 1)))
                          .append(" ");
        }

        return processedTitle.toString().trim();
    }

    public static void main(String[] args) throws SQLException {
        try (Connection con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);) {

            List<Book> books = new ArrayList<>();

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from books");

            while (rs.next()) {
                books.add(new Book(rs.getInt("ID"), rs.getString("TITLE"), rs.getString("AUTHOR"), rs.getInt("PRICE")));
            }

            // Process the books
            List<Book> processedBooks = books.stream()
                    .map(book -> {
                        book.setTitle(processTitle(book.getTitle()));
                        return book;
                    })
                    .collect(Collectors.toList());

            // Print processed books
            processedBooks.forEach(System.out::println);
        }
    }
}
