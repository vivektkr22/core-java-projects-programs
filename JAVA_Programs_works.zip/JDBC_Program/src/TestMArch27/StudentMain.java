package TestMArch27;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StudentMain {
    public static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    public static final String USERNAME = "naresh";
    public static final String PASSWORD = "root";
    
	static class Student{
		public int id;
		public String name;
		public int age;
		public String department;
		
		public Student(int id, String name, int age, String department) {
			super();
			this.id = id;
			this.name = name;
			this.age = age;
			this.department = department;
		}

		public int getId() {
			return id;
		}

		public String getName() {
			return name;
		}

		public int getAge() {
			return age;
		}

		public String getDepartment() {
			return department;
		}

		public void setId(int id) {
			this.id = id;
		}

		public void setName(String name) {
			this.name = name;
		}

		public void setAge(int age) {
			this.age = age;
		}

		public void setDepartment(String department) {
			this.department = department;
		}

		@Override
		public String toString() {
			return "Student [id=" + id + ", name=" + name + ", age=" + age + ", department=" + department + "]";
		}		
		
	}
	public static boolean isPalindrome(int age) {
          int t = age; int rev = 0;
          while(t!=0) {
        	  rev = rev*10 + t%10;
        	  t/=10;
          }
          if(age==rev) return true;
          else return false;
	}
	public static boolean isPalindrome(String name) {
           String str = "";
           for(int i=name.length()-1; i>=0; i--) {
        	   str+= name.charAt(i);
           }
            if(name.equals(str)) return true;
            else return false;
	}

	public static void main(String[] args) throws SQLException {
		try (Connection con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);) {
            List<Student> studentList = new ArrayList<>();

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from students");
              
            while(rs.next()) {
            	studentList.add(new Student(rs.getInt(1),rs.getString(2),rs.getInt(3), rs.getString(4)));
            }
            
            List<Student> filteredStudent = studentList.stream().filter(x -> isPalindrome(x.getAge()) && isPalindrome(x.getName())).collect(Collectors.toList());
            filteredStudent.forEach(System.out::println);
		}
	}

}
