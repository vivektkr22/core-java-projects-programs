package TestMArch27;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class OrderMain {
    public static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    public static final String USERNAME = "naresh";
    public static final String PASSWORD = "root";
    
    static class Order  {
    	public int id;
    	public String name;
    	public String date;
    	
		public Order(int id, String name, String date) {
			super();
			this.id = id;
			this.name = name;
			this.date = date;
		}

		public int getId() {
			return id;
		}

		public String getName() {
			return name;
		}

		public String getDate() {
			return date;
		}

		public void setId(int id) {
			this.id = id;
		}

		public void setName(String name) {
			this.name = name;
		}

		public void setDate(String date) {
			this.date = date;
		}

		@Override
		public String toString() {
			return "Order [id=" + id + ", name=" + name + ", date=" + date + "]";
		}

    }

	public static void main(String[] args) throws SQLException {
		try (Connection con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);) {
			
            List<Order> orderList = new ArrayList<>();
            
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from orders");
            
            
            
            while(rs.next()) {
            	orderList.add(new Order(rs.getInt(1), rs.getString(2), rs.getString(3)));
            }
            
            List<Order> top3IdsOrder = orderList.stream().sorted((a,b) -> Integer.compare(b.getId(), a.getId())).limit(3).collect(Collectors.toList());
            
            System.out.println(top3IdsOrder);
                 
		}
	}

}
