package TestMArch27;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FindPrimeProductPrice {
    public static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    public static final String USERNAME = "naresh";
    public static final String PASSWORD = "root";

    public static class Inventory {
        public int productId;
        public int qty;
        public int price;

        public Inventory(int productId, int qty, int price) {
            this.productId = productId;
            this.qty = qty;
            this.price = price;
        }

        public int getProductId() {
            return productId;
        }

        public int getQty() {
            return qty;
        }

        public int getPrice() {
            return price;
        }

        @Override
        public String toString() {
            return "Inventory [productId=" + productId + ", qty=" + qty + ", price=" + price + "]";
        }
    }

    public static boolean isPrime(int n) {

        for(int i=2; i*i<n; i++) {
        	if(n%i==0) return false;
        }
        return true;
    }

    public static void main(String[] args) throws SQLException {
        try (Connection con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);) {
            List<Inventory> inventoryList = new ArrayList<>();

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from product");

            while (rs.next()) {
                inventoryList.add(new Inventory(rs.getInt(1), rs.getInt(4), rs.getInt(3)));
            }

            List<Inventory> filteredInventory = inventoryList.stream()
                    .filter(x -> x.getPrice() >30000 && isPrime(x.getPrice()))
                    .collect(Collectors.toList());

            System.out.println("Prime price products b/w:  ");
            filteredInventory.forEach(System.out::println);
        }
    }
}
