package TestMArch27;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class ProductUpdate {
	public static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    public static final String USERNAME = "naresh";
    public static final String PASSWORD = "root";

    
      public static void main(String[] args) {
    	  try (Connection con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);){
    		  Statement stmt = con.createStatement();
    		  stmt.execute("update product set p_qty = 10 where p_id = 103");
              System.out.println("data updated successfully");
    	  } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
