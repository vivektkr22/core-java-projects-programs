package TestMArch27;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertBooksData {
	public static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    public static final String USERNAME = "naresh";
    public static final String PASSWORD = "root";
    static Scanner sc = new Scanner(System.in);
    
        public static void main(String[] args) {
        	 try (Connection con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);){
        		 PreparedStatement ps = con.prepareStatement("insert into books values(?,?,?,?)");
        		 System.out.print("Enter book id: ");
        		 int n = sc.nextInt(); ps.setInt(1, n);
        		 
        		 System.out.print("ENter book name: ");
        		 String name = sc.next(); ps.setString(2, name);
        		 
        		 System.out.print("ENter author");
        		 String author = sc.next(); ps.setString(3, author);
        		 
        		 System.out.print("Enter price: ");
        		 int price = sc.nextInt(); ps.setInt(4, price);
        		 
        		 ps.executeQuery();
        		 System.out.println("data inserted successfully");
        		 
        	 } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
}
