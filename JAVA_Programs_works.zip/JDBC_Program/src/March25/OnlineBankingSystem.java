package March25;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class OnlineBankingSystem {
    public static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    public static final String USERNAME = "naresh";
    public static final String PASSWORD = "root";

    public static Long senderAccount;
    public static Long receiverAccount;
    public static Long transferredAmount;

    public static Long getAccountBalance(Connection con, Long accNum) throws SQLException {
        try (PreparedStatement pstmt = con.prepareStatement("select balance from banking_system where acc_num = ?")) {
            pstmt.setLong(1, accNum);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getLong(1);
                }
                else System.err.print("Account not found");
            }
        }
		return 0l;        
    }

    public static void updateAccountBalance (Connection con, Long senderAccNum, Long receiverAccNum, Long transferAmount) throws SQLException {
    	
        try (PreparedStatement deductStmt = con.prepareStatement("update banking_system set balance = balance - ? where acc_num = ?");
        	PreparedStatement addStmt = con.prepareStatement("update banking_system set balance = balance + ? where acc_num = ?");){
                     deductStmt.setLong(1, transferAmount);
                     deductStmt.setLong(2, senderAccNum);
                     deductStmt.executeUpdate();
                     
                     try (PreparedStatement ps = con.prepareStatement("select * from banking_system where acc_num = ?")){
                    	 ps.setLong(1, receiverAccount);
                    	 ResultSet rs = ps.executeQuery();
                        if(rs.next()) {
                        	addStmt.setLong(1, transferAmount);
                            addStmt.setLong(2, receiverAccNum);
                            addStmt.executeUpdate();
                            con.commit();
                        System.out.println("Transaction successful");
                       }
                        else {
                        	System.err.print("Transaction failed: Invalid reciver's account number");
                            con.rollback();
                        }
        			}      

		} catch (Exception e) {
			e.printStackTrace();
		}        
    }

    public static void main(String[] args) {
        try (Connection con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);Scanner sc = new Scanner(System.in)){
        	
            con.setAutoCommit(false);            

            System.out.print("Enter the sender account number: ");
            senderAccount = sc.nextLong();

            System.out.print("Enter the receiver account number: ");
            receiverAccount = sc.nextLong();

            System.out.print("Enter the amount to transfer: ");
            transferredAmount = sc.nextLong();
            
            Long senderBal = getAccountBalance(con, senderAccount);

            if (transferredAmount <= 0) {
                System.out.println("Invalid amount");
                System.exit(0);
            }

            if (transferredAmount > senderBal) {
                System.out.println("Insufficient balance");
                System.exit(0);
            }
            updateAccountBalance (con, senderAccount, receiverAccount, transferredAmount);    
                
         }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
