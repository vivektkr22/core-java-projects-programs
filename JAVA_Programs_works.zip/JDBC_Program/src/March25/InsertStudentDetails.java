package March25;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertStudentDetails {
	 public static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
	 public static final String USERNAME = "naresh";
	 public static final String PASSWORD = "root";

	public static void main(String[] args) {
		try (Connection con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);Scanner sc = new Scanner(System.in)){
			CallableStatement cstmt = con.prepareCall("call insertStudentData(?,?,?,?,?,?,?,?,?)");
			
			System.out.print("Enter student id: ");
			Integer id = sc.nextInt(); cstmt.setInt(1, id);
			
			System.out.print("Enter student roll number: ");
			Integer rollNum = sc.nextInt(); cstmt.setInt(2, rollNum);
			
			System.out.print("Enter student name: ");
			String name = sc.nextLine(); name = sc.nextLine(); cstmt.setString(3, name);
			
			System.out.print("Enter student branch: ");
			String branch = sc.nextLine(); cstmt.setString(4, branch);
			
			System.out.print("Enter student home no: ");
			Integer homeNo = sc.nextInt(); cstmt.setInt(5, homeNo);
			
			System.out.print("Enter student city: ");
			String city = sc.next(); cstmt.setString(6, city);
			
			System.out.print("Enter student PIN Code: ");
			Integer pinCode = sc.nextInt(); cstmt.setInt(7, pinCode);
			
			System.out.print("Enter student mobile id: ");
			Integer MobId = sc.nextInt(); cstmt.setInt(8, MobId);
			
			System.out.print("Enter student phone number: ");
			String mobNum = sc.next(); cstmt.setString(9, mobNum);
			
			cstmt.executeUpdate();
            System.out.println("data inserted sucessfully");
            
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

}
