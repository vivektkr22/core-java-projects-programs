package March25;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class DisplayStudentsDetails {
    public static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    public static final String USERNAME = "naresh";
    public static final String PASSWORD = "root";

    public static void main(String[] args) {
        try (Connection con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
             Scanner sc = new Scanner(System.in)) {

            CallableStatement cstmt = con.prepareCall("{call GetStudentDetails(?, ?, ?, ?, ?, ?, ?, ?, ?)}");

            System.out.print("Enter student id: ");
            int studentId = sc.nextInt();
            cstmt.setInt(1, studentId);

            cstmt.registerOutParameter(2, java.sql.Types.NUMERIC); // roll_num
            cstmt.registerOutParameter(3, java.sql.Types.VARCHAR); // name
            cstmt.registerOutParameter(4, java.sql.Types.VARCHAR); // branch
            cstmt.registerOutParameter(5, java.sql.Types.NUMERIC); // home_no
            cstmt.registerOutParameter(6, java.sql.Types.VARCHAR); // city
            cstmt.registerOutParameter(7, java.sql.Types.NUMERIC); // pin_code
            cstmt.registerOutParameter(8, java.sql.Types.NUMERIC); // mid
            cstmt.registerOutParameter(9, java.sql.Types.VARCHAR); // ph_no

            cstmt.execute();

            // Fetch and display the output parameters
            int rollNum = cstmt.getInt(2);
            String name = cstmt.getString(3);
            String branch = cstmt.getString(4);
            int homeNo = cstmt.getInt(5);
            String city = cstmt.getString(6);
            int pinCode = cstmt.getInt(7);
            int mid = cstmt.getInt(8);
            String phNo = cstmt.getString(9);

            System.out.println("Roll Number: " + rollNum);
            System.out.println("Name: " + name);
            System.out.println("Branch: " + branch);
            System.out.println("Home No: " + homeNo);
            System.out.println("City: " + city);
            System.out.println("Pin Code: " + pinCode);
            System.out.println("Mid: " + mid);
            System.out.println("Phone Number: " + phNo);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
