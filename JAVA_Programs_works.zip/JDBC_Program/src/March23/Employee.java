package March23;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public class Employee {
     private Integer empId;
     private String empName;
     private Integer empAge;
     private Double empSalary;
     
 	private static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
 	private static final String USERNAME = "naresh";
 	private static final String PASSWORD = "root";
     
     
	public Employee(Integer empId, String empName, Integer empAge, Double empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empAge = empAge;
		this.empSalary = empSalary;
	}


	public Integer getEmpId() {
		return empId;
	}


	public String getEmpName() {
		return empName;
	}


	public Integer getEmpAge() {
		return empAge;
	}


	public Double getEmpSalary() {
		return empSalary;
	}


	@Override
	public String toString() {
		return "empId=" + empId + ", empName=" + empName + ", empAge=" + empAge + ", empSalary=" + empSalary;
	}
	
	public static void main(String[] args) {
		List<Employee> list = new ArrayList<Employee>();
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
			
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from employee_info");
			
			while(rs.next()) {
				list.add(new Employee(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getDouble(4)));
			}
			
			List<Employee> older25Employee = list.stream().filter(x -> x.getEmpAge()>25).collect(Collectors.toList());
			
			for(Employee e : older25Employee) {
				System.out.println(e);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
     
     
}



















