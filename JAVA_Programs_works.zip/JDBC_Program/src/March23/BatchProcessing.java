package March23;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class BatchProcessing {
 	private static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
 	private static final String USERNAME = "naresh";
 	private static final String PASSWORD = "root";
     
	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
			
			Statement stmt = con.createStatement();
			
			stmt.addBatch("insert into employee_info values(8,'rahul',33,11000.0)");
			stmt.addBatch("update employee_info set emp_salary = 25000.0 where emp_id = 1");
     		stmt.addBatch("delete from employee_info where emp_salary = (select max(emp_salary) from employee_info)");

			stmt.executeBatch();

		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
