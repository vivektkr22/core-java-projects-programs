package March22;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Scanner;

public class CustomerRegistrationLogin {
	private static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
	private static final String USERNAME = "naresh";
	private static final String PASSWORD = "root";
	static Scanner sc = new Scanner(System.in);

	public static void getCustomersDetails(Connection con) {
		while(true) {
			try {
				Statement stmt = con.createStatement();
				PreparedStatement pstmt;
				ResultSet rs;
				ResultSetMetaData rsm;
				int c;
				
				System.out.println("1. Show all customers");
				System.out.println("2. Update mail ID & phone number based on ID");
				System.out.println("3. Delete customers whose name starts with ");
				System.out.println("4. Show those customers whose ID is even");
				System.out.println("5. do you want to exit");

				int choice = sc.nextInt();

				switch (choice){
				case 1:
					 rs = stmt.executeQuery("SELECT * FROM customers");
						rsm = rs.getMetaData();
						int n = rsm.getColumnCount();
						for (int i = 1; i <= n; i++) {
							System.out.print(rsm.getColumnName(i) + "\t");
						}
						while (rs.next()) {
							System.out.println("\n" + rs.getInt(1) + "\t" + rs.getString(2) + "\t" + rs.getString(3)
									+ "\t" + rs.getString(4) + "\t" + rs.getString(5) + "\t" + rs.getString(6) + "\t"
									+ rs.getString(7));
						}
					break;
					
				case 2:
					pstmt = con.prepareStatement("update customers set mailId = ?, phoneNo = ? where customerId = ? ");
					PreparedStatement ps = con.prepareStatement("select * from customers where cutomerId=?");
					
					System.out.print("Enter customerId: ");
					int customerId = sc.nextInt();
					
					ps.setInt(1, customerId);
					rs = ps.executeQuery();
					
					if(rs.next()) {
						System.out.print("Enter new mailId: ");
						String mailId = sc.next();
						System.out.print("Enter phone number: ");
						String phoneNo = sc.next();
						
						pstmt.setString(1, mailId);
						pstmt.setString(2, phoneNo);
						pstmt.setInt(3, customerId);
						
					    c = pstmt.executeUpdate();
					    
					    if(c>0) {
							System.out.println("data updated successfully");
						}
						else {
							System.out.println("data not updated");
						}
					}
					else System.out.println("Invalid cutomerId");
					break;
				case 3:
					pstmt = con.prepareStatement("DELETE FROM customers WHERE customerName LIKE ?");
					System.out.print("Enter the starting charactor of name which want to delete: ");
					String s = sc.next();
					pstmt.setString(1, s+='%');
					
					 c = pstmt.executeUpdate(); 
					
					if(c>0) System.out.println("data deleted successfully");
					else System.out.println("data deletion failed");
					break;
					
				case 4:
					 rs = stmt.executeQuery("SELECT * FROM customers WHERE mod(customerId,2) = 0");
					if (rs.next()) {
						 rsm = rs.getMetaData();
						 n = rsm.getColumnCount();
						for (int i = 1; i <= n; i++) {
							System.out.print(rsm.getColumnName(i) + "\t");
						}
						while (rs.next()) {
							System.out.println("\n" + rs.getInt(1) + "\t" + rs.getString(2) + "\t" + rs.getString(3)
									+ "\t" + rs.getString(4) + "\t" + rs.getString(5) + "\t" + rs.getString(6)
									+ "\t" + rs.getString(7));
						   }
					     } 
					else {
						System.out.println("No such record found");
					}
					break;
				
				case 5:
					System.out.println("Thank you for visiting us...");
					System.exit(0);
				
				default:
					System.out.println("Invalid choice");
				
			}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void getRegister(Connection con) {
		try {
		PreparedStatement pstmt = con.prepareStatement("insert into customers values(?,?,?,?,?,?,?)");
		System.out.println("Going for registration");
		System.out.print("Enter customer id: ");
		int customerId = sc.nextInt();
		System.out.print("Enter customer name: ");
		String customerName = sc.nextLine();
		customerName = sc.nextLine();
		System.out.print("Enter customer password: ");
		String password = sc.next();
		System.out.print("Enter customer first name: ");
		String fName = sc.next();
		System.out.print("Enter customer last name: ");
		String lName = sc.next();
		System.out.print("Enter customer mailId: ");
		String mailId = sc.next();
		System.out.print("Enter customer phone number: ");
		String phoneNo = sc.next();

		
			pstmt.setInt(1, customerId);
			pstmt.setString(2, customerName);
			pstmt.setString(3, password);
			pstmt.setString(4, fName);
			pstmt.setString(5, lName);
			pstmt.setString(6, mailId);
			pstmt.setString(7, phoneNo);

			int c = pstmt.executeUpdate();
			if (c > 0) {
				System.out.println("registration successfull");
				getCustomersDetails(con);
			}							
			else
				System.out.println("failed");
		} catch (Exception e) {
			System.out.println("Registration failed");
		}
	}

	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);

			while(true) {
				System.out.print("1. Login/n 2. Registration: ");
				int choice = sc.nextInt();

				if (choice == 1) {
					PreparedStatement pstmt1 = con
							.prepareStatement("SELECT * FROM customers WHERE phoneNo = ? AND password = ?");
					System.out.print("Enter Phone number: ");
					String phoneNo = sc.next();
					System.out.print("Enter password:");
					String password = sc.next();

					pstmt1.setString(1, phoneNo);
					pstmt1.setString(2, password);

					ResultSet rs = pstmt1.executeQuery();

					if (rs.next()) {
						getCustomersDetails(con);
					} else {
						System.out.println("Invalid Credentials");
					}
				} else if (choice == 2) {
					getRegister(con);
				}
				else if(choice==3) {
					System.out.println("exiting the program");
					System.exit(0);
				}
				else {
					System.out.println("Invalid choice");
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
