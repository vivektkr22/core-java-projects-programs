package March30;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Program2_1 {
	public static void main(String[] args) {
		Scanner sc =  new Scanner(System.in);
		try(sc)
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","naresh","root");
			PreparedStatement pstm = conn.prepareStatement("insert into student_info values(?,?,?,?,sysdate)");

			System.out.println("Enter Student id");
			int id = sc.nextInt();
			System.out.println("Enter Student name");
			String name = sc.nextLine();
			name = sc.nextLine();
			System.out.println("Enter Student rollno");
			String rollno = sc.nextLine();
			System.out.println("Enter Student address");
			String address = sc.nextLine();
			
			
			pstm.setInt(1, id);
			pstm.setString(2, name);
			pstm.setString(3, rollno);
			pstm.setString(4, address);
			
			int n = pstm.executeUpdate();
			if(n>0)
				System.out.println("record inserted successfully...");
	     	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}