package March30;

import java.sql.Statement;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class Program3 {
	public static void main(String[] args) {
		try
		{
			FileReader reader = new FileReader("F:\\db.properties");
			Properties p = new Properties();
			p.load(reader);
			String JDBC_URL = p.getProperty("jdbc.url");
			String user_name = p.getProperty("jdbc.username"); 
			String password = p.getProperty("jdbc.password");
			String table_name = p.getProperty("table_name");
			String column1 = p.getProperty("column1");
			String column2 = p.getProperty("column2");
			String column3 = p.getProperty("column3");
			String column4 = p.getProperty("column4");
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection(JDBC_URL,user_name,password);
			Statement stm = conn.createStatement();
			stm.execute("create table "+table_name+"("+column1+","+column2+","+column3+","+column4+")");
			System.out.println("Table created successfully...");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}
}