package March30;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

public class Program2 {
	public static void main(String[] args) {
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","naresh","root");
			Statement stm = conn.createStatement();
			ResultSet rs = stm.executeQuery("select *from student_info");
			ResultSetMetaData rm = rs.getMetaData();
			int n = rm.getColumnCount();
			System.out.println("No.of columns = "+n);
			for(int i=1;i<=n;i++)
			{
				System.out.print(rm.getColumnName(i)+" - "+rm.getColumnTypeName(i));
				System.out.println();
			}
			System.out.println();
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}