package March30;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Program3_1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		try(sc)
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","naresh","root");
			PreparedStatement pstm = conn.prepareCall("insert into player_info values(?,?,?,?)");
		
			System.out.println("Enter Player id : ");
			int id = sc.nextInt(); pstm.setInt(1, id);
			
			System.out.println("Enter Player name : ");
			String name = sc.nextLine(); 
			name = sc.nextLine(); pstm.setString(2, name);
			
			System.out.println("Enter Player photo path : ");
			String path = sc.nextLine();
			
			System.out.println("Enter Player DOB (dd-MM-yyyy): ");
			String date = sc.nextLine();
			SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date date2 = format.parse(date);
		    long time = date2.getTime();
		    java.sql.Date date3 =  new Date(time);
		    
		    
		    FileInputStream fin = new FileInputStream(path);
		    pstm.setBinaryStream(3, fin, fin.available());
		    pstm.setDate(4, date3);
		    
			int n = pstm.executeUpdate();
			if(n>0)
				System.out.println("one record inserted successfully....");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
