package March21;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class LoginOperation {
	
	private static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
	private static final String USERNAME = "system";
	private static final String PASSWORD = "root";


	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);

            PreparedStatement pstmt = con.prepareStatement("select * from login_details where user_name = ? and password = ?");
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter User name: ");
            String userName = sc.next();
            System.out.print("Enter password:");
            String password = sc.next();
            
            pstmt.setString(1, userName);
            pstmt.setString(2, password);
            
			ResultSet rs = pstmt.executeQuery();
			
		    if (rs.next()) {
                System.out.println("Login Successful");
            } else {
                System.out.println("Invalid user");          
            }
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}

	}

}
