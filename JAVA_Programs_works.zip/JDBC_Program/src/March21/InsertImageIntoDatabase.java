package March21;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertImageIntoDatabase {
    public static void main(String[] args) {
        // Database connection parameters
        String jdbcUrl = "jdbc:oracle:thin:@localhost:1521:xe";
        String username = "naresh";
        String password = "root";

        // Image file path
        String imagePath = "C:\\Users\\USER\\Desktop\\abc\\images\\img1.jpg";

        try {
            // Load the Oracle JDBC driver
            Class.forName("oracle.jdbc.driver.OracleDriver");

            // Establish connection
            Connection connection = DriverManager.getConnection(jdbcUrl, username, password);

            // Prepare SQL statement to insert image
            String sql = "INSERT INTO images (image_data) VALUES (?)";
            PreparedStatement statement = connection.prepareStatement(sql);

            // Read the image file into a byte array
            File imageFile = new File(imagePath);
            InputStream inputStream = new FileInputStream(imageFile);
            statement.setBinaryStream(1, inputStream, (int) imageFile.length());

            // Execute the statement
            statement.executeUpdate();

            // Close resources
            inputStream.close();
            statement.close();
            connection.close();

            System.out.println("Image inserted successfully!");
        } catch (ClassNotFoundException e) {
            System.out.println("Oracle JDBC Driver not found!");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Database connection error!");
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            System.out.println("Image file not found!");
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println("Error occurred!");
            e.printStackTrace();
        }
    }
}
