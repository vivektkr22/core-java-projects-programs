/**
 * 
 */
/**
 * 
 */
module JDBC_Program {
	requires java.sql;
}