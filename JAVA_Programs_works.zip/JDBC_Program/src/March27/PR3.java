package March27;

public class PR3 {

	public static void main(String[] args) {
		

	}

}
