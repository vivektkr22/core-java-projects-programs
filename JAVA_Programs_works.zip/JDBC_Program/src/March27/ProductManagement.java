package March27;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ProductManagement {
	public static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    public static final String USERNAME = "naresh";
    public static final String PASSWORD = "root";
    static Scanner sc = new Scanner(System.in);
    
    public static void insertProductData(Connection con) {
    	try(PreparedStatement pstmt = con.prepareStatement("insert into product values(?,?,?,?)")) {
			
			System.out.print("Enter product id: ");
			Integer p_id = sc.nextInt();
		    pstmt.setInt(1, p_id);
			System.out.print("Enter product name: ");
			String p_name = sc.next();
		    pstmt.setString(2, p_name);
			System.out.print("Enter product price: ");
			Double p_price = sc.nextDouble();
		    pstmt.setDouble(3, p_price);
			System.out.print("Enter product quantity: ");
			int p_qty = sc.nextInt();
		    pstmt.setInt(4, p_qty);
		    
		    pstmt.executeUpdate();
    	} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public static void retrieveProductDataForwardDirection(Connection con) {
    	try(Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);){
    		ResultSet rs = stmt.executeQuery("select * from product");
    		System.out.println("Retrieve data in Forward direction ");
    		while(rs.next()) {
    			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getDouble(3)+" "+rs.getInt(4));
    		}
    	}
    	catch(SQLException e) {
    		e.printStackTrace();
    	}
    }
    
    public static void retrieveProductDataReverseDirection(Connection con) {
    	try(Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);){
    		ResultSet rs = stmt.executeQuery("select * from product");
    		rs.afterLast();
    		System.out.println();
    		System.out.println("Retrieve data in Backward direction ");
    		while(rs.previous()) {
    			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getDouble(3)+" "+rs.getInt(4));
    		}
    	}
    	catch(SQLException e) {
    		e.printStackTrace();
    	}
    }
    
    public static void retrieve3RdRecordFromTop(Connection con) {
    	try(Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);){
    		ResultSet rs = stmt.executeQuery("select * from product");
    		rs.absolute(3);
    		System.out.println();
    		System.out.println("Retrieve third data from top");
    			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getDouble(3)+" "+rs.getInt(4));
    	}
    	catch(SQLException e) {
    		e.printStackTrace();
    	}
    }
    
    public static void retrieve3RdRecordFromBottom(Connection con) {
    	try(Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);){
    		ResultSet rs = stmt.executeQuery("select * from product");
    		rs.absolute(-3);
    		System.out.println();
    		System.out.println("Retrieve third data from bottom");
    			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getDouble(3)+" "+rs.getInt(4));
    	}
    	catch(SQLException e) {
    		e.printStackTrace();
    	}
    }

	public static void main(String[] args) {
	    try (Connection con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);){
	    	
	    	while (true) {
	    		System.out.println("1.Insert productdetails into product table.\r\n"
		    			+ "2.Retrieve productdetails in forward direction.\r\n"
		    			+ "3.Retrieve productdetails in reverse direction.\r\n"
		    			+ "4.Retrieve 3rd record from top.\r\n"
		    			+ "5.Retrieve 3rd record from bottom. ");
		    	int c = sc.nextInt();
		    	System.out.println("------------------------------------------------");
		    	switch (c) {
				case 1: insertProductData(con); break;
				case 2: retrieveProductDataForwardDirection(con); break;
				case 3: retrieveProductDataReverseDirection(con); break;
				case 4: retrieve3RdRecordFromTop(con); break;
				case 5: retrieve3RdRecordFromBottom(con); break;
				case 6: System.exit(0); System.out.print("System closed...");
				default: System.out.print("wrong input");
				}
		    	System.out.println("-----------------------------------------------");
			}
	    	
	    	
	    }
	    catch(SQLException e) {
	    	e.printStackTrace();
	    }

	}

}
