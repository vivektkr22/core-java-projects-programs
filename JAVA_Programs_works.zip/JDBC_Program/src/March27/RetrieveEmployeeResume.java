package March27;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class RetrieveEmployeeResume {

	public static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    public static final String USERNAME = "naresh";
    public static final String PASSWORD = "root";
    static Scanner sc = new Scanner(System.in);
    
    public static void retrieveAndSaveResume(Connection connection, String empPhNo) throws SQLException, IOException {
        String s = "select* from emp_info where phone_no = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(s)) {
            preparedStatement.setString(1, empPhNo);
            try (ResultSet rs = preparedStatement.executeQuery()) {
            	rs.next();
    			InputStream fin = rs.getBinaryStream(6);
    				
    		    try (FileOutputStream fos = new FileOutputStream("F:\\ResumeCopy.txt")) {
					while(fin.read()!=-1)
					{
						fos.write(fin.read());
					}
				}
    				
    			System.out.println("File Copied successfully..");

            }
        }
    }
    
    public static void main(String[] args) {
    	try (Connection con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);){
            String empPhNo = "123456789"; 
            retrieveAndSaveResume(con, empPhNo);
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
    }


}

