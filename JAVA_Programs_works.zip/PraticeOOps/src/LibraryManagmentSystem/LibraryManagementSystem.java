package LibraryManagmentSystem;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Book {
    private String title;
    private String author;
    private String year;

    public Book(String title, String author, String year) {
        this.title = title;
        this.author = author;
        this.year = year;
    }

    public void displayInfo() {
        System.out.println("Title: " + title + ", Author: " + author + ", Year: " + year);
    }

    @Override
    public String toString() {
        return "Title: " + title + ", Author: " + author + ", Year: " + year;
    }
}

class ReferenceBook extends Book {
    private int edition;

    public ReferenceBook(String title, String author, String year, int edition) {
        super(title, author, year);
        this.edition = edition;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Edition: " + edition);
    }
}

class Library {
    private List<Book> books;

    public Library() {
        this.books = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
        System.out.println("Book added successfully!");
    }

    public void removeBook(String title) {
        books.removeIf(book -> book.toString().contains(title));
        System.out.println("Book removed successfully!");
    }

    public void displayAllBooks() {
        if (books.isEmpty()) {
            System.out.println("No books in the library.");
        } else {
            System.out.println("All Books in the Library:");
            for (Book book : books) {
                book.displayInfo();
            }
        }
    }

    public Book findBookByTitle(String title) {
        for (Book book : books) {
            if (book instanceof ReferenceBook && book.toString().contains(title)) {
                return book;
            } else if (book.toString().contains(title)) {
                return book;
            }
        }
        return null;
    }
}

public class LibraryManagementSystem {
    public static void main(String[] args) {
        Library library = new Library();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nLibrary Management System");
            System.out.println("1. Add Book");
            System.out.println("2. Remove Book");
            System.out.println("3. Display All Books");
            System.out.println("4. Search for a Book");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume the newline

            switch (choice) {
                case 1:
                    System.out.print("Enter the title of the book: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter the author of the book: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter the publication year of the book: ");
                    String year = scanner.nextLine();

                    System.out.print("Is it a reference book? (yes/no): ");
                    String isReferenceBook = scanner.nextLine();
                    if ("yes".equalsIgnoreCase(isReferenceBook)) {
                        System.out.print("Enter the edition of the reference book: ");
                        int edition = scanner.nextInt();
                        library.addBook(new ReferenceBook(title, author, year, edition));
                    } else {
                        library.addBook(new Book(title, author, year));
                    }
                    break;

                case 2:
                    System.out.print("Enter the title of the book to remove: ");
                    String removeTitle = scanner.nextLine();
                    library.removeBook(removeTitle);
                    break;

                case 3:
                    library.displayAllBooks();
                    break;

                case 4:
                    System.out.print("Enter the title of the book to search: ");
                    String searchTitle = scanner.nextLine();
                    Book foundBook = library.findBookByTitle(searchTitle);

                    if (foundBook != null) {
                        System.out.println("Book found:");
                        foundBook.displayInfo();
                    } else {
                        System.out.println("Book not found.");
                    }
                    break;

                case 5:
                    System.out.println("Exiting the Library Management System. Goodbye!");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }
}

