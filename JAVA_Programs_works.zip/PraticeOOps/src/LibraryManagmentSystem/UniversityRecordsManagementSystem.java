/* 1. Semester Class:
Variables:
int semesterNumber: Represents the semester number.
List<String> enrolledCourses: Stores the course codes the student is enrolled in for the particular semester.
Methods:
Semester(int semesterNumber): Constructor to initialize the semester with a given semester number.
int getSemesterNumber(): Getter method to retrieve the semester number.
void enrollInCourse(String courseCode): Method to enroll the student in a course for the current semester.
List<String> getEnrolledCourses(): Getter method to retrieve the list of enrolled courses.
2. Student Class:
Variables:
String studentId: Represents the unique identifier for a student.
String name: Stores the name of the student.
Map<Integer, Semester> semesters: A map where the key is the semester number, and the value is the corresponding Semester object.
Methods:
Student(String studentId, String name): Constructor to initialize a student with a given student ID and name.
String getStudentId(): Getter method to retrieve the student ID.
void enrollInCourse(int semesterNumber, String courseCode): Method to enroll the student in a course for a specific semester.
void displayInfo(): Method to display detailed information about the student, including their enrolled courses for each semester.
3. Course Class:
Variables:
String courseCode: Represents the unique identifier for a course.
String courseName: Stores the name of the course.
Methods:
Course(String courseCode, String courseName): Constructor to initialize a course with a given course code and name.
String getCourseCode(): Getter method to retrieve the course code.
void displayInfo(): Method to display detailed information about the course.
4. UniversityRecordsManager Class:
Variables:
List<Student> students: A list to store instances of the Student class.
List<Course> courses: A list to store instances of the Course class.
Methods:
void addStudent(String studentId, String name): Method to add a new student to the system.
void enrollStudentInCourse(String studentId, int semesterNumber, String courseCode): Method to enroll a student in a course for a specific semester.
void addCourse(String courseCode, String courseName): Method to add a new course to the system.
void displayAllStudents(): Method to display information about all students, including their enrolled courses and semesters.
void displayAllCourses(): Method to display information about all courses. */


package LibraryManagmentSystem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

class Semester {
    private int semesterNumber;
    private List<String> enrolledCourses;

    public Semester(int semesterNumber) {
        this.semesterNumber = semesterNumber;
        this.enrolledCourses = new ArrayList<>();
    }

    public int getSemesterNumber() {
        return semesterNumber;
    }

    public void enrollInCourse(String courseCode) {
        enrolledCourses.add(courseCode);
        System.out.println("Enrolled in course " + courseCode + " for Semester " + semesterNumber);
    }

    public List<String> getEnrolledCourses() {
        return enrolledCourses;
    }
}

class Student {
    private String studentId;
    private String name;
    private Map<Integer, Semester> semesters;

    public Student(String studentId, String name) {
        this.studentId = studentId;
        this.name = name;
        this.semesters = new HashMap<>();
    }

    public String getStudentId() {
        return studentId;
    }

    public void enrollInCourse(int semesterNumber, String courseCode) {
        semesters.computeIfAbsent(semesterNumber, Semester::new).enrollInCourse(courseCode);
    }

    public void displayInfo() {
        System.out.println("Student ID: " + studentId + " | Name: " + name);
        System.out.println("Semesters and Enrolled Courses:");
        for (Map.Entry<Integer, Semester> entry : semesters.entrySet()) {
            System.out.println("Semester " + entry.getKey() + ": " + entry.getValue().getEnrolledCourses());
        }
    }
}

class Course {
    private String courseCode;
    private String courseName;

    public Course(String courseCode, String courseName) {
        this.courseCode = courseCode;
        this.courseName = courseName;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void displayInfo() {
        System.out.println("Course Code: " + courseCode + " | Course Name: " + courseName);
    }
}

class UniversityRecordsManager {
    private List<Student> students;
    private List<Course> courses;

    public UniversityRecordsManager() {
        this.students = new ArrayList<>();
        this.courses = new ArrayList<>();
    }

    public void addStudent(String studentId, String name) {
        students.add(new Student(studentId, name));
        System.out.println("Student added successfully!");
    }

    public void enrollStudentInCourse(String studentId, int semesterNumber, String courseCode) {
        Student student = findStudentById(studentId);
        Course course = findCourseByCode(courseCode);

        if (student != null && course != null) {
            student.enrollInCourse(semesterNumber, courseCode);
        } else {
            System.out.println("Student or course not found.");
        }
    }

    public void addCourse(String courseCode, String courseName) {
        courses.add(new Course(courseCode, courseName));
        System.out.println("Course added successfully!");
    }

    public void displayAllStudents() {
        if (students.isEmpty()) {
            System.out.println("No students in the system.");
        } else {
            System.out.println("All Students:");
            for (Student student : students) {
                student.displayInfo();
                System.out.println();
            }
        }
    }

    public void displayAllCourses() {
        if (courses.isEmpty()) {
            System.out.println("No courses in the system.");
        } else {
            System.out.println("All Courses:");
            for (Course course : courses) {
                course.displayInfo();
                System.out.println();
            }
        }
    }

    private Student findStudentById(String studentId) {
        for (Student student : students) {
            if (student.getStudentId().equals(studentId)) {
                return student;
            }
        }
        return null;
    }

    private Course findCourseByCode(String courseCode) {
        for (Course course : courses) {
            if (course.getCourseCode().equals(courseCode)) {
                return course;
            }
        }
        return null;
    }
}

public class UniversityRecordsManagementSystem {
    public static void main(String[] args) {
        UniversityRecordsManager recordsManager = new UniversityRecordsManager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nUniversity Records Management System");
            System.out.println("1. Add Student");
            System.out.println("2. Enroll Student in Course");
            System.out.println("3. Add Course");
            System.out.println("4. Display All Students");
            System.out.println("5. Display All Courses");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume the newline

            switch (choice) {
                case 1:
                    System.out.print("Enter student ID: ");
                    String studentId = scanner.nextLine();
                    System.out.print("Enter student name: ");
                    String studentName = scanner.nextLine();
                    recordsManager.addStudent(studentId, studentName);
                    break;

                case 2:
                    System.out.print("Enter student ID: ");
                    String enrollStudentId = scanner.nextLine();
                    System.out.print("Enter semester number: ");
                    int semesterNumber = scanner.nextInt();
                    scanner.nextLine(); // consume the newline
                    System.out.print("Enter course code: ");
                    String courseCode = scanner.nextLine();
                    recordsManager.enrollStudentInCourse(enrollStudentId, semesterNumber, courseCode);
                    break;

                case 3:
                    System.out.print("Enter course code: ");
                    String courseCodeToAdd = scanner.nextLine();
                    System.out.print("Enter course name: ");
                    String courseName = scanner.nextLine();
                    recordsManager.addCourse(courseCodeToAdd, courseName);
                    break;

                case 4:
                    recordsManager.displayAllStudents();
                    break;

                case 5:
                    recordsManager.displayAllCourses();
                    break;

                case 6:
                    System.out.println("Exiting the University Records Management System. Goodbye!");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }
}
