package tax_util;

public class ClassObject {

	public static void main(String[] args) 
	{
	  Employee employee = new Employee(1, "Raj", 40000, 3500, 2000);
	  
	  Manager manager = new Manager(2, "Virat", 80000, 10000, 4000, 3500);
	  Trainer trainer = new Trainer(3, "Rohit", 120000, 2000, 1500, 1200, 2000);
	  
	  Sourcing sourcing = new Sourcing(4,"Bumrah", 30000, 3000, 2200, 100, 80, 350);
	  
	  TaxUtil tax = new TaxUtil();
	  double totalTax = tax.calculateTax(employee);
	  System.out.println("Tax amount for Employee :"+totalTax);
	  
	  totalTax =  tax.calculateTax(manager);
	  System.out.println("Tax amount for Manager :"+totalTax);
	  
	  totalTax =  tax.calculateTax(trainer);
	  System.out.println("Tax amount for Trainer :"+totalTax);
	  
	  totalTax =  tax.calculateTax(sourcing);
	  System.out.println("Tax amount for Sourcing :"+totalTax);

	}
}