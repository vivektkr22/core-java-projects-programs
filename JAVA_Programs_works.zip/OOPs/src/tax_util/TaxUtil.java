package tax_util;

public class TaxUtil 
{
   public double calculateTax(Employee e1)  // e1 = employee
   {
	  if(e1.calculateGrossSalary() >=50000)
	  {
		  return e1.calculateGrossSalary()*0.20;
	  }
	  else
	  {
		  return e1.calculateGrossSalary()*0.05;
	  }
   }
   
   public double calculateTax(Manager m1)
   {
	   if(m1.calculateGrossSalary() >=50000)
		  {
			  return m1.calculateGrossSalary()*0.20;
		  }
		  else
		  {
			  return m1.calculateGrossSalary()*0.05;
		  }
   }
   
   public double calculateTax(Trainer t1)
   {
	   if(t1.calculateGrossSalary() >=50000)
		  {
			  return t1.calculateGrossSalary()*0.20;
		  }
		  else
		  {
			  return t1.calculateGrossSalary()*0.05;
		  }
   }
   
   public double calculateTax(Sourcing s1)
   {
	   if(s1.calculateGrossSalary() >=50000)
		  {
			  return s1.calculateGrossSalary()*0.20;
		  }
		  else
		  {
			  return s1.calculateGrossSalary()*0.05;
		  }
   }
}
