package tax_util;

public class Sourcing 
{
	int sourcingId;
    String sourcingName;
    double basicSalary;
    double HRAPer;
    double DAPer;
    int enrollmentTarget;
    int enrollmentReached;
    double perkPerEnrollment;
    
	public Sourcing(int sourcingId, String sourcingName, double basicSalary, double hRAPer, double dAPer,
			int enrollmentTarget, int enrollmentReached, double perkPerEnrollment) {
		super();
		this.sourcingId = sourcingId;
		this.sourcingName = sourcingName;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DAPer = dAPer;
		this.enrollmentTarget = enrollmentTarget;
		this.enrollmentReached = enrollmentReached;
		this.perkPerEnrollment = perkPerEnrollment;
	}
    
	public double calculateGrossSalary()
	{
		return basicSalary + HRAPer +DAPer +((enrollmentReached/enrollmentTarget)*100)*perkPerEnrollment;
	}   
    
    
    
}
