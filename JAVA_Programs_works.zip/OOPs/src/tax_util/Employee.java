package tax_util;

public class Employee 
{
    int employeeId;
    String employeeName;
    double basicSalary;
    double HRAPer;
    double DAPer;
    
	public Employee(int employeeId, String employeeName, double basicSalary, double hRAPer, double dAPer) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DAPer = dAPer;
	}
    
	public double calculateGrossSalary()
	{
		return basicSalary +HRAPer +DAPer;
	}   
   
}
