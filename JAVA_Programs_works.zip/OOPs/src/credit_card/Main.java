package credit_card;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Customer Name :");
		String name = sc.nextLine();
		System.out.print("Enter Customer credit points :");
		int creditPoint = sc.nextInt();
		
		Customer c1 = new Customer(creditPoint, name);
		
		CardType offeredCard = CardsOnOffer.getOfferedCard(c1);
        System.out.println(offeredCard);
        sc.close();
	}

}
