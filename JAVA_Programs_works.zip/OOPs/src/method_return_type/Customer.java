package method_return_type;

	import java.util.Date;
	import java.util.Scanner;

	public class Customer 
	{
	   private Integer customerId;
	   private String customerName;
	   private Double customerBill;
	   private Date dateOfJoining;  //HAS-A Relation
	   
	   public Customer(Integer customerId, String customerName, Double customerBill, Date dateOfJoining) 
		{
			super();
			this.customerId = customerId;
			this.customerName = customerName;
			this.customerBill = customerBill;
			this.dateOfJoining = dateOfJoining;
		}
	   
	   public static Customer getCustomerObject()
	   {
		   Scanner sc = new Scanner(System.in);
		   System.out.print("Enter Customer Id :");
		   int cid = sc.nextInt();
		   System.out.print("Enter Customer Name :");
		   String cName = sc.nextLine();
		   cName = sc.nextLine();
		   System.out.print("Enter Customer Bill :");
		   double cBill = sc.nextDouble();
		   
		   Date d1 = new Date();
		   
		   Customer c = new Customer(cid, cName, cBill, d1);
		   return c;
	   }

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerBill=" + customerBill
				+ ", dateOfJoining=" + dateOfJoining + "]";
	}
	   

}
