package object_reference;

public class ELC {

	public static void main(String[] args)
	{
		Player p1 = new Player("Rohit", "Virat");
		System.out.println(p1);
		
		System.out.println("................");
		
		Player p2 = new Player(p1);
		System.out.println(p2);
		

	}

}