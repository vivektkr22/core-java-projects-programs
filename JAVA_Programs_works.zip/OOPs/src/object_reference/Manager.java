package object_reference;

public class Manager 
{
   private int managerId;
   private String managerName;
   
   public Manager(Employee emp) //emp = e1
   {
	   managerId = emp.getEmployeeNumber();
	   managerName = emp.getEmployeeName();
   }

@Override
public String toString() {
	return "Manager [managerId=" + managerId + ", managerName=" + managerName + "]";
}
   
   
}
