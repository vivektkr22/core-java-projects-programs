package object_reference;

public class PassingObjectReference {

	public static void main(String[] args)
	{
		Employee e1 = new Employee(111, "Raj");
		
		Manager m1 = new Manager(e1);
		System.out.println(m1);

	}

}
