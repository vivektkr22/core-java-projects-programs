package object_reference;

public class Employee 
{
   private int employeeNumber;  //111
   private String employeeName; //Raj
   
	public Employee(int employeeNumber, String employeeName) 
	{
		super();
		this.employeeNumber = employeeNumber;
		this.employeeName = employeeName;
	}
	
	

	public int getEmployeeNumber() {
		return employeeNumber;
	}



	public String getEmployeeName() {
		return employeeName;
	}



	@Override
	public String toString() 
	{
		return "Employee [employeeNumber=" + employeeNumber + ", employeeName=" + employeeName + "]";
	}   
}
