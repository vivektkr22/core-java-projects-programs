package Constructor;

public class Person 
{
  private int personId;
  private String personName;
  
  public Person()
  {
	  super();
	  personId = 111;
	  personName = "Ravi";
  }

	@Override
	public String toString() {
		return "Person [personId=" + personId + ", personName=" + personName + "]";
	}
  
  
  
}