package Constructor;

public class Student 
{
   private int roll;
   
   public int getData()
   {
	   return this.roll;
   }
   
	public static void main(String[] args) 
	{
		int data = new Student().getData();
		System.out.println(data);
	}
}
