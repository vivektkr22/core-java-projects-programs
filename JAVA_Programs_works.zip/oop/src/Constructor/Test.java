package Constructor;

public class Test
{
    int x, y;

public Test() //No argument constructor, written by the user
{
   x = 100;
   y = 200;
}
}
