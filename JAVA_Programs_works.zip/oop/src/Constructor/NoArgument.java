package Constructor;

public class NoArgument 
{
	public static void main(String[] args) 
	{
		Person ravi = new Person();
		System.out.println(ravi);		
		
		Person raj = new Person();
		System.out.println(raj);
		
		Person priya = new Person();
		System.out.println(priya);

	}

}
