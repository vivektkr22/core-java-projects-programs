package ClassObject;

public class Student 
{
	String regNo;
	String name;
	
	public void talk()
	{
		System.out.println("My Registration no is :"+regNo);
		System.out.println("My Name is :"+name);
	}
	
	public String writeExam()
	{
		return "My name is :"+name+" and every Saturday I am writing Java exam";
	}
	
	public static void main(String[] args) 
	{	
       Student raj = new Student();
       //Initializing the raj student proprties
       raj.regNo = "NIT23001";
       raj.name = "Raj Gourav";
       
       //Calling the behavior
         raj.talk();
         String data = raj.writeExam();
         System.out.println(data);
         
         System.out.println("............");
         
         Student priya = new Student();
       //Initializing the priya student proprties
          priya.regNo = "NIT23002";
          priya.name = "Priya Kumari";
        //Calling the behavior
          priya.talk();  
          data = priya.writeExam();
          System.out.println(data);
          
	}

}
