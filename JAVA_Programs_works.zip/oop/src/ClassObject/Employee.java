package ClassObject;

public class Employee 
{
	int employeeId;
	String employeeName;
	
	public void setEmployeeData()
	{
		employeeId = 111;
		employeeName = "Ravi";
	}
	
	public void getEmployeeData()
	{
		System.out.println("Employee Id is :"+employeeId);
		System.out.println("Employee Name is :"+employeeName);
	}

	public static void main(String[] args) 
	{		
       Employee raj = new Employee();
       raj.getEmployeeData(); //0 and null
       
       raj.setEmployeeData();
       raj.getEmployeeData(); // 111 and Ravi
	}
}
