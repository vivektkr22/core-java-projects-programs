package ClassObject;

import java.util.Scanner;

public class Manager 
{
	int managerId;
	double managerSalary;
	
	public void setManagerData()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Manager id :");
		managerId = sc.nextInt();
		System.out.print("Enter Manager Salary :");
		managerSalary = sc.nextDouble();
		sc.close();
		
	}
	public void getManagerData()
	{
		System.out.println("Manager id is :"+managerId);
		System.out.println("Manager Salary is :"+managerSalary);
	}
	

	public static void main(String[] args) 
	{
	   Manager sneha = new Manager();
	   sneha.setManagerData();
	   sneha.getManagerData();
	}

}