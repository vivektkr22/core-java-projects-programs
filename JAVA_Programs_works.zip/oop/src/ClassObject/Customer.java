package ClassObject;

public class Customer 
{
	//Properties
	int customerId;
	String customerName;
	double customerBill;
	
	//Behavior
	public void getCustomerInformation()
	{
		System.out.println("Id is :"+customerId);
		System.out.println("Name is :"+customerName);
		System.out.println("Bill is :"+customerBill);
	}
	
	
	public static void main(String[] args) 
	{
		Customer ram = new Customer();
		
		//Initializing the properties
		ram.customerId = 001;
		ram.customerName = "Ram kumar";
		ram.customerBill = 23456.90;
		
		//calling the behavior
		ram.getCustomerInformation();
		

	}

}