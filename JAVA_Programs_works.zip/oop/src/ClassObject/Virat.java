package ClassObject;

public class Virat 
{
	public static void main(String[] args) 
	{
		Player virat = new Player();
		virat.setPlayerData(18, "Virat Kohli");
		virat.getPlayerData();
	}

}
