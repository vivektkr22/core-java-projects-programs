package ClassObject;

public class Rohit 
{
	public static void main(String[] args) 
	{
		Player rohit = new Player();
		rohit.setPlayerData(45, "Rohit Sharma");
		rohit.getPlayerData();
		
		

	}
}
