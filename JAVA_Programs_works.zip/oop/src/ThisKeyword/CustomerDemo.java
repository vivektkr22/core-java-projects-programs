package ThisKeyword;

public class CustomerDemo 
{
	public static void main(String[] args) 
	{
		Customer raj = new Customer();
		raj.setCustomerData(111, "Raj Gourav");
		raj.getCustomerData();
	}

}