package ThisKeyword;

public class Student 
{
   int rollNumber;
   String studentName;
   String studentAddress;
   static String collegeName = "NIT";
   static String courseName = "Java";
   
   public void setStudentData(int rollNumber, String studentName, String studentAddress)
   {
	 this.rollNumber = rollNumber;
	 this.studentName = studentName;
	 this.studentAddress = studentAddress;
   }
   
   public void getStudentData()
   {
	   System.out.println("Roll Number is :"+rollNumber);
	   System.out.println("Name is :"+studentName);
	   System.out.println("Address is :"+studentAddress);
	   System.out.println("College Name is :"+Student.collegeName);
	   System.out.println("Course Name is :"+Student.courseName);
   }
}