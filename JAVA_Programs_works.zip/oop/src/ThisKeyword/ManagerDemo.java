package ThisKeyword;

public class ManagerDemo {

	public static void main(String[] args) 
	{
		Manager m1 = new Manager();
		m1.setManagerData(1, "Raj", "AMPT", 120000);
		System.out.println(m1); //toString()

	}

}