package ThisKeyword;

public class Manager 
{
  int managerId;
  String managerName;
  String managerAddress;
  double managerSalary;
  
  public void setManagerData(int id, String name, String addr,double salary)
  {
	  this.managerId = id;
	  this.managerName = name;
	  this.managerAddress = addr;
	  this.managerSalary = salary;
  }

	@Override
	public String toString() 
	{
		return "Manager [managerId=" + managerId + ", managerName=" + managerName + ", managerAddress=" + managerAddress
				+ ", managerSalary=" + managerSalary + "]";
	}
  
  
  
}
