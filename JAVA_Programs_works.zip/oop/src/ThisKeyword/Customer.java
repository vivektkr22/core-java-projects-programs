package ThisKeyword;

public class Customer 
{
   int customerId;
   String customerName;
   
   public void setCustomerData(int customerId, String customerName)
   {
	   this.customerId = customerId;
	   this.customerName = customerName;
	   
   }
   
   public void getCustomerData()
   {
	   System.out.println("Customer id is :"+customerId);
	   System.out.println("Customer Name is :"+customerName);
   }
   
}