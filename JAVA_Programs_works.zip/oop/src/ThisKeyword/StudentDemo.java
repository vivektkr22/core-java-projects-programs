package ThisKeyword;

public class StudentDemo {

	public static void main(String[] args) 
	{
		Student s1 = new Student();
		s1.setStudentData(111, "ABC", "Ameerpet");
		s1.getStudentData();
		System.out.println("...........");
		Student s2 = new Student();
		s2.setStudentData(222, "DEF", "S.R Nagar");
		s2.getStudentData();
	}

}