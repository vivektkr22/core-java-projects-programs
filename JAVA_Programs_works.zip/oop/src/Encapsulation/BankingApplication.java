package Encapsulation;

public class BankingApplication 
{
	public static void main(String[] args)
	{
		Customer hacker = new Customer();
		hacker.deposit(5000);
		hacker.withdraw(2000);

	}

}