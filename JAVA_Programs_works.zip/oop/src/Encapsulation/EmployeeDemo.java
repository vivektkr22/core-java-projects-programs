package Encapsulation;

public class EmployeeDemo {

	public static void main(String[] args) 
	{
	   Employee e1 = new Employee();
	   e1.setEmployeeData(1, "Virat", 40000);
	   e1.calculateEmployeeGrade();
	   System.out.println(e1);

	}

}