package Encapsulation;

public class Employee 
{
  private int empId;
  private String empName;
  private double empSalary;
  private char empGrade;
  
  public void setEmployeeData(int id, String name, double salary)
  {
	  this.empId = id;
	  this.empName = name;
	  this.empSalary = salary;
  }
  
  public void calculateEmployeeGrade()
  {
	  if(this.empSalary >= 100000)
	  {
		  empGrade  = 'A';
	  }
	  else if(this.empSalary >=75000)
	  {
		  empGrade  = 'B';
	  }
	  else if(this.empSalary >=50000)
	  {
		  empGrade  = 'C';
	  }
	  else
	  {
		  empGrade  = 'D'; 
	  }	  
  }

@Override
public String toString() 
{
	return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empGrade=" + empGrade
			+ "]";
}
  
}
