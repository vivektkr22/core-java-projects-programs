package Encapsulation;

public class Customer
{
   private double balance = 1000; //Data Hiding
   
   public void deposit(int amount)
   {
	   //Validation
	   if(amount <=0)
	   {
		   System.out.println("Amount can't be deposited");
	   }
	   else
	   {
	   balance = balance + amount;
	   System.out.println("Available balance is :"+balance);
	   }
   }
   
   public void withdraw(int amount)
   {
	   balance = balance - amount;
	   System.out.println("Available balance is :"+balance);
   }   
}