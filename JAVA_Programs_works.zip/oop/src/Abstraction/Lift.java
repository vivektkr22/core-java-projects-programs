package Abstraction;

public abstract class Lift 
{
	   public abstract void keyOne();
	   public abstract void keyTwo();
	   public abstract void keyThree();
	   public abstract void keyFour();	   
	
	public void liftInformation()
	{
		System.out.println("Lift information");
	} 
}