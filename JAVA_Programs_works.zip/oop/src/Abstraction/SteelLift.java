package Abstraction;

public interface SteelLift 
{
   public void keyOne();
   public void keyTwo();
   public void keyThree();
   public void keyFour();
   
}