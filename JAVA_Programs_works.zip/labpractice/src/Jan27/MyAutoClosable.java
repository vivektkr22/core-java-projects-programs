package Jan27;

public class MyAutoClosable implements AutoCloseable {
	@Override
	public void close() throws Exception {
	  System.out.println("Resources close");	
	}

	public void display(String str) {
		if(str == null) {
			throw new RuntimeException();
		}
		else {
			System.out.println("i dont have exception");
		}
	}
	public static void main(String[] args) throws Exception {
		MyAutoClosable m = new MyAutoClosable();
		try(m){
			m.display("John");
		}
	}
}
