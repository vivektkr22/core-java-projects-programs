package Jan27;

public class ExceptionDemo {
	public void checkException()
	{
		try
		{
		String str=null;
		System.out.println(str.length());
		}
		catch(NullPointerException e)
		{
		System.out.println("Null Pointer Exception");
		}
	}
	
	public static void main(String[] args) {
		ExceptionDemo e = new ExceptionDemo();
		e.checkException();
	}
}
