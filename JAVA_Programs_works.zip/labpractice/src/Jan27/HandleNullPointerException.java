package Jan27;

public class HandleNullPointerException {
     public void display(String s, int n) {
    	 System.out.println("Name: "+s+"\nID: "+n);
     }
	public static void main(String[] args) {
		HandleNullPointerException h = null;
		if(h==null) {
			h = new HandleNullPointerException();
			h.display("Rohan", 101);
		}
		else {
			h.display("John", 102);
		}
	}
}
