package Jan27;

public class StackOverFlowErrorDemo {
      public static void display() {
    	  System.out.println("I am stack overflow");
    	  display();
      }
	public static void main(String[] args) {
		display();
	}

}
