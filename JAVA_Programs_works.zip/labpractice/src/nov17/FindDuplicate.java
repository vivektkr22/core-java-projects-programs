package nov17;
import java.util.Scanner;

public class FindDuplicate {
	
	public static String getDuplicates(int num) {
	    String s = "" + num;
	    String s1 = "";
	    int k = 0;

	    for (int i = 0; i < s.length(); i++) {
	        int c = k;
	        for (int j = i + 1; j < s.length(); j++) {
	            if (s.charAt(i) == s.charAt(j)) {
	                c++;
	                if (c == 1) {
	                    s1 += s.charAt(j) + " ";
	                }
	                s.replace(s.charAt(j), '*');
	            }
	        }
	    }
	    return s1;
	}


	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		int n = sc.nextInt();
		System.out.println(getDuplicates(n));
		sc.close();
		}

}
