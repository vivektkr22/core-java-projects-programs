package Fab29;

import java.util.ArrayList;

public class CabCustomerService {
    private ArrayList<CabCustomer> ccList = new ArrayList<>();
    private static double bill;

    public void addCabCustomer(CabCustomer cc) {
        if (isFirstCustomer(cc)) {
        	bill = calculateBill(cc);
            ccList.add(cc);
        } else {
        	bill = calculateBill(cc);
            System.out.println("Customer is already exist....");
        }
    }

    public boolean isFirstCustomer(CabCustomer cc) {
        for (CabCustomer existingCustomer : ccList) {
            if (existingCustomer.getPhone().equals(cc.getPhone())) {
                return false; 
            }
        }
        return true; 
    }

    public double calculateBill(CabCustomer cc) {
    	double b=0;
        if (isFirstCustomer(cc)) {
            b= 0; 
        } else if (cc.getDistance() <= 4) {
            b= 80;
        } else {
            b= 80 + (cc.getDistance() - 4) * 6;
        }
        return b;
    }

    public String printBill(CabCustomer cc) {
        return cc.getCustomerName() + " Please pay your bill of Rs. " + bill;
    }
}
