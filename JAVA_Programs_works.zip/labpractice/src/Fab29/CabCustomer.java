package Fab29;

public class CabCustomer {
  private int customerId;
  private String customerName;
  private String pickupLocation;
  private String dropLocation;
  private int distance;
  private String phone;
  
  public CabCustomer() {
	 super(); 
  }

public CabCustomer(int customerId, String customerName, String pickupLocation, String dropLocation, int distance,
		String phone) {
	super();
	this.customerId = customerId;
	this.customerName = customerName;
	this.pickupLocation = pickupLocation;
	this.dropLocation = dropLocation;
	this.distance = distance;
	this.phone = phone;
}

public int getCustomerId() {
	return customerId;
}

public String getCustomerName() {
	return customerName;
}

public String getPickupLocation() {
	return pickupLocation;
}

public String getDropLocation() {
	return dropLocation;
}

public int getDistance() {
	return distance;
}

public String getPhone() {
	return phone;
}

public void setCustomerId(int customerId) {
	this.customerId = customerId;
}

public void setCustomerName(String customerName) {
	this.customerName = customerName;
}

public void setPickupLocation(String pickupLocation) {
	this.pickupLocation = pickupLocation;
}

public void setDropLocation(String dropLocation) {
	this.dropLocation = dropLocation;
}

public void setDistance(int distance) {
	this.distance = distance;
}

public void setPhone(String phone) {
	this.phone = phone;
}

@Override
public String toString() {
	return "CabCustomer [customerId=" + customerId + ", customerName=" + customerName + ", pickupLocation="
			+ pickupLocation + ", dropLocation=" + dropLocation + ", distance=" + distance + ", phone=" + phone + "]";
}
  
  
  
}
