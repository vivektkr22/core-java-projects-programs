package Fab29;

public class CabCustomerServiceTester {

	public static void main(String[] args) {
CabCustomerService ccs = new CabCustomerService();
		
		CabCustomer cc = new CabCustomer(1, "Raj", "ameerpet", "charmenaar", 15, "123456");        
		ccs.addCabCustomer(cc);
		ccs.isFirstCustomer(cc);
		System.out.println(cc);
		String billPrint = ccs.printBill(cc);
		System.out.println(billPrint);
		System.out.println("--------------------------------------------------------------");
		
		CabCustomer cc1 = new CabCustomer(2, "virat", "panjagutta", "centralMall", 10, "123456");
		ccs.addCabCustomer(cc1);
		System.out.println(cc1);
		billPrint = ccs.printBill(cc1);		
		System.out.println(billPrint);
		System.out.println("--------------------------------------------------------------");
	
		CabCustomer cc2 = new CabCustomer(3, "rohit", "ameerpet", "S R nagar", 5, "1234567");
		 ccs.addCabCustomer(cc2);
		System.out.println(cc2);
		billPrint = ccs.printBill(cc2);		
		System.out.println(billPrint);
	}

}
