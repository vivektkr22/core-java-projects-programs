package dec29;

public class GeometricShape {
    String shapeType;
    double area;
    
    public GeometricShape() {
		shapeType = "";
		area = 0;
	}
    
    public double computeArea(double val1, double val2) {
    	return area;
    }
    
    public void show() {
    	System.out.println("Shape Type is: "+shapeType);
    	System.out.println("Area is: "+area);
    }
}
