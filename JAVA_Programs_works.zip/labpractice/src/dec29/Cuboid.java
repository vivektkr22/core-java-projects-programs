package dec29;


public class Cuboid extends Rectangle {
  private double height;
  
  public Cuboid() {
	height = 15;
}
  

  public double computeArea(double width, double length, double height) {
      super.computeArea(width, length);
      this.height = height;
      area = super.area * this.height;
      return area;
  }

  @Override
  public void show() {
      super.show();
      System.out.println("Cuboid Height: " + height);
      System.out.println("Cuboid Total Area: " + area);
  }
}
