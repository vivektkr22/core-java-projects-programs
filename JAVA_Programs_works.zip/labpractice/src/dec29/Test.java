package dec29;

public class Test {

	public static void main(String[] args) {
	    Rectangle rectangle = new Rectangle();
        rectangle.computeArea(5, 6);
        rectangle.show(); 
        System.out.println("==============================");
        Cuboid cuboid = new Cuboid();
        cuboid.computeArea(4, 5, 6); 
        cuboid.show(); 
	}

}
