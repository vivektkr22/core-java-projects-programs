package dec29;

public class ShapeDemo {

	public static void main(String[] args) {

		//call Shape sh = Shape.randshape()
		Shape sh = Shape.randshape();
		// call draw and erase methods
		sh.draw();
		sh.erase();
	
	
		
		//call Shape sh1 = Shape.randshape()
	Shape sh1 = Shape.randshape();
		// call draw and erase methods
		sh1.draw();
		sh1.erase();
		
		
		
		//call Shape sh2 = Shape.randshape()
	Shape sh2 = Shape.randshape();
		// call draw and erase methods
		sh2.draw();
		sh2.erase();
		
		//call Shape sh3 = Shape.randshape()
		Shape sh3 = Shape.randshape();
		// call draw and erase methods
		sh3.draw();
		sh3.erase();
	}

}

