package dec29;

public class Rectangle extends GeometricShape{
     private double width;
     private double length;
     
     public Rectangle() {
		width = 10;
		length = 10;
	}

	public double getWidth() {
		return width;
	}

	public double getLength() {
		return length;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public void setLength(double length) {
		this.length = length;
	}
     
 
     @Override
    public double computeArea(double width, double length) {
    	 this.width = width;
    	 this.length = length;
    	 area = this.width * this.length;
         return area;
    }
     
     @Override
    public void show() {
    	System.out.println("Rectangle length: "+length);
    	System.out.println("Rectangle width: "+width);
    	System.out.println("Rectangle area: "+area);
    }
     
}






