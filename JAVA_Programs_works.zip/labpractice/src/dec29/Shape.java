package dec29;

public class Shape {
	
	// create no argument constructor
	Shape(){
		
	}
	//create a static method randshape() which should return Shape type 

			public static Shape randshape() {
				//initialize shape type reference variable to null
			    Shape sp = null;
			    
			    //declare switch case statement
			    //based on case type create child object and assign it to Shape type reference variable.
			    //if it is default case then create an object to Shape class and assign it to reference variable
		//System.out.println((int)(Math.random()*3));
			    int i=(int)(Math.random()*3);
			    System.out.println(i);
			    switch(i) {
	             	case 0:  sp = new Circle(); break;
		            case 1:  sp = new Square(); break;
		            case 2:  sp = new Triangle(); break;
	             	default: sp = new Shape();
		         }
			// return Shape type reference variable
	               return sp;
    }
    
	public void draw() {
		System.out.println("Shape draw");
	}
	public void erase() {
		System.out.println("Shape erase");
	}
	

}

