package March14;
/* Program-1
----------
A class Employee is given to you. It contains the following:
Instance Variables: 
name:String  private  
employeeId: int  private
salary: double private
Methods: set and get methods for all.
Default constructor AND  All-fields constructor

An Enum called ManagerType is given to you. It defines the two types of managers, HR and Sales


Create two sub classes of Employee called Manager and Clerk. 
The details of each class is given below.
For class Manager:
Instance Variables:
type: enum ManagerType private


Methods: set and get methods for type. 
Default constructor AND  All-fields constructor

Override :
setSalary(): If the type is HR manager, add 10000 to the given salary 
and for a sales manager, add 5000 to the given salary.


For class Clerk:
Instance Variables: 
speed: int
accuracy:int

Methods: set and get methods for speed and accuracy.
Default constructor AND All-fields constructor.

Override:
setSalary(): If the clerk has a typing speed of greater than 70 AND accuracy greater than 80 then add 1000 to the salary. Otherwise set the same salary. 
Note that any change in speed and accuracy(using setSpeed() or setAccuracy() ) should result in 
recalculation of salary, as the Trainee may qualify for the extra amount. 
HOWEVER, when once the extra 1000 is given for extra speed/ and accuracy it should not be given again.

For example, if a Clerk's speed is already 85 and accuracy is already 75, and the speed is changed to 90, 
then the extra amount should not be added again. This extra amount should be credited to salary only the first time the Clerk qualifies for the amount.
Provide proper constructors for all classes.
A class EmployeeTester is given to you with a main method. Use this class to test your solution's classes and methods.
*/
//Enum for ManagerType
enum ManagerType {
 HR, SALES
}

//Employee class
class Employee {
 private String name;
 private int employeeId;
 private double salary;

 // Default constructor
 public Employee() {}

 // All-fields constructor
 public Employee(String name, int employeeId, double salary) {
     this.name = name;
     this.employeeId = employeeId;
     this.salary = salary;
 }

 // Getters and setters for name, employeeId, and salary
 public String getName() {
     return name;
 }

 public void setName(String name) {
     this.name = name;
 }

 public int getEmployeeId() {
     return employeeId;
 }

 public void setEmployeeId(int employeeId) {
     this.employeeId = employeeId;
 }

 public double getSalary() {
     return salary;
 }

 public void setSalary(double salary) {
     this.salary = salary;
 }
}

//Manager class, subclass of Employee
class Manager extends Employee {
 private ManagerType type;

 // Default constructor
 public Manager() {}

 // All-fields constructor
 public Manager(String name, int employeeId, double salary, ManagerType type) {
     super(name, employeeId, salary);
     this.type = type;
 }

 // Getter and setter for type
 public ManagerType getType() {
     return type;
 }

 public void setType(ManagerType type) {
     this.type = type;
 }

 // Override setSalary method
 @Override
 public void setSalary(double salary) {
     if (type == ManagerType.HR)
         super.setSalary(salary + 10000);
     else if (type == ManagerType.SALES)
         super.setSalary(salary + 5000);
 }
}

//Clerk class, subclass of Employee
class Clerk extends Employee {
 private int speed;
 private int accuracy;
 private boolean extraAmountAdded; // flag to check if extra amount already added

 // Default constructor
 public Clerk() {}

 // All-fields constructor
 public Clerk(String name, int employeeId, double salary, int speed, int accuracy) {
     super(name, employeeId, salary);
     this.speed = speed;
     this.accuracy = accuracy;
     this.extraAmountAdded = false; // Initially extra amount not added
 }

 // Getters and setters for speed and accuracy
 public int getSpeed() {
     return speed;
 }

 public void setSpeed(int speed) {
     this.speed = speed;
     // Recalculate salary if speed and accuracy change
     if (!extraAmountAdded && speed > 70 && accuracy > 80) {
         setSalary(getSalary() + 1000);
         extraAmountAdded = true; // Set flag to true after adding extra amount
     }
 }

 public int getAccuracy() {
     return accuracy;
 }

 public void setAccuracy(int accuracy) {
     this.accuracy = accuracy;
     // Recalculate salary if speed and accuracy change
     if (!extraAmountAdded && speed > 70 && accuracy > 80) {
         setSalary(getSalary() + 1000);
         extraAmountAdded = true; // Set flag to true after adding extra amount
     }
 }

 // Override setSalary method
 @Override
 public void setSalary(double salary) {
     // Check if extra amount already added
     if (!extraAmountAdded) {
         super.setSalary(salary);
     }
 }
}

//EmployeeTester class to test the solution
public class EmployeeTester {
 public static void main(String[] args) {
     // Testing Manager class
     Manager manager1 = new Manager("John", 101, 50000, ManagerType.HR);
     manager1.setSalary(50000); // Should add 10000 to salary
     System.out.println("Manager 1 Salary: " + manager1.getSalary()); // Expected output: 60000

     Manager manager2 = new Manager("Alice", 102, 60000, ManagerType.SALES);
     manager2.setSalary(60000); // Should add 5000 to salary
     System.out.println("Manager 2 Salary: " + manager2.getSalary()); // Expected output: 65000

     // Testing Clerk class
     Clerk clerk = new Clerk("Bob", 201, 30000, 80, 85);
     clerk.setSalary(30000); // Should add 1000 to salary
     System.out.println("Clerk Salary: " + clerk.getSalary()); // Expected output: 31000

     // Changing speed and accuracy to check if extra amount is not added again
     clerk.setSpeed(90); // Should not add extra amount again
     System.out.println("Clerk Salary after speed change: " + clerk.getSalary()); // Expected output: 31000
 }
}
