package nov27;

public class PrintAreaOfCircle {
 public static String getArea(double r) {
	 final double PI = 3.14f;
	 double aoc = PI*r*r;
	 String s = "";
	 return String.format("%.2f", s+=aoc);
 }
}
