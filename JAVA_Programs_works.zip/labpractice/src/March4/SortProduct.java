package March4;

import java.util.ArrayList;
import java.util.Collections;

public class SortProduct {
      public static void main(String[] args) {
	ArrayList<Product> al = new ArrayList<>();
	al.add(new Product(101, "Dell Laptop", 35000));
	al.add(new Product(102, "Television", 50000));
	al.add(new Product(103, "Apple tablet", 28000));
	
	Collections.sort(al);
	
	al.forEach(System.out::println);
	
	
	}
}
