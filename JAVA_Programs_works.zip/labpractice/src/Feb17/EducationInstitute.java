package Feb17;

public class EducationInstitute {
    private Course[] courses;
    private Offer[] offers;

    public EducationInstitute(Course[] courses, Offer[] offers) {
        this.courses = courses;
        this.offers = offers;
    }

    public Course[] getCourses() {
        return courses;
    }

    public Offer[] getOffers() {
        return offers;
    }

    public synchronized void enrollStudentInCourse(int courseId, String studentName) {
        for (Course course : courses) {
            if (course.getId() == courseId) {
                System.out.println(studentName + " has enrolled in the course: " + course.getName());
                return;
            }
        }
        System.out.println("Invalid course ID");
    }
}