package nov11;

public class EvenOrOdd {
    public static boolean isEven(int number) {
        return number % 2 == 0;
    }
}

