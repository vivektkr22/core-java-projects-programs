package nov11;

public class Circle {
    public static String getArea(double radius) {
        if (radius <= 0) {
            return "0";
        } else {
            double area = Math.PI * Math.pow(radius, 2);
            return String.format("%.2f", area);
        }
    }
}