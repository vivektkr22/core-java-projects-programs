package nov11;
import java.util.Scanner;
public class Test3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int testNumber = scanner.nextInt();
        scanner.close();

        boolean isEvenResult = EvenOrOdd.isEven(testNumber);

        if (isEvenResult) {
            System.out.println(testNumber + " is even.");
        } else {
            System.out.println(testNumber + " is odd.");
        }
    }
}