package nov11;

import java.util.Scanner;

public class Test1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the radius of the circle: ");
        double radius = scanner.nextDouble();

        String area = Circle.getArea(radius);
        System.out.println("Area of the circle: " + area);

        scanner.close();
    }
}

