package nov11;

public class Student {

 public static String getStudentDetails(int roll, String name, double fees) {

     return "[ Roll is :" + roll + ", Name is :" + name + ", Fees is :" + fees + "]";
 }
}

