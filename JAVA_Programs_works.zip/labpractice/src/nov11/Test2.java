package nov11;

import java.util.Scanner;

public class Test2 {
 public static void main(String[] args) {
   
     Scanner scanner = new Scanner(System.in);

     System.out.print("Enter Roll Number: ");
     int roll = scanner.nextInt();

     System.out.print("Enter Name: ");
     scanner.nextLine(); 
     String name = scanner.nextLine();

     System.out.print("Enter Fees: ");
     double fees = scanner.nextDouble();

     String studentDetails = Student.getStudentDetails(roll, name, fees);
     System.out.println(studentDetails);

     scanner.close();
 }
}
