package nov6;

public class sphereVolume {

	public static void main(String[] args) {
		float r = Float.parseFloat(args[0]);
		float pi =3.14f;
		float v = (4.0f/3.0f)*(pi)*(r*r*r);
		
		System.out.println("Volume of sphere is: "+v);

	}

}
