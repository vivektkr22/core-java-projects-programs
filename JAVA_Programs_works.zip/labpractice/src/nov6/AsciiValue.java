package nov6;

public class AsciiValue {

	public static void main(String[] args) {
		char c = args[0].charAt(0);
		
		int n = c;
		
		System.out.println("The ASCII value of a is: "+n);
	}

}
