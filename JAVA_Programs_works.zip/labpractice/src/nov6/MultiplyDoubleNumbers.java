package nov6;

public class MultiplyDoubleNumbers {

	public static void main(String[] args) {
		if(args.length<2) System.out.println("Error: please give two argument");
		
		double a,b,mul;
		a = Double.parseDouble(args[0]);
		b = Double.parseDouble(args[1]);
		
		mul = a*b;
		
		System.out.println("Multiplication of number is: "+mul);

	}

}
