package nov6;

public class KilometerToMiles {

	public static void main(String[] args) {
     double k = Double.parseDouble(args[0]);
     
     double m = k*0.621371;
     
     System.out.println(k+" kilometer in miloes is: "+m);
	}

}
