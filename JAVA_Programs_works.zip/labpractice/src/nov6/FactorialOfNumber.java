package nov6;

public class FactorialOfNumber {

	public static void main(String[] args) {
		int n = Integer.parseInt(args[0]);
		
		int fact =1;
		
		while(n!=0) {
			fact*=n;
			n--;
		}
		System.out.println("Factorial of a number is: "+fact);
	}

}
