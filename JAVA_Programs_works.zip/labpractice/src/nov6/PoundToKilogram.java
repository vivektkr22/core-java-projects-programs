package nov6;

public class PoundToKilogram {

	public static void main(String[] args) {
		Double p = Double.parseDouble(args[0]);
		
		double k = p*0.453592;
		
        System.out.println(p+" Pound in Kilogram is: "+k);
	}

}
