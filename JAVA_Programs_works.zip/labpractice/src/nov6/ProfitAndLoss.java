package nov6;

public class ProfitAndLoss {

	public static void main(String[] args) {
		float sp,cp,profit,loss,profitPercentages,lossPercentages;
		
		sp = Float.parseFloat(args[0]);
		cp = Float.parseFloat(args[1]);
		
        profit = sp - cp;
        loss = cp - sp;
        
        profitPercentages = (profit*100)/cp;
        lossPercentages = (loss*100)/cp;
        
        if(cp<sp) System.out.println("Profit PErcentages is: "+profitPercentages+"%");
        else System.out.println("Loss Percentages is: "+lossPercentages+"%");

	}

}
