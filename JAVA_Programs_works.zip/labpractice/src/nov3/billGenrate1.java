//Write a  program in Java that will generate and print the bill at Dominos for four chicken rolls (@ Rs 60 per chicken rolls) and three vegetable puffs 
//(@ Rs 25 per vegetable puffs). There is a special Yoga Day discount of Rs 50 on the final bill amount. Calculate and print final bill as well as all item bill.

package nov3;

public class billGenrate1 {

	public static void main(String[] args) {
		String it1, it2; 
		float p1,p2,dis,totBill,qty1,qty2,it1price,it2price;
		
		 it1 = args[0];
		 p1 = Float.parseFloat(args[1]);
		 qty1 = Float.parseFloat(args[2]);
		 
		 it2 = args[3];
		 p2 = Float.parseFloat(args[4]);
		 qty2 = Float.parseFloat(args[5]);
		 
		 dis = Float.parseFloat(args[6]);
		 
		 it1price = p1*qty1;
		 it2price = p2*qty2;
		 
		 totBill = (it1price+it2price)-dis;
		 
		 System.out.println(qty1+" "+it1+" price is: "+p1*qty1);
		 System.out.println(qty2+" "+it2+" price is: "+p2*qty2);
		 System.out.println("Discount is: "+dis);
		 System.out.println("Total Bill: "+totBill);
		
		 

	}

}
