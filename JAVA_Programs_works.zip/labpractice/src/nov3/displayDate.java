package nov3;

public class displayDate {

	public static void main(String[] args) {
	     int a,b,c;
		
		a = Integer.parseInt(args[0]);
		b = Integer.parseInt(args[1]);
		c = Integer.parseInt(args[2]);
		
		if(a<10&&b<10)
		System.out.println("0"+a+"/"+"0"+b+"/"+c);
		else if(b<10)
		System.out.println(a+"/"+"0"+b+"/"+c);	
		else if(a<10)
	    System.out.println("0"+a+"/"+b+"/"+c);
		else 
	    System.out.println(a+"/"+b+"/"+c);
	}

}



