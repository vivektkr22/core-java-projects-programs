package nov3;

public class stuResult {

	public static void main(String[] args) {
		float a,b,c,d,e,avg;
		
		a = Float.parseFloat(args[0]);
		b = Float.parseFloat(args[1]);
		c = Float.parseFloat(args[2]);
		d = Float.parseFloat(args[3]);
		e = Float.parseFloat(args[4]);
		
		avg = (a + b + c + d + e)/5;
		
		if(avg>60) System.out.println("PASS");
		else System.out.println("FAIL");

	}

}
