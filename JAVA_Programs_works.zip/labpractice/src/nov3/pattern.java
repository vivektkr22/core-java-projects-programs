package nov3;

public class pattern {

	public static void main(String[] args) {
		System.out.println("@@@@@@@@");
		System.out.println("@      @");
		System.out.println("@      @");
		System.out.println("@      @");
		System.out.println("@      @");
		System.out.println("@      @");
		System.out.println("@@@@@@@@");
		

	}

}
