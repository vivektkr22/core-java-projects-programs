package nov3;

public class findMax {

	public static void main(String[] args) {
		int a,b,c;
		
		a = Integer.parseInt(args[0]);
		b = Integer.parseInt(args[1]);
		c = Integer.parseInt(args[2]);
		
		int max = a;
		if(b>a&&b>c) max =b;
		else if(c>a&&c>b) max =c;
		
		System.out.println("MAximun number is: "+ max);

	}

}
