package nov3;

public class pattern1 {

	public static void main(String[] args) {
		
		System.out.println("Twinkle, twinkle, little star,\n"
				+ "       How I wonder what you are!\n"
				+ "Up above the world so high,\n"
				+ "       Like a diamond in the sky.\n"
				+ "Twinkle, twinkle, little star,\n"
				+ "       How I wonder what you are");

	}

}
