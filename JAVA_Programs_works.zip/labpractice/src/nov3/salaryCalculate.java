//Write a program to input the basic salary of a person. He get 15% of the basic as HRA, 15% of the basic as Conveyance allowance and 10% of the basic as 
//Entertainment allowance.The total salary is calculated by adding Basic + HRA + Conveyance + Entertainment Allowance. Calculate and print the total salary of
//person. Take the Basic Salary from Command Line Argument.

package nov3;

public class salaryCalculate {

	public static void main(String[] args) {
		
    float bas, hra, con, ent,totalSalary;
    
    bas = Float.parseFloat(args[0]);
    
    hra = (bas*15)/100;
    con = (bas*15)/100;
    ent = (bas*10)/100;
    
    totalSalary = bas + hra + con + ent;
    
    System.out.println("Basic Salary is: Rs "+bas);
    System.out.println("HRA is 15% of Basic Salary which is: Rs "+hra);
    System.out.println("Conveyence is 15% of Basic Salary which is: Rs "+con);
    System.out.println("Entertainment Allowance is 10% of Basic Salary which is: Rs "+ent);
    System.out.println("Toatal Salary is: "+totalSalary);
	}

}
