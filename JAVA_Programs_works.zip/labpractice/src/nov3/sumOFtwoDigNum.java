package nov3;

public class sumOFtwoDigNum {

	public static void main(String[] args) {
		int n,a,b,sum;
		
		n = Integer.parseInt(args[0]);
		
		a = n%10;
		b = n/10;
		
		sum = a + b;
		
		System.out.println("Sum is: "+sum);

	}

}
