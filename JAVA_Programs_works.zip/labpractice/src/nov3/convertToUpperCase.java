package nov3;

public class convertToUpperCase {

	public static void main(String[] args) {
		char c = args[0].charAt(0);
		
		char x = (char)(c-32);
		System.out.println(x);
		
	}

}
