package March8;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

class Student {
    private String studentName;
    private char studentGrade;

    public Student(String studentName, char studentGrade) {
        this.studentName = studentName;
        this.studentGrade = studentGrade;
    }

    public String getStudentName() {
        return studentName;
    }

    public char getStudentGrade() {
        return studentGrade;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setStudentGrade(char studentGrade) {
        this.studentGrade = studentGrade;
    }
}

class StudentManagementSystem {
    Map<String, Character> hm;

    StudentManagementSystem() {
        this.hm = new HashMap<>();
    }

    public void addStudent(Student student) {
        hm.put(student.getStudentName(), student.getStudentGrade());
    }

    public void removeStudent(String studentName) {
        String lowercaseName = studentName.toLowerCase();
        if (hm.isEmpty()) {
            System.out.println("It's Empty");
        } else if (!hm.containsKey(lowercaseName)) {
            System.err.println("Student is not found");
        } else {
            hm.remove(lowercaseName);
            System.out.println("Student data is removed for " + lowercaseName);
        }
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder("StudentManagementSystem [Student Data:\n");

        for (Map.Entry<String, Character> entry : hm.entrySet()) {
            result.append("Name: ").append(entry.getKey()).append(", Grade: ").append(entry.getValue()).append("\n");
        }

        result.append("]");
        return result.toString();
    }
}

public class StudentManagementSystemMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StudentManagementSystem sms = new StudentManagementSystem();

        while (true) {
            System.out.println("Options:\n1. Add Student Grade\n2. Remove Student Grade\n3. Display Data\n4. Exit");
            System.out.print("Enter your choice: ");

            if (sc.hasNextInt()) {
                int choice = sc.nextInt();
                sc.nextLine(); 

                switch (choice) {
                    case 1: {
                        System.out.print("Enter the student name: ");
                        String name = sc.nextLine();
                        System.out.print("Enter the student grade: ");
                        char grade = sc.next().charAt(0);

                        Student student = new Student(name, grade);
                        sms.addStudent(student);
                        break;
                    }
                    case 2: {
                        System.out.print("Enter the student name to remove: ");
                        String name = sc.next();
                        sms.removeStudent(name);
                        break;
                    }
                    case 3: {
                        System.out.println(sms);
                        break;
                    }
                    case 4: {
                        System.out.println("Thank you for visiting us");
                        System.exit(0);
                    }
                    default:
                        System.out.println("Invalid choice. Please select a valid option.");
                }
            } 
            else {
                System.out.println("Invalid input. Please enter a valid integer choice.");
                sc.next(); 
            }
        }
    }
}
