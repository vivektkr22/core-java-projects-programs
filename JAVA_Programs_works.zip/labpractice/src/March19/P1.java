package March19;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/* Given an integer array nums, return true if any value appears at least twice in the array, and return false if every element is distinct.

Input: nums = [1,2,3,1]

Output: true

Input: nums = [1,2,3,4]

Output: false  */

public class P1 {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1,2,3,1);
		
		List<Integer> res = list.stream().distinct().collect(Collectors.toList());
		
		System.out.println(res.size()==list.size());
	}

}
