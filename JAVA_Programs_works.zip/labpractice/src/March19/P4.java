package March19;
/* Write a java program to identify the highest paid employee from each department which is present in the list which have the
employee details as well as the department name also? */

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

class Employee1 {
    private String name;
    private String department;
    private double salary;

    public Employee1(String name, String department, double salary) {
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "Employee1{name='" + name + "', department='" + department + "', salary=" + salary + '}';
    }
}

public class P4 {
    public static void main(String[] args) {
        List<Employee1> employees = Arrays.asList(
                new Employee1("John", "HR", 50000),
                new Employee1("Jane", "HR", 55000),
                new Employee1("Mike", "Finance", 60000),
                new Employee1("Emily", "Finance", 62000),
                new Employee1("David", "IT", 70000),
                new Employee1("Sarah", "IT", 72000)
        );

        employees.stream()
                .collect(Collectors.groupingBy(Employee1::getDepartment,
                        Collectors.collectingAndThen(
                                Collectors.maxBy((e1, e2) -> Double.compare(e1.getSalary(), e2.getSalary())),
                                Optional::get)))
                .forEach((department, employee) -> {
                    System.out.println("Department: " + department + ", Highest Paid Employee: " + employee);
                });
    }
}

