package March19;
/* Write a java program where there is a list of employees and each employee have the attributes as age name and salary, requirement
is I have to increase the salary of each employee whose age is greater than 25 by 10%? */

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class Employee{
	private Integer age;
	private String name;
	private Double salary;
	
	public Employee(Integer age, String name, Double salary) {
		super();
		this.age = age;
		this.name = name;
		this.salary = salary;
	}

	public Integer getAge() {
		return age;
	}

	public String getName() {
		return name;
	}

	public Double getSalary() {
		return salary;
	}
	
	

	public void setAge(Integer age) {
		this.age = age;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [age=" + age + ", name=" + name + ", salary=" + salary + "]";
	}

	
	
	
}

public class P3 {

	public static void main(String[] args) {
		Employee e1 = new Employee(20, "virat", 25000.0);
		Employee e2 = new Employee(26, "rohit",30000.0);
		Employee e3 = new Employee(34, "rahul", 60000.0);
		
		List<Employee> list = new ArrayList<>();
		list.add(e1); list.add(e2); list.add(e3);
		
		List<Employee> l2 = list.stream().filter(x-> x.getAge()>25).collect(Collectors.toList());
		
		for(Employee e : l2) {
			e.setSalary(e.getSalary()*10/100+e.getSalary());
		}
		
		System.out.println(list);
	}

}
