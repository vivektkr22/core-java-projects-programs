package March19;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


// Java 8 program to perform cube on list elements and filter numbers greater than 50.
public class P2 {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(4,5,2,6,3,7,1);
		List<Integer> l = list.stream().map(x-> x*x*x).filter(x-> x>50).collect(Collectors.toList());
		System.out.println(l);
	}

}
