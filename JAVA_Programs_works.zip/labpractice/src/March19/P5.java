package March19;
/* Given 3 list of String name, each list is containing 5 names. Convert all the list into single list using flatMap() and display 
the result  */

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class P5 {
    public static void main(String[] args) {
        List<String> names1 = Arrays.asList("Alice", "Bob", "Charlie", "David", "Eva");
        List<String> names2 = Arrays.asList("Frank", "Grace", "Henry", "Ivy", "Jack");
        List<String> names3 = Arrays.asList("Kevin", "Linda", "Mike", "Nancy", "Olivia");

        List<String> allNames = Stream.of(names1, names2, names3)
                .flatMap(Collection::stream)
                .collect(Collectors.toList());

        System.out.println("All Names: " + allNames);
    }
}

