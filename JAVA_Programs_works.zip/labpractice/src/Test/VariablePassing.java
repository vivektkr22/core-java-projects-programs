package Test;

public class VariablePassing {

	public static void main(String[] args) {
		int [] localVar = {5,7,8};
		
		VariablePassing var = new VariablePassing();
		var.test(localVar);
		System.out.println("modified value: "+localVar[0]);
	}
	
	public void test(int [] arr) {
		arr[0] = 8;
		
	}

}
