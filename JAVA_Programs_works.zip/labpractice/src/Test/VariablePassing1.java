package Test;

public class VariablePassing1 {

	public static void main(String[] args) {
		int localVar = 5;
		
		VariablePassing1 var = new VariablePassing1();
		var.test(localVar);
		System.out.println("modified value: "+localVar);
	}
	
	public void test(int arr) {
		arr = 8;
	}

}
