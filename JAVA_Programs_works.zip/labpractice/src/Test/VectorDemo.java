package Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
class VectorDemo{
	public static void main(String[] args)
	{
		List list = new ArrayList();
		 list.add("a");
		 list.add(123);
		 list.add('c');
		 list.add(null);
		 list.remove(true);
		 System.out.println(list);
		 int arr[] = {2,4,5,1};
		 Arrays.sort(arr);
		 System.out.println(arr.toString());
		 }
	}