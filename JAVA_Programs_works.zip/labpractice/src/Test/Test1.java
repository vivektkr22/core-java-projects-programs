package Test;

class Foo
{
Foo()
{
System.out.println("No Argument constructor..");
}
{
System.out.println("Instance block..");
}
static
{
System.out.println("Static block...");
}
}
public class Test1
{
public static void main(String [] args)
{
new Foo();
new Foo();
System.out.println("Main Completed...");
}
}




