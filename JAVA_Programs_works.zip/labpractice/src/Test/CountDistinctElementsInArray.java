package Test;

import java.util.HashSet;

public class CountDistinctElementsInArray {
       public static void main(String[] args) {
    	   int a1[] = {6,3,9,2,9,4};
    	   int a2[] = {7,3,9};
    	   
    	   int c=0;
    	   HashSet<Integer> h = new HashSet<Integer>();
    	   for(Integer i : a1) {
    		   h.add(i);
           }
    	   
    	   for(Integer i : a2) {
    		   if(h.contains(i)) {
    			   c++;
    			   h.remove(i);
    		   }
    	   }
    	   
    	   System.out.print(c);
       }
}
