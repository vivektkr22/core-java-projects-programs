package nov2;

public class bakeryShope {

	public static void main(String[] args) {
		int qty,price;
		
		qty = Integer.parseInt(args[0]);
		price = Integer.parseInt(args[1]);
		
		System.out.println("Welcome to My Bakery Shop!");
		System.out.println("----------------------------");
		System.out.println("Available Item is : Chocolate");
		System.out.println("Enter the quantity you want to purchase:"+qty);
		System.out.println("Enter the price of Chocolate Cake:"+price);
		System.out.println("------------------------------------");
		System.out.println("Quantity:"+qty);
		System.out.println("Price per item: Rs."+price);
		System.out.println("Total cost: Rs."+qty*price);
		System.out.println("Thank you for shopping at My Bakery Shop! Have a nice day!");
		
		

	}

}
