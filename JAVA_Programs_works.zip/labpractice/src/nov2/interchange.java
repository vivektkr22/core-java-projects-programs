//Write a program to interchange the value of two numbers without using    
//the third variable where number must be taken from command argument.
package nov2;

public class interchange {

	public static void main(String[] args) {
		float a,b;
		a = Float.parseFloat(args[0]);
		b = Float.parseFloat(args[1]);
		
		System.out.println("Initial number is: "+a+" "+b);
		a = a+b;
		b = a-b;
		a = a-b;
		
		System.out.println("After swapping number is: "+a+" "+b);
	}

}
