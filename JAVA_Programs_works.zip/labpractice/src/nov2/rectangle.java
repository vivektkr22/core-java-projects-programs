package nov2;

public class rectangle {
	public static void main(String[] args) {
		float l,w;
		 l = Float.parseFloat(args[0]);
		 w = Float.parseFloat(args[1]);
		float a = l*w;
		System.out.println("area of a rectangle is: "+ a);
	}
	}

