package nov2;

public class restorant {

	public static void main(String[] args) {
		int tea,coffee,biscuit,totBill;
		
		tea = Integer.parseInt(args[0]);
		coffee = Integer.parseInt(args[1]);
		biscuit = Integer.parseInt(args[2]);
		
        totBill = tea*30 + coffee*25 + biscuit*30;
		
		System.out.println(tea+" cup of tea");
		System.out.println(coffee+" cup of tea");
		System.out.println(biscuit+" biscuit");
		System.out.println("Total Bill Amount: Rs."+totBill);
		System.out.println("Thank you for choosing Tasty Treats Cafe! Please let us know your order, and we will be more than happy to serve you.");
		
		

	}

}
