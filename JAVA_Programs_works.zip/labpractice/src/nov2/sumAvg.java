package nov2;

public class sumAvg {
	public static float sum(float a, float b, float c) {
		return a+b+c;
	}
	public static float avg(float a, float b, float c) {
		return (a+b+c)/3;
	}
public static void main(String[] args) {
	float a,b,c;
	a = Float.parseFloat(args[0]);
	b = Float.parseFloat(args[1]);
	c = Float.parseFloat(args[2]);
	
	System.out.println("Sum of three numbers:"+sum(a,b,c));
	System.out.println("Sum of three numbers:"+avg(a,b,c));
	}
}

