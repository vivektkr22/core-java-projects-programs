package nov2;

public class cube{

	public static void main(String[] args) {
		int n = Integer.parseInt(args[0]);
		
		int c = n*n*n;
		System.out.println("Cube of a number is: "+ c);

	}

}
