package nov2;

public class addAsciiValue {

	public static void main(String[] args) {
		char a = args[0].charAt(0);
		char b = args[1].charAt(0);
		
		int sum = a+b;
		
		System.out.println(sum);
		

	}

}
