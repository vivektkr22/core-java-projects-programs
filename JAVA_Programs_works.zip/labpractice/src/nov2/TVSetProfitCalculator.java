package nov2;

public class TVSetProfitCalculator {

	public static void main(String[] args) {
		 float cp,p,vat,sc;
	        
	        cp = Float.parseFloat(args[0]);
	        p = Float.parseFloat(args[1]);
	        vat = Float.parseFloat(args[2]);
	        sc = Float.parseFloat(args[3]);
	        
	        float profit = ((cp*p)/100);
	        float VAT = ((cp+profit)*vat)/100;
	        float sellp = ((cp+profit)*sc)/100;
	        float totsell = profit+VAT+sellp+cp;
	        
	        System.out.println("Cost Price: RS."+cp);
	        System.out.println("Profit: RS."+profit);
	        System.out.println("VAT: RS."+VAT);
	        System.out.println("Service Charge: RS."+sellp);
	        System.out.println("Total  Selling Price: RS."+totsell);
	}

}
