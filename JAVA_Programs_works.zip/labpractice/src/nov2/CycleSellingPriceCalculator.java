package nov2;

public class CycleSellingPriceCalculator {

	public static void main(String[] args) {
		  float incost,repcost,colcost,acecost,totcost,desprofit,sellprice;
	        
	        incost = Float.parseFloat(args[0]);
	        repcost = Float.parseFloat(args[1]);
	        colcost = Float.parseFloat(args[2]);
	        acecost = Float.parseFloat(args[3]);
	        desprofit = Float.parseFloat(args[4]);
	        
	         totcost = incost+repcost+acecost+colcost;
	            
	         sellprice = totcost+desprofit;
	         
	         System.out.println("Initial cost: Rs."+ incost);
	         System.out.println("Repair cost: Rs."+ repcost);
	         System.out.println("Coloring cost: Rs."+ colcost);
	         System.out.println("Accessories cost: Rs."+ acecost);
	         System.out.println("Total cost: Rs."+ totcost);
	         System.out.println("Desired profit: Rs."+ desprofit);
	         System.out.println("Selling price: Rs."+ sellprice);
	         

	}

}
