//Write a program to calculate the tax for a taxable income of Rs.9,90,000, if the tax rate is fixed at 4.9%.

package nov2;

public class calculateTax {
       public static void main(String[] args) {
	    float ic = 990000, tr = 4.9f, tax;
	    tax = (ic*tr/100);
	    System.out.println("The "+tr+"%"+" tax of "+ic+" income is: "+ tax);
}
}
