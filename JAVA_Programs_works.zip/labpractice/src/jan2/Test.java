package jan2;

public class Test extends Car {
      
	public static void main(String[] args) {
		Test t = new Test();
		t.carBrand();
		t.carModel();
		t.carMileage();
		t.carTopSpeed();
		t.carYear();
		t.display();
		
	}

	@Override
	void display() {
		System.out.println("Car name: "+brand+"\nModel name: "+model+"\nMileage: "+mileage+"\nTop Speed: "+topSpeed+"\nManufacturing date: "+yearOfManufacturing);
	}
}
