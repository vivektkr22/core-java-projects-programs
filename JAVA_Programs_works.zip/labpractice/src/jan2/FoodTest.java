package jan2;

import java.util.Scanner;

public class FoodTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);		
		System.out.print("Enter the number of food items: ");
		int noOfFoodItems = sc.nextInt();
		System.out.print("Enter the food: ");
		String food = sc.next();
	    
		System.out.println("Ordered items: "+noOfFoodItems);
		
		if(food.equals("bread")) {
			for(int i=0; i<noOfFoodItems; i++) {
				Bread bread = new Bread(4.0, 1.1, 13.8);
				System.out.println("Bread is: "+bread.getType());
				bread.getMacroNutrients();
				System.out.println("Taste: "+bread.tastyScore);
				System.out.println("----------------------------------------------------");
			}
		}
		else if(food.equals("egg")) {
			for(int i=0; i<noOfFoodItems; i++) {
				Egg egg = new Egg(5.1,2.0,15.6);
				System.out.println("Egg is: "+egg.getType());
				egg.getMacroNutrients();
				System.out.println("Taste: "+egg.getTastyScore());
				System.out.println("------------------------------------------------------");
			}
		}
		
		sc.close();
	}

	private static void toLowerCase(String food) {
		// TODO Auto-generated method stub
		
	}
}
