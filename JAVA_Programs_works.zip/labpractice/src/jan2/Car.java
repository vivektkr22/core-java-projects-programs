package jan2;

public abstract class Car {
   String brand;
   String model;
   int mileage;
   int topSpeed;
   int yearOfManufacturing;
   
   Car(){
	   
   }
   
   public String carBrand(){
	   brand = "BMW";
	   return brand;
   }
   
   public String carModel(){
	   model = "X3";
	   return model;
   }

   public int carMileage(){
	   mileage = 15;
	   return mileage;
   }
   
   public int carTopSpeed(){
	   topSpeed = 300;
	   return topSpeed;
   }
   
   public int carYear() {
	   yearOfManufacturing = 2022;
	   return yearOfManufacturing;
   }
   
   abstract void display();
}
