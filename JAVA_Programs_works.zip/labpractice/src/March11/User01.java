package March11;
/*Que-2
______________________________
You are required to implement a system that utilizes interfaces and dynamic class loading in Java. The system involves defining interfaces, implementing classes, and dynamically loading classes at runtime.

Specifications:

Interface Definition:
--------------------------------
Define an interface named I1 with a method m1() which returns an integer.

Class Implementations:
---------------------------------
Implement a class A that implements I1.
A should have integer fields a and b.
Implement a parameterless constructor and a parameterized constructor that initializes a and b.
Override the m1() method to return the sum of a and b.
Implement getter and setter methods for a and b.
Implement another class B that also implements I1.
B should have integer fields a and b.
Implement a parameterless constructor and a parameterized constructor that initializes a and b.
Override the m1() method to return the product of a and b.
Implement getter and setter methods for a and b.

Class C:
---------------------------------
Implement a class named C with a method display(int a1, int b1).
Based on the user choice:-
Inside display, instantiate an object of class B, set its fields using the provided parameters, and invoke the m1() method.
Print the result obtained from m1().
Inside display, instantiate an object of class A, set its fields using the provided parameters, and invoke the m1() method.

Print the result obtained from m1().

Dynamic Class Loading:
----------------------------------
In the User01 class main method, use dynamic class loading to instantiate an object of class A and B.
[Use the field initilization by calling paramterize constructor ]
[After that try with setter method to initilize the fields]
[Don't use new keyword to create the Object of the class , use some other functionality 
 which will create the object of the class and then you can call the methods]
[Create that type of code so that if you switch from one class to another class you have to change 
  only few things not the all code :-
 For Eg :- First we are creating the object of class A and call the m1() of class A 
           then we want to call the m1() of class B then you have to change the code of object creation
           for that we have to find some solution].

Invoke the m1() method and print the result.
____________________________________________________________________________________________________________*/

//Interface I1
interface I1 {
 int m1();
}

//Class A implementing interface I1
class A implements I1 {
 private int a;
 private int b;

 // Parameterized constructor
 public A(int a, int b) {
     this.a = a;
     this.b = b;
 }

 // Default constructor
 public A() {}

 // Getter and setter methods for a and b
 public int getA() {
     return a;
 }

 public void setA(int a) {
     this.a = a;
 }

 public int getB() {
     return b;
 }

 public void setB(int b) {
     this.b = b;
 }

 // Override m1() method to return the sum of a and b
 @Override
 public int m1() {
     return a + b;
 }
}

//Class B implementing interface I1
class B implements I1 {
 private int a;
 private int b;

 // Parameterized constructor
 public B(int a, int b) {
     this.a = a;
     this.b = b;
 }

 // Default constructor
 public B() {}

 // Getter and setter methods for a and b
 public int getA() {
     return a;
 }

 public void setA(int a) {
     this.a = a;
 }

 public int getB() {
     return b;
 }

 public void setB(int b) {
     this.b = b;
 }

 // Override m1() method to return the product of a and b
 @Override
 public int m1() {
     return a * b;
 }
}

//Class C
class C {
 // Method to display result based on user choice
 public void display(int a1, int b1, String className) throws ClassNotFoundException, IllegalAccessException, InstantiationException {
     // Dynamically load class based on className parameter
     Class<?> clazz = Class.forName(className);
     I1 obj = (I1) clazz.newInstance(); // Instantiate object of loaded class

     // Set fields using provided parameters
     if (obj instanceof A) {
         A aObj = (A) obj;
         aObj.setA(a1);
         aObj.setB(b1);
     } else if (obj instanceof B) {
         B bObj = (B) obj;
         bObj.setA(a1);
         bObj.setB(b1);
     }

     // Invoke m1() method and print the result
     System.out.println("Result: " + obj.m1());
 }
}

//User01 class
public class User01 {
 public static void main(String[] args) throws ClassNotFoundException, IllegalAccessException, InstantiationException {
     // Using dynamic class loading to instantiate objects of class A and B
     C c = new C();

     // Dynamically instantiate object of class A
     c.display(3, 4, "A");

     // Dynamically instantiate object of class B
     c.display(3, 4, "B");
 }
}
