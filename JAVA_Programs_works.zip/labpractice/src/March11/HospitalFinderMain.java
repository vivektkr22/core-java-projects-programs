package March11;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

class Hospital{
	private Integer hospitalCode;
	private String hospitalName;
	private List<String> listOfTreatment;
	private String contactPerson;
	private String number;
	private String location;
	
	public Hospital(Integer hospitalCode, String hospitalName, List<String> treatments, String contactPerson, String contactNumber,
			String location) {
		super();
		this.hospitalCode = hospitalCode;
		this.hospitalName = hospitalName;
		this.listOfTreatment = treatments;
		this.contactPerson = contactPerson;
		this.number = contactNumber;
		this.location = location;
	}

	public Integer getHospitalCode() {
		return hospitalCode;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public List<String> getlistOfTreatment() {
		return listOfTreatment;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public String getNumber() {
		return number;
	}

	public String getLocation() {
		return location;
	}

	public void setHospitalCode(Integer hospitalCode) {
		this.hospitalCode = hospitalCode;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public void setAl(ArrayList<String> listOfTreatment) {
		this.listOfTreatment = listOfTreatment;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "Hospital [hospitalCode=" + hospitalCode + ", hospitalName=" + hospitalName + ", listOfTreatment=" + listOfTreatment
				+ ", contactPerson=" + contactPerson + ", number=" + number + ", location=" + location + "]";
	}

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
	
}

class HospitalService{
	 private List<Hospital> hospitals;

	    // Constructor to load hospital data from properties file
	    public HospitalService(String propertiesFilePath) {
	        hospitals = new ArrayList<>();
	        loadHospitalData(propertiesFilePath);
	    }

	    // Load hospital data from properties file
	    private void loadHospitalData(String propertiesFilePath) {
	        Properties properties = new Properties();
	        try (FileInputStream fis = new FileInputStream(propertiesFilePath)) {
	            properties.load(fis);

	            // Iterate over properties to create Hospital objects
	            Set<String> keys = properties.stringPropertyNames();
	            for (String key : keys) {
	                if (key.startsWith("hospital")) {
	                    int hospitalCode = Integer.parseInt(key.substring(8, key.indexOf('.')));
	                    String name = properties.getProperty(key + ".name");
	                    List<String> treatments = Arrays.asList(properties.getProperty(key + ".treatments").split(","));
	                    String contactPerson = properties.getProperty(key + ".contactPerson");
	                    String contactNumber = properties.getProperty(key + ".contactNumber");
	                    String location = properties.getProperty(key + ".location");

	                    Hospital hospital = new Hospital(hospitalCode, name, treatments, contactPerson, contactNumber, location);
	                    hospitals.add(hospital);
	                }
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    // Returns a map of hospital codes and names
	    public Map<Integer, String> getHospitals() {
	        Map<Integer, String> hospitalMap = new HashMap<>();
	        for (Hospital hospital : hospitals) {
	            hospitalMap.put(hospital.getHospitalCode(), hospital.getHospitalName());
	        }
	        return hospitalMap;
	    }

	    // Returns details of the hospital corresponding to the given hospital code
	    public Hospital getHospitalDetails(int hospitalCode) {
	        for (Hospital hospital : hospitals) {
	            if (hospital.getHospitalCode() == hospitalCode) {
	                return hospital;
	            }
	        }
	        return null;
	    }
	
}

public class HospitalFinderMain {
    public static void main(String[] args) {
        HospitalService hospitalService = new HospitalService("/labpractice/src/March11/Hospital.properties");

        // Display hospitals and their codes
        Map<Integer, String> hospitalMap = hospitalService.getHospitals();
        System.out.println("Hospitals and their codes:");
        for (Map.Entry<Integer, String> entry : hospitalMap.entrySet()) {
            System.out.println("Hospital Code: " + entry.getKey() + ", Hospital Name: " + entry.getValue());
        }

        // Retrieve and display details of hospitals using sample hospital codes
        int sampleHospitalCode1 = 1;
        int sampleHospitalCode2 = 2;

        Hospital hospital1 = hospitalService.getHospitalDetails(sampleHospitalCode1);
        Hospital hospital2 = hospitalService.getHospitalDetails(sampleHospitalCode2);

        if (hospital1 != null) {
            System.out.println("\nDetails for Hospital with Code " + sampleHospitalCode1 + ":");
            System.out.println(hospital1);
        } else {
            System.out.println("\nHospital with Code " + sampleHospitalCode1 + " not found.");
        }

        if (hospital2 != null) {
            System.out.println("\nDetails for Hospital with Code " + sampleHospitalCode2 + ":");
            System.out.println(hospital2);
        } else {
            System.out.println("\nHospital with Code " + sampleHospitalCode2 + " not found.");
        }
    }
}
