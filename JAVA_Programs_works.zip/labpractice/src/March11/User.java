package March11;
/*Que-1>
__________________________________________________________________________________________
You are tasked with designing a system for managing different modes of operation for car engines. The system must incorporate various engine states such as operational, failure with possibility of retry, and needing servicing.

Specifications:

Engine Interface:
-------------------------
Define an interface named Engine with a method mode() which returns an integer representing the current mode of the engine.

Engine Modes:
-------------------------
Implement three classes MockSuccessEngine, MockFailAndRetryEngine, and MockServicingEngine, all of which implement the Engine interface.
MockSuccessEngine: Represents a fully operational engine (mode 0).
MockFailAndRetryEngine: Represents an engine that has failed with possibility of retry (mode 1).
MockServicingEngine: Represents an engine in need of servicing (mode 2).

Car Class:
-------------------------
Define a class named Car which has a relationship with an Engine.
Implement a constructor in Car class that takes an Engine object as parameter to set the engine.
Implement a method drive(int model) in Car class which takes an integer representing the desired model of the engine operation.
If the mode is 0, print "Engine started".
If the mode is 1, print "Engine fail kindly try once!".
If the mode is 2, print "Need Servicing!!!!".
If the mode is other than 0, 1, or 2, print "Invalid Input".

User Interaction:
-------------------------
In the User class main method, create instances of Car with different types of engine modes (MockSuccessEngine, MockFailAndRetryEngine, and MockServicingEngine).
Call the drive method for each instance of Car with various model inputs to observe the behavior.
_____________________________________________________________________________________________________________*/

//Engine Interface
interface Engine {
	int mode();
}

//MockSuccessEngine class
class MockSuccessEngine implements Engine {
	@Override
	public int mode() {
		return 0; // Operational mode
	}
}

//MockFailAndRetryEngine class
class MockFailAndRetryEngine implements Engine {
	@Override
	public int mode() {
		return 1; // Failure with possibility of retry mode
	}
}

//MockServicingEngine class
class MockServicingEngine implements Engine {
	@Override
	public int mode() {
		return 2; // Need servicing mode
	}
}

//Car class
class Car {
	private Engine engine;

	// Constructor
	public Car(Engine engine) {
		this.engine = engine;
	}

	// Method to drive the car based on engine mode
	public void drive(int model) {
		switch (model) {
		case 0:
			System.out.println("Engine started");
			break;
		case 1:
			System.out.println("Engine fail kindly try once!");
			break;
		case 2:
			System.out.println("Need Servicing!!!!");
			break;
		default:
			System.out.println("Invalid Input");
		}
	}
}

//User class
public class User {
	public static void main(String[] args) {
		// Create instances of Car with different engine modes
		Car carWithSuccessEngine = new Car(new MockSuccessEngine());
		Car carWithFailAndRetryEngine = new Car(new MockFailAndRetryEngine());
		Car carWithServicingEngine = new Car(new MockServicingEngine());

		// Call the drive method for each instance of Car with various model inputs
		carWithSuccessEngine.drive(0); // Engine started
		carWithFailAndRetryEngine.drive(1); // Engine fail kindly try once!
		carWithServicingEngine.drive(2); // Need Servicing!!!!

		// Testing invalid input
		carWithSuccessEngine.drive(3); // Invalid Input
	}
}
