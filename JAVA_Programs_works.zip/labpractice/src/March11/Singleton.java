package March11;

public class Singleton {
    private static Singleton instance;

    private Singleton() {

    }


    public static Singleton getInstance() {
        if (instance == null) {
            instance = new Singleton();
        }
        return instance;
    }

    public void displayMessage() {
        System.out.println("Singleton instance is created!");
    }

    public static void main(String[] args) {
  
        Singleton singletonInstance1 = Singleton.getInstance();
        Singleton singletonInstance2 = Singleton.getInstance();
        System.out.println(singletonInstance1);
        System.out.println(singletonInstance2);

    
        System.out.println("Are the instances the same? " + (singletonInstance1 == singletonInstance2));


        singletonInstance1.displayMessage();

    }
}

