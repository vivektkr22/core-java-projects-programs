package nov11a;
import java.util.*;
public class PrintPattern {

	public static void main(String[] args) {
		    Scanner scan = new Scanner(System.in);
	        System.out.println("Enter the number of rows:");
	        int row = scan.nextInt();
	        String pattern = Pattern.patternPrinter(row);
	        System.out.println(pattern);
	        
	        scan.close();
	}

}
