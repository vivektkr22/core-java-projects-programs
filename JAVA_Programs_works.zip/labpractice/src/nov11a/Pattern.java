package nov11a;

public class Pattern {
    public static String patternPrinter(int row) {
        return patternCreator(row);
    }

    public static String patternCreator(int row) {
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < row; i++) {
           
            for (int j = 0; j < i; j++) {
                result.append("  ");
            }

            for (char ch = (char) ('E' - i); ch >= 'A'; ch--) {
                result.append(ch).append(" ");
            }

            result.append("\n");
        }

        return result.toString();
    }
}
