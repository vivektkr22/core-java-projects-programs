package decc30;

public class ProductEquality {

	public static void main(String[] args) {
		Product p1 = new Product(101,"Laptop");
		Product p2 = new Product(101,"Laptop");
		
		System.out.println(p1.equals(p2));
	}

}
