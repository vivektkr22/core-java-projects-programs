package decc30;

public class Product {
     private int productId;
     private String productName;
     
	public Product(int productId, String productName) {
		super();
		this.productId = productId;
		this.productName = productName;
	}
	
	@Override
	public boolean equals(Object obj) {
		
		//First object data
		int pId1 = this.productId;
		String pName1 = this.productName;
		
		//Second object data
		Product p2 = (Product) obj;
		int pId2 = p2.productId;
		String pName2 = p2.productName;
		
		if(pId1 == pId2 && pName1.equals(pName2)) {
			return true;
		}
		else {
			return false;
		}		
	}     
}
