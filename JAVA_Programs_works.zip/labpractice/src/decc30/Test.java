package decc30;

public class Test {

	public static void main(String[] args) {
	        Soccer s1 = new Soccer(); 
	        System.out.println(s1.getNumberOfTeamMembers()); 
   }
}
