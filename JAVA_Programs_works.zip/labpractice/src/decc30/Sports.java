package decc30;

class Sports {
 public Sports() {
	}

public String getName(String sport) {
     return "Sports";
 }

 public String getNumberOfTeamMembers() {
     return "Each team has n players in Sports";
 }
}
	
