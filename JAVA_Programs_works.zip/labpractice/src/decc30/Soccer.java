package decc30;

class Soccer extends Sports {
    @Override
    public String getName(String sport) {
        return sport;
    }

    @Override
    public String getNumberOfTeamMembers() {
        return "In " + getName("Soccer") + ", \neach team has 11 players";
    }
}

