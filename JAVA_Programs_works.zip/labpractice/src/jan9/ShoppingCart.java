package jan9;

public class ShoppingCart {
   private CartItem item;

public ShoppingCart(CartItem item) {
	super();
	this.item = item;
}
   
}
