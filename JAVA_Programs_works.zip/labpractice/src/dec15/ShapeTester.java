package dec15;

class Circle{
	//Declare instance variables
    private double radius;
	
	//default constructor to assign radius value to 5 by default
	Circle(){
	    this.radius = 5;
	}
	
	//parameterized constructor to assign radius value dynamically
	Circle(double radius){
		this.radius = radius;
	}
	
	//this method is used to calculate the area of a circle and returns
	public double getArea() {
		return radius*radius*3.14;
	}
}

//Cylinder is a subclass of Circle
class Cylinder extends Circle{
	//Declare instance variables
     private double height;

	//default constructor to assign height value to 5 by default
	Cylinder(){
		this.height = 5;
	}
	
	
	//parameterized constructor to assign radius and height values dynamically
	Cylinder(double radius , double height){
		//call super class's parameterized constructor by passing required values
		super(radius);
		this.height = height;
		
	}
	
	//this method calculates and returns volume of Cylinder
	public double getVolume() {
		return getArea()*height;
	}


	@Override
	public String toString() {
		return "Cylinder [height=" + height + ", getVolume()=" + getVolume() + ", getArea()=" + getArea()
				+ ", toString()=" + super.toString() + "]";
	}


		
	
}

//ELC method to test our code
public class ShapeTester {

	public static void main(String[] args) {
		//create an object to Cylinder class. don't pass values.
		Cylinder c1 = new Cylinder();
		//call getVolume and getArea methods and print details
		System.out.println("Volume: "+c1.getVolume());
		System.out.println("Area: "+c1.getArea());
		
		//create an object to Cylinder class by passing values like (6,12)
		Cylinder c2 = new Cylinder(6,12);
		//call getVolume and getArea methods and print details
		System.out.println("Volume: "+c2.getVolume());
		System.out.println("Area: "+c2.getArea());
	}

}

