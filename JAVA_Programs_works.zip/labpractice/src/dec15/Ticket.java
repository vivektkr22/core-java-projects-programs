package dec15;

public class Ticket {

	//Declare instance variables
	private String eventName;
    private int seatNumber;
    private double price;

    //create parameterized constructor and assign instance variables
	public Ticket(String eventName, int seatNumber, double price) {
		super();
		this.eventName = eventName;
		this.seatNumber = seatNumber;
		this.price = price;
	}

	
	//generate getters and setters
	public String getEventName() {
		return eventName;
	}

	public int getSeatNumber() {
		return seatNumber;
	}

	public double getPrice() {
		return price;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}

	public void setPrice(double price) {
		this.price = price;
	}


	//override toString method to print object details
	@Override
	public String toString() {
		return "Ticket [eventName=" + eventName + ", seatNumber=" + seatNumber + ", price=" + price + "]";
	}
		
}

