package dec15;

public class VIPTicket extends Ticket{
	//Declare instance variables
    private String specialAccess;
    
	//create parameterized constructor and assign values to instance variables
	public VIPTicket(String eventName, int seatNumber, double price, String specialAccess) {
		super(eventName, seatNumber, price);
		this.specialAccess = specialAccess;
	}

	
	//generate setter and getter methods
	public String getSpecialAccess() {
		return specialAccess;
	}

	public void setSpecialAccess(String specialAccess) {
		this.specialAccess = specialAccess;
	}


	//override toString method to print object details
	@Override
	public String toString() {
		return "VIPTicket [specialAccess=" + specialAccess + ", getEventName()=" + getEventName() + ", getSeatNumber()="
				+ getSeatNumber() + ", getPrice()=" + getPrice() + ", toString()=" + super.toString() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + "]";
	}
	
	
}
