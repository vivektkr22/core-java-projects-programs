package dec15;

public class StudentTicket extends Ticket{

	//declare instance variables
	private boolean studentDiscount;
	
	//create parameterized constructor and assign values to instance variables
	public StudentTicket(String eventName, int seatNumber, double price, boolean studentDiscount) {
		super(eventName, seatNumber, price);
		this.studentDiscount = studentDiscount;
	}

	
	//Generate Getters and setters for Instance variables
	public boolean isStudentDiscount() {
		return studentDiscount;
	}

	public void setStudentDiscount(boolean studentDiscount) {
		this.studentDiscount = studentDiscount;
	}


	//override toString method to print object details
	@Override
	public String toString() {
		return "Student Ticket [Event =" + getEventName() + ", Seat Number=" + getSeatNumber()
				+ ", Price=" + getPrice() + ", getPrice()=" + getPrice() + ", toString()="
				+ super.toString() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}
	
}

