package dec15;

public class MainTicket {

	public static void main(String[] args) {
		
		//Creating a Ticket object using the parameterized constructor and print object details
		Ticket t1 = new Ticket("Concert1",101,1000);
		
		//Creating a VIPTicket object using the parameterized constructor and print object details
	    VIPTicket vt1 = new VIPTicket("VIP Concert",201,5000,"BackStage Access");
		
		//Creating a StudentTicket object using the parameterized constructor and print object details
		StudentTicket st1 = new StudentTicket("Student Event",301,500,true);

		System.out.println("Regulor Ticket");
		System.out.println("Event: "+t1.getEventName());
		System.out.println("Seat Number: "+t1.getSeatNumber());
		System.out.println("Price: "+t1.getPrice());
		System.out.println("====================================");
		System.out.println("VIP Ticket");
		System.out.println("Event: "+vt1.getEventName());
		System.out.println("Seat Number: "+vt1.getSeatNumber());
		System.out.println("Price: "+vt1.getPrice());
		System.out.println("Special Access: "+vt1.getSpecialAccess());
		System.out.println("=====================================");
		System.out.println("Student Ticket");
		System.out.println("Event: "+st1.getEventName());
		System.out.println("Seat Number: "+st1.getSeatNumber());
		System.out.println("Price: "+st1.getPrice());
		System.out.println("Student Discount: "+st1.isStudentDiscount());
	}

}
