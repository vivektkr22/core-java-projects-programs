package nov4;

public class NetBillBasedOnDiscount {

	public static void main(String[] args) {
		float n,dis,disamt;
		
		n = Integer.parseInt(args[0]);
		
		if(n<5000) {
			dis =5;
			disamt = (n*dis)/100;
		}
		else if(n>=5000 && n<10000) {
			dis =10;
			disamt = (n*dis)/100;
		}
		else {
			dis = 15;
			disamt = (n*dis)/100;
		}
		
		System.out.println("Net Bill: "+n);
		System.out.println("Discount Percentage: "+dis+"%");
		System.out.println("Discount Amount:"+disamt);
		System.out.println("Amount Payable:"+(n-disamt));

	}

}
