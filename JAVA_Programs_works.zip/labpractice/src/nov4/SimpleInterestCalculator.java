package nov4;

public class SimpleInterestCalculator {

	public static void main(String[] args) {
		float p,t,r,si,tot;
		 
		p = Integer.parseInt(args[0]);
		r = Integer.parseInt(args[1]);
		t = Integer.parseInt(args[2]);
		
		si=(p*r*t)/100;
		tot = p+si;
		
		System.out.println("Enter the Principal Amount: "+p);
		System.out.println("Enter the Rate of Interest (in percentage): "+r);
		System.out.println("Enter the Time (in years): "+t);
		System.out.println("Simple Interest: Rs."+si);
		System.out.println("Total Amount: Rs."+tot);

	}

}
