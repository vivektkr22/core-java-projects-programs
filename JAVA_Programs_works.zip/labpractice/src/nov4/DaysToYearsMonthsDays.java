package nov4;

public class DaysToYearsMonthsDays {

	public static void main(String[] args) {
		int n,y,m,d;
		
	 n = Integer.parseInt(args[0]);
	 
	 y = n/365;
	 m = (n%365)/30;
	 d = (n%365)%30;
	 
	 System.out.println("Year: "+y);
	 System.out.println("Month: "+m);
	 System.out.println("Date: "+d);
	 

	}

}
