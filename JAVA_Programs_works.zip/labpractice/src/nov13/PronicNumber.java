package nov13;

import java.util.Scanner;

public class PronicNumber {
	public static boolean isPronicNumber(int num) {
		int i,j;
		for(i=1,j=2; i<=num/2; i++,j++) {
			if(i*j==num) return true;
		}
		return false;
	}

	public static void main(String[] args) {
		Scanner scan  = new Scanner(System.in);
		System.out.println("Enter a number");
		int num = scan.nextInt();
		
		scan.close();
		
		if(isPronicNumber(num)) System.out.println("Pronic Number");
		else System.out.println("Not a Pronic Number");
	}

}
