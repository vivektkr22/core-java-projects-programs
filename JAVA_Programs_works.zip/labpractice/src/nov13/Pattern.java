package nov13;

import java.util.Scanner;

public class Pattern {
    
    public static void printPattern(int num) {
        for (int i = 1; i <= num; i++) {
            for (int k = 0; k < num - i; k++) {
                System.out.print(" "); // Changed println to print here
            }
            for (int j = 1; j <= i; j++) {
                System.out.print("* "); // Print the stars with a space
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter a number");
        int num = scan.nextInt();

        printPattern(num);
        scan.close();
    }
}
