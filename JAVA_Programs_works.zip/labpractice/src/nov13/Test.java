package nov13;

public class Test {

public static void main(String[] args) {
	byte b =2;
	switch(b)
	{ case 23:System.out.println("23");
	case 127:System.out.println("28");
	case 2 :System.out.println("2");
	default :System.out.println("default");
	}
}
}
