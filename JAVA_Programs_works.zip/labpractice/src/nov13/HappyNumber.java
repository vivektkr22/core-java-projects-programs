package nov13;

import java.util.Scanner;

public class HappyNumber {
	public static boolean isHappyNumber(int num) {
		int sum=0;
		do {
				 sum=0;
				while(num!=0) {
					int rem = num%10;
					sum = sum + rem*rem;
					num/=10;
				}
				num = sum;
		}while(num>9);
		
			return sum==1;
	}

	public static void main(String[] args) {
		Scanner scan  = new Scanner(System.in);
		System.out.println("Enter a number");
		int num = scan.nextInt();
		
		scan.close();
		
		if(isHappyNumber(num)) System.out.println("Happy Number");
		else System.out.println("Not a Happy Number");
	}

}
