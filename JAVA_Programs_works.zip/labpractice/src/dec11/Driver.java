package dec11;

public class Driver {
	
	//Declare instance variables
	private String name;
	private int age;
	
	
	//create a constructor to initialize instance variables
	public Driver(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}


	//generate setters and getter for instance variables
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


//override to string method
	@Override
	public String toString() {
		return "Driver [name=" + name + ", age=" + age + "]";
	}

}

