package dec11;



@FunctionalInterface 
interface Str
{
	String str(String str);
}

public class FunctionalInter {
	public static void main(String[] args) {
		Str jhjh = s -> "Naresh"+s;
		System.out.println(jhjh.str("IT"));	
	}
}
