package dec11;

public class Car {

	//Declare instance variables
	 private String brand;
	 private String model;
	 private int year;
	 private Driver driver;
	 
	//create a constructor to initialize instance variables
	public Car(String brand, String model, int year, Driver driver) {
		super();
		this.brand = brand;
		this.model = model;
		this.year = year;
		this.driver = driver;
	}
	 
	 // create a constructor with Car as a parameter and initialise instance variables;
     public Car(Car car) {
    	 this.brand = car.brand;
    	 this.model = car.model;
    	 this.year = car.year;
    	 this.driver = car.driver;
     }

	 //create a method called changeDriver(). parameter is of type Driver. return type void.
	 // this method changes current driver to new driver
     public void changeDriver(Driver newDriver) {
  		 this.driver = newDriver;
  	}
	 
	 // create getters and setters for all instance variables
     public String getBrand() {
 		return brand;
 	}

 	public void setBrand(String brand) {
 		this.brand = brand;
 	}

 	public String getModel() {
 		return model;
 	}

 	public void setModel(String model) {
 		this.model = model;
 	}

 	public int getYear() {
 		return year;
 	}

 	public void setYear(int year) {
 		this.year = year;
 	}

 	public Driver getDriver() {
 		return driver;
 	}

 	public void setDriver(Driver driver) {
 		this.driver = driver;
 	}

 	
	//override toString method
     @Override
 	public String toString() {
 		return "Car [brand=" + brand + ", model=" + model + ", year=" + year + ", driver=" + driver + "]";
 	}
	 
}

