package dec11;

public class Employee {
	
	// Declare instance variables
	private String name;
	private int age;
	private double salary;
	private String department;
	
	// Create a constructor to initialize instance variables
    public Employee(String name, int age, double salary, String department){
        this.name = name;
        this.age = age;
        this.salary = salary;
        this.department = department;
    
    }
	
	//create a constructor to initialize instance variables using Employee parameter
	public Employee(Employee orignal){
	    this.name = orignal.name;
	    this.age = orignal.age;
	    this.salary = orignal.salary;
	    this.department = orignal.department;
	}
	
	//create raiseSalary method by passing percentage as parameter. type double
	public  double raiseSalary(double per){
	    return this.salary += salary*per/100;
	}
	
	//override toString method
		public String toString(){
		    return "Employee Name: "+name+", Age: "+age+", Salary: "+salary+", Department: "+department;
		}
	
	}



