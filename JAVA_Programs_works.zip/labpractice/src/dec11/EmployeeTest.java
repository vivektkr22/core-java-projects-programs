package dec11;

public class EmployeeTest {

	public static void main(String[] args) {
		// create employee object by passing values like Name, age, salary and department;
		Employee orignal = new Employee("Rohit",35,15000,"Hr");

		//create employee1 object by passing employee as parameter
		Employee duplicate = new Employee(orignal);
		
		System.out.println(orignal);
		System.out.println(duplicate);
		System.out.println("====================================================================");
		//increment employee salary by 10 percent
		duplicate.raiseSalary(10);
		
		// print both employee and employee1 
		System.out.println(orignal);
		System.out.println(duplicate);
	}

}

