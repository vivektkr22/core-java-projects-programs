package dec11;

public class CarMain {

    public static void main(String[] args) {
        // Create an object to Driver class with driver name and age
        Driver originalDriver = new Driver("Ramu", 45);

        // Create an object to Car class with car model, type, year, and driver
        Car originalCar = new Car("BMW", "A7", 2023, originalDriver);

        // Assume that this is an original car
        System.out.println("Original Car Details:"+originalCar);

        // Create an object car class as copyCar by passing original car object reference as parameter
        Car copiedCar = new Car(originalCar);
        
        // Print both car and copy car details
        System.out.println("\nCopied Car Details:"+copiedCar);

        // Create a new driver with different name and age
        Driver newDriver = new Driver("Alice", 24);

        // Call changeDriver method by using the original car's object reference to change the driver
        originalCar.changeDriver(newDriver);

        // Print both car and copy car details
        System.out.println("\nAfter Changing Driver - Original Car Details:"+originalCar);

        System.out.println("\nAfter Changing Driver - Copied Car Details:"+copiedCar);

    }

}
