package jan5;

public interface AdvancedArithmetic {
       public int divisorSum(int n);
}
