package jan5;

public class CalculatorTest {

	public static void main(String[] args) {
		MyCalculator myCalculator = new MyCalculator();
		int result = myCalculator.divisorSum(6);
		
		System.out.println("Sum of divisors of "+6+" is : "+result);
	}

}
