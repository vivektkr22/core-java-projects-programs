package jan5;

public class Jio implements SimCard{
	long number;
	String network;
	boolean isActivated;

	public Jio(long number, String network) {
		super();
		this.number = number;
		this.network = network;
	}

	@Override
	public long getNumber() {
		// TODO Auto-generated method stub
		return number;
	}

	@Override
	public String getNetworkProvider() {
		// TODO Auto-generated method stub
		return network;
	}

	@Override
	public boolean isActivated() {
		// TODO Auto-generated method stub
		return isActivated;
	}

	@Override
	public void makeActivate(boolean activate) {
		this.isActivated = activate;

	}
	
}
