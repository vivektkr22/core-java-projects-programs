package jan5;

public interface MobilePhone {
	void insert(SimCard sim);

	void remove(SimCard sim);

	void call(SimCard sim);

	void sms(SimCard sim);
}
