package jan5;

public class User {

	public static void main(String[] args) {
        Jio j = new Jio(11111111,"4G");
        Airtel a = new Airtel(2222222, "5G");
        BSNL b = new BSNL(3333333,"3G");
        
        Mobile m = new Mobile();
        
        m.insert(j);
        m.call(a);
        m.sms(j);
        m.remove(j);  
        
	}
}
