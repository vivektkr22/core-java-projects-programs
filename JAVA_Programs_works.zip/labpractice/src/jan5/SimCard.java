package jan5;

public interface SimCard {
	long getNumber();

	String getNetworkProvider();

	boolean isActivated();

	void makeActivate(boolean activate);
}
