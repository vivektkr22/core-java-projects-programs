package jan5;

public class Mobile implements MobilePhone{
	@Override
	public void insert(SimCard sim) {
		if (sim.isActivated() == false) {
			sim.makeActivate(true);
			System.out.println("Sim is inserted");
			System.out.println("Sim card : " + sim.getClass().getSimpleName());
			System.out.println("Number is : " + sim.getNumber());
			System.out.println("Network : " + sim.getNetworkProvider());
		} else {
			System.out.println("Sim is already inserted...");
		}

	}

	@Override
	public void remove(SimCard sim) {
        if(sim.isActivated()) {
        	sim.makeActivate(false);
        	System.out.println(sim.getClass().getSimpleName()+ " is removed");
        }else {
        	System.out.println("Sim never inserted");
        }
	}

	@Override
	public void call(SimCard sim) {
        if(sim.isActivated()){
        	System.out.println("Calling from "+sim.getClass().getSimpleName());
        }else {
        	System.out.println("Sim is not activated");
        }
	}

	@Override
	public void sms(SimCard sim) {
		if(sim.isActivated()){
        	System.out.println("Sms from "+sim.getClass().getSimpleName());
        }else {
        	System.out.println("Sim is not activated");
        }
	}
    
}
