package nov21;
import java.util.Scanner;

public class UglyNumber {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number: ");
        int n = sc.nextInt();

        if (n <= 0) {
            System.out.println("Not a Ugly number");
        } else {
            int f = 0;
            while (n != 0) {
                if (n % 2 == 0) {
                    n /= 2;
                } else if (n % 3 == 0) {
                    n /= 3;
                } else if (n % 5 == 0) {
                    n /= 5;
                } else {
                    f = 1;
                    System.out.println("Not an ugly number");
                    break;
                }
            }
            if (f == 0) {
                System.out.println("Ugly number");
            }
        }
        sc.close();
    }
}
