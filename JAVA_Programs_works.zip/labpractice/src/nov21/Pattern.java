/* 2)write a program to print pattern using printInvertedPyramid() in java

123456789
 1234567
  12345
   123
    1 */


package nov21;

import java.util.Scanner;

public class Pattern {

    public static void printInvertedPyramid(int n) {
        for (int i = 0; i < n; i++) {
            // Printing spaces
            for (int j = 0; j < i; j++) {
                System.out.print(" ");
            }

            // Printing numbers
            for (int j = 1; j <= 2 * (n - i) - 1; j++) {
                System.out.print(j);
            }

            System.out.println(); // Moving to the next line
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number:");
        int n = sc.nextInt();

        printInvertedPyramid(n);
        sc.close();
    }
}
