package nov21;
import java.util.Scanner;

public class SecondsConversionUsingSwitch {

	public static void main(String[] args) {
		
		//create a scanner object and read seconds and conversion options from the user
	    Scanner sc = new Scanner(System.in);
	    System.out.print("Enter a number of seconds: ");
	    float n = sc.nextFloat();
	    System.out.print("Please select below option to convert\n(1)Days\n(2)Hours\n(3)Minutes\n");
	    int op = sc.nextInt();
	    //implement the logic using switch case
		switch(op) {
		case 1:	System.out.println(n+" seconds in Days equals to: "+n/86400+" days"); break;
	
		case 2: System.out.println(n+" seconds in Hours equals to: "+n/3600+" hours"); break;
		
		case 3: System.out.println(n+" seconds in Minutes equals to: "+n/60+" minutes"); break;
		
		default: System.out.println("please select any one option  from 1 to 3\r\n"
				+ "\r\n"
				+ "");
		}
		
		//close scanner object
	    sc.close();
	}

}

