package nov21;
import java.util.Scanner;

public class VerifyTriangeTypeUsingSwitch {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter side 1: ");
		int s1 = sc.nextInt();
		
		System.out.print("Enter side 2: ");
		int s2 = sc.nextInt();
		
		System.out.print("Enter side 3: ");
		int s3 = sc.nextInt();
		
		int f;
		
//		if(s1!=s2&&s2!=s3&&s3!=s1) f=1;
//		else if(s1==s2 && s2==s3 && s3==s1) f=2;
//		else f=3;
//		
//		int f = 
//				
//		switch(f) {
//		case 1: System.out.println("The triangle is scalene."); break;
//		case 2: System.out.println("The traingle is equilateral. "); break;
//		case 3: System.out.println("The triangle is isosceles. ");
//		}
//		sc.close();
	}

}
