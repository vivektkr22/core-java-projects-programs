package nov21;
import java.util.*;
public class VowelOrConsonantUsingSwitch {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		    System.out.println("Enter a charactor ");
		    char ch = sc.next().charAt(0);
		    
			int flag,unicode=ch;
			if(ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U'||ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u') flag =1;
			else if(ch>=0&&ch<=9) flag = 2;
			else flag=0;
			
	        switch(flag){
			    case 1: {
			    	System.out.println("Charactor is vowel");
			    	System.out.println("Unicode value is: "+unicode);
			    	break;
			    }
			    case 0: {
			    	System.out.println("Charactor is consonent");
			    	System.out.println("Unicode value is: "+unicode);
			    }
			    case 2: {
			    	System.out.println("Invalid charcator");
			    	System.out.println("Unicode value is: "+unicode);
			    }
			    
			}
	        sc.close();

	}

}
