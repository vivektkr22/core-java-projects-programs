package March18;
/* Write a program to convert all the strings in a list to uppercase and print the result using the Stream API. */

import java.util.*;

public class P6 {
    public static void main(String[] args) {
        List<String> strings = Arrays.asList("hello", "world", "java", "stream", "api");

        // Using Stream API to convert all strings to uppercase
        List<String> uppercaseStrings = strings.stream()
                .map(String::toUpperCase)
                .toList();

        // Printing uppercase strings
        System.out.println("Uppercase Strings:");
        uppercaseStrings.forEach(System.out::println);
    }
}
