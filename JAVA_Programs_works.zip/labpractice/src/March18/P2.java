package March18;
/* Write a program to convert all the strings in a list to lowercase and print the result using the Stream API. */

import java.util.*;

public class P2 {
    public static void main(String[] args) {
        List<String> strings = Arrays.asList("Hello", "WORLD", "Java", "STREAM", "API");

        // Using Stream API to convert all strings to lowercase
        List<String> lowercaseStrings = strings.stream()
                .map(s -> s.toLowerCase())
                .toList();

        // Printing lowercase strings
        System.out.println("Lowercase Strings:");
        lowercaseStrings.forEach(System.out::println);
    }
}
