package March18;
/* Given a list of Employee objects with id and salary properties, write a program to filter the list of Employees by salary in who are 
having salary > 30000. */

import java.util.*;

class Employee2 {
    private int id;
    private double salary;

    public Employee2(int id, double salary) {
        this.id = id;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "Employee2{id=" + id + ", salary=" + salary + '}';
    }
}

public class P3 {
    public static void main(String[] args) {
        List<Employee2> employees = Arrays.asList(
                new Employee2(1, 50000),
                new Employee2(2, 25000),
                new Employee2(3, 60000),
                new Employee2(4, 35000),
                new Employee2(5, 45000)
        );

        // Filtering employees by salary > 30000
        List<Employee2> filteredEmployees = employees.stream()
                .filter(employee -> employee.getSalary() > 30000)
                .toList();

        // Printing filtered employees
        System.out.println("Filtered Employees (salary > 30000):");
        filteredEmployees.forEach(System.out::println);
    }
}

