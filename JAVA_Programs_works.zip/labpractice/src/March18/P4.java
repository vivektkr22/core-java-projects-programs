package March18;
// Write a program to convert all the lower case strings in a list to first letter Uppercase and print the result using the Stream API.
import java.util.*;

public class P4 {
    public static void main(String[] args) {
        List<String> strings = Arrays.asList("hello", "world", "java", "stream", "api");

        // Using Stream API to convert all lowercase strings to first letter uppercase
        List<String> convertedStrings = strings.stream()
                .map(s -> Character.toUpperCase(s.charAt(0)) + s.substring(1))
                .toList();

        // Printing converted strings
        System.out.println("Converted Strings:");
        convertedStrings.forEach(System.out::println);
    }
}

