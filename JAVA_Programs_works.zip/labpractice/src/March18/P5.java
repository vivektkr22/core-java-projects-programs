package March18;
/* Given a list of Person objects with name and age properties, write a program to sort the list of persons by age in ascending order using the 
 * Stream API.
 */
import java.util.*;

class Person {
    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    @Override
    public String toString() {
        return "Person{name='" + name + "', age=" + age + '}';
    }
}

public class P5 {
    public static void main(String[] args) {
        List<Person> persons = Arrays.asList(
                new Person("Alice", 30),
                new Person("Bob", 25),
                new Person("Charlie", 35),
                new Person("David", 20),
                new Person("Eva", 40)
        );

        // Sorting persons by age in ascending order using Stream API
        List<Person> sortedPersons = persons.stream()
                .sorted((p1, p2) -> Integer.compare(p1.getAge(), p2.getAge()))
                .toList();

        // Printing sorted persons
        System.out.println("Sorted Persons (by age in ascending order):");
        sortedPersons.forEach(System.out::println);
    }
}

