package March18;
/* Given a list of Employee objects with id and salary properties, write a program to sort the list of Employees by salary in descending order using the
Stream API. */

import java.util.*;

class Employee {
    private int id;
    private double salary;

    public Employee(int id, double salary) {
        this.id = id;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "Employee{id=" + id + ", salary=" + salary + '}';
    }
}

public class P1 {
    public static void main(String[] args) {
        List<Employee> employees = Arrays.asList(
                new Employee(1, 50000),
                new Employee(2, 60000),
                new Employee(3, 55000),
                new Employee(4, 70000),
                new Employee(5, 62000)
        );

        // Sorting employees by salary in descending order using Stream API
        List<Employee> sortedEmployees = employees.stream()
                .sorted(Comparator.comparingDouble(Employee::getSalary).reversed())
                .toList();

        // Printing sorted employees
        System.out.println("Sorted Employees (by salary in descending order):");
        sortedEmployees.forEach(System.out::println);
    }
}
