package Oops_nov28;

public class Dog {
	   // Declare the variables 
	     String name;
	     double height;
	     int age;

	    // Method to get dog information
	    public void getDogInformation() {
	      System.out.println("Dog name: "+name+", height is: "+height+"cm"+", age is: "+age+"yr");
	    }

	    // Method for the dog to bark
	    public void bark() {
	        System.out.println("dog is barking...");
	    }

	    public static void main(String[] args) {
	        // Create a Dog object
	        Dog dog1 = new Dog();
	        dog1.name ="German shefered";
	        dog1.height= 100;  //in c.m.
	        dog1.age = 5;  //in years
	        
	        // Call methods on the Dog object
	        dog1.bark();
	        dog1.getDogInformation();
	    }
	}
