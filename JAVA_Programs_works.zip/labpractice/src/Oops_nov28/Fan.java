package Oops_nov28;

public class Fan {
	   // Declare the variable 
	   String name;
	   String coil;
	   int wings;
	    // Constructor
	   

	    // Method to switch on the fan
	    public void switchOn() {
	        System.out.println("Fan is switched on and start moving");
	    }

	    // Method to switch off the fan
	    public void switchOff() {
	       System.out.println("Fan is switched off and stop moving");
	    }
	    public void getInformation(){
	        System.out.println("Brand name is: "+name+", coil is made of: "+coil+", wings are: "+wings);
	    }

	    public static void main(String[] args) {
	        // Create a Fan object
	        Fan fan1 = new Fan();
	        fan1.name="Bajaj";
	        fan1.coil ="copper";
	        fan1.wings= 3;

	        // Call methods on the Fan object
	        fan1.switchOn();
	        fan1.switchOff();
	        fan1.getInformation();
	    }
	}
