package Oops_nov28;

public class Food {
	String name;
	String taste;
	String region;
	
	public void getInformation() {
		System.out.println("Name of food is: "+name+", Taste is: "+taste+", Region of food is: "+region);
	}
	
	public void variety() {
		System.out.println("Onion dosa\nMasala dosa\nPaneer dosa\nCorn dosa\nPlain dosa\nButter dosa");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Food food1 = new Food();
        food1.name= "Dosa";
        food1.taste ="Spicy";
        food1.region="South Indian";
        
        food1.getInformation();
        food1.variety();
        
        System.out.println("-------------------------------------------");
        
        Food food2 = new Food();
        food2.name= "Jalebi";
        food2.taste ="Sweet";
        food2.region="North Indian";
        
        food2.getInformation();
      
	}

}
