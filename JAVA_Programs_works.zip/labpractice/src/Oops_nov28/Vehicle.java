package Oops_nov28;

public class Vehicle {
	String name;
    int wheels;
    int maxSpeed;
    
    public void getInformation() {
    	System.out.println("Name of vehicle: "+name+", tyres are: "+wheels+", Maximum speed: "+maxSpeed+"km/h");
    }
    

	public static void main(String[] args) {
		Vehicle vh1 = new Vehicle();
		vh1.name = "Cycle";
		vh1.wheels = 2;
		vh1.maxSpeed = 20;
		vh1.getInformation();
		
		Vehicle vh2 = new Vehicle();
		vh2.name = "Car";
		vh2.wheels = 4;
		vh2.maxSpeed = 250;
		vh2.getInformation();
		
	}

}
