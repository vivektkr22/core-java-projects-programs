package nov16;

import java.util.Scanner;

public class BuzzNumber {
	public static boolean buzzNum(int num) {
		if(num%10==7||num%7==0) return true;
		else return false;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number:");
		int num = sc.nextInt();
		
		if(buzzNum(num)) System.out.println("is a buzz");
		else System.out.println("is not a buzz");
	}

}
