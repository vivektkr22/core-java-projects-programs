/* Ques - 1
---------
write Program to create a calculator app by using switch case and call methods from switch case and 
takes operator from input 

Example : 

first num : 10 
second num : 20
operator : +

result = 10+20 = 30; */


package nov16;
import java.util.Scanner;
public class Calculator {
	public static float addition(float a,float b) {
		return a+b;
	}
	public static float substraction(float a,float b) {
		return a-b;
	}
	public static float multiplication(float a,float b) {
		return a*b;
	}
	public static float division(float a,float b) {
		return a/b;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter a first number");
		float n1 = sc.nextInt();
		
		System.out.println("Enter a second number");
		float n2 = sc.nextInt();
		
		System.out.println("Enter a operator");
		char op = sc.next().charAt(0);
		sc.close();
		
		switch(op) {
		case '+': System.out.println(addition(n1,n2)); break;
		case '-': System.out.println(substraction(n1,n2)); break;
		case '*': System.out.println(multiplication(n1,n2)); break;
		case '/': System.out.println(division(n1,n2)); break;
		}
	}

}
