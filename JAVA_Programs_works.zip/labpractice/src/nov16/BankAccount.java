/*Ques - 2
---------
Write a program to create a bank Account using createBankAccount() method and deposit money into balance varaible and withdraw money from same bankbalance and 
make sure that money are available while withdrawing create static methods of deposit and withdraw with return type void and parameter of double balance 

take one static varaible with datatype double and initialize with 30000....

Example For Taking Static Varaible in java
-------------------------------------------
*/

package nov16;
import java.util.Scanner;
public class BankAccount {
	static double initBalance = 30000d;
	
	public static void createBankAccount()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your name");
		String name = sc.nextLine();
	
		System.out.println("Enter your age");
		int age = sc.nextInt();
		
		System.out.println("Enter your gender");
		char gender = sc.next().charAt(0);
		
		System.out.println("----- ACcount Created-----");
		System.out.println(name + " , Welcome to our Bank-----");
		System.out.println("---------Our services--------");
		
		System.out.println("Enter 'w' for withdrwal and 'd' for deposite ");
		char ch = sc.next().charAt(0);
		switch(ch)
		{
		case 'w':{
			System.out.println("Enter Amount to Widthdrawal");
			int wd = sc.nextInt();
			withdrawal(wd);	
		} break;
		case 'd':{
			System.out.println("Enter amount to deposite");
			int dp = sc.nextInt();
			deposite(dp);
		}
		}
	}
	public static void deposite(double balance) {
		
		initBalance-=balance;
		System.out.println("Deposite succesfull");
		System.out.println("current balnce is: "+ initBalance);
	}
	public static void withdrawal(double balance) {
		initBalance+=balance;
		System.out.println("Deposite succesfull");
		System.out.println("current balnce is: "+ initBalance);
	}
	public static void main(String[] args) {
		createBankAccount();
	}

}






























