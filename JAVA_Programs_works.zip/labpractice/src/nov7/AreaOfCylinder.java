package nov7;

public class AreaOfCylinder {

	public static void main(String[] args) {
		int radius = Integer.parseInt(args[0]);
		int height = Integer.parseInt(args[1]);
		float pi = 3.14f;
		float areaOfCylinder = (2*pi*radius*height) + (2*pi*radius*radius);
		
		System.out.println("Area of Cylinder is: "+areaOfCylinder);
	}

}
