package nov7;

public class CheckPalindrome {
	public static boolean isPalindrome(int n) {
		int rev=0,t=n;
		while(t!=0) {
			rev=rev*10+t%10;
			t/=10;
		}
		return (rev==n);
	}
		

	public static void main(String[] args) {
		int n = Integer.parseInt(args[0]);
		
		if(isPalindrome(n))
		System.out.println("Is palindrome");
		else 
		System.out.println("Not a palindrome");

	}

}
