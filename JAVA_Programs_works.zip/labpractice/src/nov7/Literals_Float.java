package nov7;

public class Literals_Float
{
 public static void main (String args[])
 {
 float val_float=1.7732f;
 double val_double=1.7732d;
 float val_exponent=123E4f;
 System.out.println("This is a Floating Point Literal "+val_float);
 System.out.println("This is a Decimal Literal "+val_double);
 System.out.println("This is an Exponential Literal "+ val_exponent);
 }
}
