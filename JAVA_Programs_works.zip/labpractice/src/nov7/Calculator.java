package nov7;

public class Calculator {
	
	public static int addition(int a,int b) {
		return a+b;
	}
	public static int substraction(int a,int b) {
		return a-b;
	}
	public static int multiplication(int a,int b) {
		return a*b;
	}
	public static int division(int a,int b) {
		return a/b;
	}

	public static void main(String[] args) {
		int a = Integer.parseInt(args[0]);
		int b = Integer.parseInt(args[1]);
		
		System.out.println("Addition of "+a+" and "+b+" is: "+addition(a,b));
		System.out.println("Substraction of "+a+" and "+b+" is: "+substraction(a,b));
		System.out.println("Multiplication of "+a+" and "+b+" is: "+multiplication(a,b));
		System.out.println("Dvivision of "+a+" and "+b+" is: "+division(a,b));
	}

}
