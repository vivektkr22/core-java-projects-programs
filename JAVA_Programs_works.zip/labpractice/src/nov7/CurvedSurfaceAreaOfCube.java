package nov7;

public class CurvedSurfaceAreaOfCube {

	public static void main(String[] args) {
		float side = Float.parseFloat(args[0]);
		
		float areaOfCube = 6*side*side;
		
		System.out.println("Area of cube is: "+areaOfCube);
	}

}
