package nov7;

public class Sample2 {
public static void main(String[] args) {
int a=10;
float b=4.5f;
double c=5.2;
long d=378293L;
 long e=(long)-8.98;
System.out.println(a);
System.out.println(b); 
System.out.println(c); 
System.out.println(d);
System.out.println(e);
System.out.println("java");
}
}
