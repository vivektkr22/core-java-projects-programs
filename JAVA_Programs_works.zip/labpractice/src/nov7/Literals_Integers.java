package nov7;

public class Literals_Integers 
{
public static void main (String args[])
{
int decimal_int=1234;
int octal_int=077;
int hexadec_int=0x1ff2;
int binary_int=0b1010101;
System.out.println("This is a Decimal Literal: "+decimal_int);
System.out.println("This is an Octal Literal: "+octal_int);
System.out.println("This is a Hexa Decimal Literal: "+hexadec_int);
System.out.println("This is a Binary Literal: "+binary_int);
}
}
