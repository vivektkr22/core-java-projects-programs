package nov7;

public class FahrenheitToCalsius {

	public static void main(String[] args) {
       float fahrenheit,celsius;
		
		fahrenheit = Float.parseFloat(args[0]);
		
		celsius = ((fahrenheit-32)*5)/9;
		
		System.out.println(fahrenheit+" "+"in celsius is: "+celsius);
	}

}
