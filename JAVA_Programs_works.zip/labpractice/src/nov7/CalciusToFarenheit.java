package nov7;

public class CalciusToFarenheit {

		public static void main(String[] args) {
			float fahrenheit,celsius;
			
			celsius = Float.parseFloat(args[0]);
			
			fahrenheit = ((9*celsius)/5)+32;
			
			System.out.println(celsius+" "+"in celsius is: "+fahrenheit);

		}

	}

