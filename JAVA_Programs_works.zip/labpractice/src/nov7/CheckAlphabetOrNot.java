package nov7;

public class CheckAlphabetOrNot {
	
	public static boolean isAlphabet(char c) {
		if(c>='a'&&c<='z' || c>='A'&&c<='Z') return true;
		else return false;
	}

	public static void main(String[] args) {
	    char c = args[0].charAt(0);
	    
	    System.out.println(isAlphabet(c));

	}

}
