package nov7;

public class CompundInterest {

	public static void main(String[] args) {
		float principal = Float.parseFloat(args[0]);
		float rate = Float.parseFloat(args[1]);
		
		float amount = principal*((1+rate/100)+(1+rate/100)+(1+rate/100));
		
		System.out.println("Principal amount: "+amount);

	}

}
