package nov7;

public class CheckOddEven {
	
	public static String checkDigit(int n) {
		if(n%2==0) return "EVEN";
		else return "ODD";
	}

	public static void main(String[] args) {
		int n = Integer.parseInt(args[0]);
		
		System.out.println(checkDigit(n));
	

	}

}
