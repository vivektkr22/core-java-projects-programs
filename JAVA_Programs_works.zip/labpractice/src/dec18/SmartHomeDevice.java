package dec18;

public class SmartHomeDevice {
	//Declare instance variables
	private String type;
	private boolean status=false;
	
	//create parameterized constructor and initialize instance variables
    public SmartHomeDevice(String type,boolean status){
	    this.type = type;
	    this.status = status;
	}  

	//instance method turnOn
    public void turnOn(){
         System.out.println(type + " is turned on.");
    }
	
	//instance method turnOff
	public void turnOff(){
        System.out.println(type + " is turned off.");
	}	
		
	//generate setter and getter methods for instance variables
    public String getType() {
		return type;
	}

	public boolean isStatus() {
		return status;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}	
	
}