package dec18;

public class ThermostatDevice extends SmartHomeDevice {

	//create parameterized constructor and initialize super class's instance variables
	public ThermostatDevice(String type,boolean status) {
		super(type,status);
	}
	//instance method setTemperature
	public void setTemperature(int temperature) {
		 System.out.println("Thermostat temperature is set to " + temperature + "°C.");
	}

	
}