package dec18;

public class LightDevice extends SmartHomeDevice{

	//create parameterized constructor and initialize super class's instance variables
	public LightDevice(String type,boolean status) {
		super(type,status);
		
	}
	
	//instance method dim
    public void dim(int brightness) {
		  System.out.println("Light brightness is set to " + brightness + "%.");
	}
	

}