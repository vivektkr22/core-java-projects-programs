package dec18;

public class VoiceAssistantIntegration extends SmartHomeDevice {

	//create parameterized constructor and initialize super class's instance variables
	public VoiceAssistantIntegration(String type, boolean status) {
		super(type, status);
	}

	//instance method executeVoiceCommand. implement logic according to question.
    public void executeVoiceCommand(String command) {
    	if(command=="turn on") {
    		turnOn();
    	}
    	else if(command=="turn off") {
    		turnOff();
    	}
    	else if(command=="dim") {
    		System.out.println("Adjusting brightness....");
    	}
    	else if(command=="set temperature") {
    		System.out.println("Setting temperature....");
    	}
    	else {
    		System.out.println("Command not recognized");
    	}
    }

}
