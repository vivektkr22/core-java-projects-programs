package dec18;

public class MainSmart {

	public static void main(String[] args) {

		//create a new object to LightDevice class by passing parameters as 'Light',false
        LightDevice ld = new LightDevice("Light",false);
		//call turn on method
        ld.turnOn();
		//call dim method by passing some integer value
        ld.dim(50);
		
		//create a new object to ThermostatDevice class by passing parameters as 'Thermostat',false
        ThermostatDevice td = new ThermostatDevice("Thermostat",false);
		//call turn on method
        td.turnOn(); 
		//call setTemperature method by passing some integer value
		td.setTemperature(22);
		
		//call turnOff method on lightDevice and thermostatDevice objects
		ld.turnOff();
	    td.turnOff();
	}

}
