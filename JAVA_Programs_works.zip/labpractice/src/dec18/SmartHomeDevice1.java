package dec18;

public class SmartHomeDevice1 {
	//Declare instance variables
    private String type;
    private boolean status;
    
    //create parameterized constructor and initialize instance variables
	public SmartHomeDevice1(String type, boolean status) {
		super();
		this.type = type;
		this.status = status;
	}
	
	//instance method turnOn
	public void turnOn() {
		System.out.println(type+"is turned On");
	}
	
	//instance method turnOff
	public void turnOff() {
		System.out.println(type+"is turned Off");
	}

	//generate setter and getter methods for instance variables
	public String getType() {
		return type;
	}

	public boolean isStatus() {
		return status;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}
		

}