package dec18;

public class MainSmartHome1 {

	public static void main(String[] args) {
	    
	    // create new object to VoiceAssistantIntegration class by passing parameters as 'Voice Assistant' and false
		VoiceAssistantIntegration v = new VoiceAssistantIntegration("Voice Assistant",false);
        //calls executeVoiceCommand() by passing 'turn on' as string
        v.executeVoiceCommand("turn on");
		//calls executeVoiceCommand() by passing 'set temperature' as string
        v.executeVoiceCommand("set temperature");
		//calls executeVoiceCommand() by passing 'dim' as string
        v.executeVoiceCommand("dim");
		//calls executeVoiceCommand() by passing 'turn off' as string
		v.executeVoiceCommand("turn off");
		System.out.println(v.isStatus());

	}

}