package nov1;

public class circleArea{
	
	 public static void main(String[] args) {
	  float n = Float.parseFloat(args[0]);
         float a = (float)3.14*n*n;
	
           if(args.length !=1)
	       System.out.println("Usage: java CircleAreaCalculator <radius>");
	    else if(n<0)
	       System.out.println("Error: Radius must be a non-negative number");
	    else
           System.out.println("The area of circle with radius "+n+" is: "+ a);  

	    }
}

