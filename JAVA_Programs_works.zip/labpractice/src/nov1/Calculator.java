package nov1;

import java.util.*;
public class Calculator{
      public static void main(String[] args){
       Scanner sc = new Scanner(System.in);
       System.out.print("Define variable number 1 to :");
       float a = sc.nextFloat();
       System.out.print("Define variable number 2 to :");
       float b = sc.nextFloat();

       System.out.println("Addition Result is: "+(a+b));
       System.out.println("Substraction Result is: "+(a-b));
       System.out.println("Multiplication Result is: "+(a*b));
       if(b==0)
       System.out.println("Division by zero is not allowed.");
       else 	
       System.out.println("Division Result is: "+(a/b));
  
}
}