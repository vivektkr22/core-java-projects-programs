package Fab6;

import java.io.FileInputStream;
import java.io.ObjectInputStream;


public class RetrieveCustomerObject {
   public static void main(String[] args) throws Exception {
	var fin = new FileInputStream("c:\\Batch27\\customer.txt");
	var ois = new ObjectInputStream(fin);
	
	try(fin ; ois){
		Customer cust = null;
		while((cust = (Customer)ois.readObject())!=null) {
			System.out.println(cust);
		}
	}
	catch(Exception e) {
		System.err.println("End of file reached:!!!");
	}
}
}
