package Fab6;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class StoreCustomerObject {
   
	public static void main(String[] args) throws Exception {
		var fout = new FileOutputStream("c:\\Batch27\\customer.txt");
		var oos = new ObjectOutputStream(fout);
		var sc = new Scanner(System.in);
		try(fout ; oos; sc){
			System.out.print("How many customer object you want to store: ");
		    Integer numberOfObj = sc.nextInt();
		    
		    for(int i=0; i<numberOfObj; i++) {
		    	Customer obj = Customer.getCustomerObject();
		    	oos.writeObject(obj);
		    }
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		System.out.print("Customer data stored successfully");
	}
}
