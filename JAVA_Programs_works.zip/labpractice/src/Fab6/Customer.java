package Fab6;

import java.io.Serializable;
import java.util.Scanner;

public class Customer implements Serializable {
  
	private static final long serialVersionUID = 1L;
private Integer customerId;
  private String customerName;
  private Double customerBill;
  
public Customer(Integer customerId, String customerName, Double customerBill) {
	super();
	this.customerId = customerId;
	this.customerName = customerName;
	this.customerBill = customerBill;
}
  
public static Customer getCustomerObject() {
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter customer id: ");
	 Integer id = sc.nextInt();
	 System.out.print("Enter customer name: ");
	 String name = sc.nextLine();
	 name = sc.nextLine();
	 System.out.print("Enter customer Bill: ");
	 Double bill = sc.nextDouble();
	 
	 return new Customer(id,name,bill);
}

public Integer getCustomerId() {
	return customerId;
}

public String getCustomerName() {
	return customerName;
}

public Double getCustomerBill() {
	return customerBill;
}

public void setCustomerId(Integer customerId) {
	this.customerId = customerId;
}

public void setCustomerName(String customerName) {
	this.customerName = customerName;
}

public void setCustomerBill(Double customerBill) {
	this.customerBill = customerBill;
}

@Override
public String toString() {
	return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerBill=" + customerBill
			+ "]";
}

}





