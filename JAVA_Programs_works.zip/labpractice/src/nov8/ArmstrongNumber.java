package nov8;

public class ArmstrongNumber {

    public static void amstrongPrinter(int n) {
        for (int i = 0; i <= n; i++) {
            int temp = i;
            double sum = 0;
            while (temp != 0) {
                int r = temp % 10;
                sum += Math.pow(r, 3);
                temp /= 10;
            }
            if (sum == i) System.out.println(i + " ");
        }
    }

    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);

        amstrongPrinter(n);
    }
}
