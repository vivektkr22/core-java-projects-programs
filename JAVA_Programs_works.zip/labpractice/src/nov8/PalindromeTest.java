package nov8;

import java.util.*;
public class PalindromeTest {
	 public static int isPalindrome(int n){
	        if(n>=100&&n<=999){
			   int t=n,rev=0;
			   while(t!=0){
			       rev = rev*10 + t%10;
			       t/=10;
			   }
			   if(n==rev) return 1;
			   else return 0;
			}
			else if(n<=0) return -1;
			else return -2;
	    }
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.print("Enter a number: ");
			int n = sc.nextInt();
			int a = isPalindrome(n);
			if(a==-1) System.out.println("the given number is -ve kindly provide the +ve number only");
			else if(a==-2) System.out.println("this program can check the operation for the 3 number only.");
			else if(a==1) System.out.println("Palindrome");
			else System.out.println("Not a palindrome");
			
		}

}
