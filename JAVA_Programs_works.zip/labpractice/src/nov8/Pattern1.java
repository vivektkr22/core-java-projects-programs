package nov8;

public class Pattern1 {

	public static void main(String[] args) {
		
	}

}
