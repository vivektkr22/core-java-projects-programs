package nov8;
import java.util.*;
public class NextMultipleOfHundred {
    public static int nextMultiple(int n){
        if(n<=0) return -1;
        else return ((n/100)+1)*100;

    }
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int n = sc.nextInt();
		sc.close();
		System.out.println(nextMultiple(n));
		
	}
}