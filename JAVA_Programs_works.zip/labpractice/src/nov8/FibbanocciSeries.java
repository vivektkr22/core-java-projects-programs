package nov8;

public class FibbanocciSeries {
	
	public static String fibbanocciFinder(int n) {
		int a=0,b=1;
		String str = new String();
		for(int i=0; i<n; i++) {
		   str+=a+" ";
		   int t = a+b;
		   a = b;
		   b = t;
		}
		return str;
	}

	public static void main(String[] args) {
		int n = Integer.parseInt(args[0]);
		
		System.out.println(fibbanocciFinder(n));

	}

}
