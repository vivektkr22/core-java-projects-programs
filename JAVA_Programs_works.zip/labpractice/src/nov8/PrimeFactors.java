package nov8;

public class PrimeFactors {
	
	public static String primeFactors(int n) {
		if(n<=0) return "false";
		else {
			String str = new String();
			for(int i=2; i<=n/2; i++){
				if(n%i==0) {
				int f=0;
				for(int j=2; j<=i; j++) {
					if(i%j==0) f++;
				}
				if(f<2) str+=i+" ";
				}
			}
			return str;
		}
	}

	public static void main(String[] args) {
		int n = Integer.parseInt(args[0]);
		
		System.out.println(primeFactors(n));

	}

}
