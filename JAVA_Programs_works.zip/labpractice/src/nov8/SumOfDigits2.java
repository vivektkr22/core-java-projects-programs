package nov8;

public class SumOfDigits2 {

	public static void main(String[] args) 
	{
		int n = Integer.parseInt(args[0]);
		int sum=0;
		if(n<0) System.out.println(-3);
		else if(n>99) System.out.println(-2);
		else if(n>=0&&n<=9) System.out.println(-1);
		else
		{
			sum+=(n%10+n/10);
			System.out.println("Sum of the digit of "+n+" is: "+sum);
		}

	}

}
