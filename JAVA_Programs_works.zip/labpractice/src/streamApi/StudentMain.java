package streamApi;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.stream.Collectors;

class Student {
    private int id;
    private String firstName;
    private String lastName;
    private int age;
    private String gender;
    private String department;
    private int yearOfPassing;
    private String city;
    private int rank;

    public Student(int id, String firstName, String lastName, int age, String gender, String department, int yearOfPassing, String city, int rank) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.gender = gender;
        this.department = department;
        this.yearOfPassing = yearOfPassing;
        this.city = city;
        this.rank = rank;
    }
    

    public int getId() {
		return id;
	}


	public String getFirstName() {
		return firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public int getAge() {
		return age;
	}


	public String getGender() {
		return gender;
	}


	public String getDepartment() {
		return department;
	}


	public int getYearOfPassing() {
		return yearOfPassing;
	}


	public String getCity() {
		return city;
	}


	public int getRank() {
		return rank;
	}


	@Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", age=" + age +
                ", gender='" + gender + '\'' +
                ", department='" + department + '\'' +
                ", yearOfPassing=" + yearOfPassing +
                ", city='" + city + '\'' +
                ", rank=" + rank +
                '}';
    }
}

public class StudentMain {
    public static void main(String[] args) {
  
    	 List<Student> list = Arrays.asList(
                 new Student(1, "Rohit", "Mall", 30, "Male", "Mechanical Engineering", 2015, "Mumbai", 122),
                 new Student(2, "Pulkit", "Singh", 56, "Male", "Computer Engineering", 2018, "Delhi", 67),
                 new Student(3, "Ankit", "Patil", 25, "Female", "Mechanical Engineering", 2019, "Kerala", 164),
                 new Student(4, "Satish Ray", "Malaghan", 30, "Male", "Mechanical Engineering", 2014, "Kerala", 26),
                 new Student(5, "Roshan", "Mukd", 23, "Male", "Biotech Engineering", 2022, "Mumbai", 12),
                 new Student(6, "Chetan", "Star", 24, "Male", "Mechanical Engineering", 2023, "Karnataka", 90),
                 new Student(7, "Arun", "Vittal", 26, "Male", "Electronics Engineering", 2014, "Karnataka", 324),
                 new Student(8, "Nam", "Dev", 31, "Male", "Computer Engineering", 2014, "Karnataka", 433),
                 new Student(9, "Sonu", "Shankar", 27, "Female", "Computer Engineering", 2018, "Karnataka", 7),
                 new Student(10, "Shubham", "Pandey", 26, "Male", "Instrumentation Engineering", 2017, "Mumbai", 98)
         );

 //-------------------------------------------------------------------------------------------------------------------------------
        // Group The Student By Department Names
    	 Map<String, List<Student>> groupedByDepartment = list.stream()
                .collect(Collectors.groupingBy(Student::getDepartment));


        groupedByDepartment.forEach((department, studentList) -> {
            System.out.println("Department: " + department);
            studentList.forEach(System.out::println);
            System.out.println();
        });
 //----------------------------------------------------------------------------------------------------------------------------   
        // Find the total count of students using streams
           long totalCount = list.stream().count();

        // Print the total count
            System.out.println("Total count of students: " + totalCount);
            System.out.println();
 //----------------------------------------------------------------------------------------------------------------------------
//        Find the max age of student
            OptionalInt maxAge = list.stream().mapToInt(dt -> dt.getAge()).max();
            System.out.println("Max age of student : "+maxAge.getAsInt());
            System.out.println();
 //------------------------------------------------------------------------------------------------------------------------------
        //find all departsment name
            List<String> lstDepartments = list.stream().map(dt -> dt.getDepartment()).distinct()
        	    .collect(Collectors.toList());
            System.out.println("All distinct department names : "+lstDepartments);
            System.out.println();
 //-------------------------------------------------------------------------------------------------------------------------------
       // Find the count of student in each department
            Map<String, Long> countStudentInEachdept = list.stream()
        		    .collect(Collectors.groupingBy(Student::getDepartment, Collectors.counting()));
            System.out.println("Student count in each department : "+countStudentInEachdept);
            System.out.println();
//-------------------------------------------------------------------------------------------------------------------------------
       // Find the list of students whose age is less than 30
            List<Student> lstStudent = list.stream().filter(dt -> dt.getAge() < 30).collect(Collectors.toList());
            System.out.println("List of students whose age is less than 30 : "+lstStudent);
            System.out.println();
//----------------------------------------------------------------------------------------------------------------------------------
        //Find the list of students whose rank is in between 50 and 100
        List<Student> lstStu = list.stream().filter(dt -> dt.getRank() > 50 && dt.getRank() < 100)
        	    .collect(Collectors.toList());
        	System.out.println("List of students whose rank is between 50 and 100 : "+lstStu);
        	System.out.println();
//-----------------------------------------------------------------------------------------------------------------------------------
        //Find the average age of male and female students
           Map<String, Double> mapAvgAge = list.stream()
          .collect(Collectors.groupingBy(Student::getGender, Collectors.averagingInt(Student::getAge)));
           System.out.println("Average age of male and female students : "+mapAvgAge);
           System.out.println();
//-----------------------------------------------------------------------------------------------------------------------------------
        //Find the department who is having maximum number of students
           Entry<String, Long> entry = list.stream().collect(Collectors.groupingBy(Student::getDepartment, Collectors.counting())).entrySet().stream()
        	.max(Map.Entry.comparingByValue()).get();
           System.out.println("Department having maximum number of students : "+entry);
           System.out.println();
//-----------------------------------------------------------------------------------------------------------------------------------
       //  Find the Students who stays in Delhi and sort them by their names
           List<Student> lstDelhistudent = list.stream().filter(dt -> dt.getCity().equals("Delhi")).sorted(Comparator.comparing(Student::getFirstName)).collect(Collectors.toList());
           System.out.println("List of students who stays in Delhi and sort them by their names : "+lstDelhistudent);
           System.out.println();
//-----------------------------------------------------------------------------------------------------------------------------------
       //Find the average rank in all departments
           Map<String, Double> collect = list.stream().collect(Collectors.groupingBy(Student::getDepartment, Collectors.averagingInt(Student::getRank)));
           System.out.println("Average rank in all departments  : "+collect);
           System.out.println();
//----------------------------------------------------------------------------------------------------------------------------------
       //Find the highest rank in each department
           Map<String, Optional<Student>> studentData = list.stream().collect(Collectors.groupingBy(Student::getDepartment,
           Collectors.minBy(Comparator.comparing(Student::getRank))));
           System.out.println("Highest rank in each department  : "+studentData);
           System.out.println();
//-----------------------------------------------------------------------------------------------------------------------------------
       //Find the list of students and sort them by their rank
    	   List<Student> stuRankSorted = list.stream().sorted(Comparator.comparing(Student::getRank)).collect(Collectors.toList());
           System.out.println("List of students sorted by their rank  : "+stuRankSorted);
           System.out.println();
//----------------------------------------------------------------------------------------------------------------------------------
      // Find the student who has second rank
		   Student student = list.stream().sorted(Comparator.comparing(Student::getRank)).skip(1).findFirst().get();
    	   System.out.println("Second highest rank student  : "+student);
    }
}

