package Mar1;

public class Employee {
   private String employeeName;
   private String employeePosition;
   private double employeeSalary;
   
public Employee(String employeeName, String employeePosition, double employeeSalary) {
	super();
	this.employeeName = employeeName;
	this.employeePosition = employeePosition;
	this.employeeSalary = employeeSalary;
}

public String getEmployeeName() {
	return employeeName;
}

public String getEmployeePosition() {
	return employeePosition;
}

public double getEmployeeSalary() {
	return employeeSalary;
}

public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}

public void setEmployeePosition(String employeePosition) {
	this.employeePosition = employeePosition;
}

public void setEmployeeSalary(double employeeSalary) {
	this.employeeSalary = employeeSalary;
}

@Override
public String toString() {
	return "Employee [employeeName=" + employeeName + ", employeePosition=" + employeePosition + ", employeeSalary="
			+ employeeSalary + "]";
}


   
}
