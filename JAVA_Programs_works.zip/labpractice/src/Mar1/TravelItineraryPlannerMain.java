package Mar1;

public class TravelItineraryPlannerMain {

	public static void main(String[] args) {
		ItineraryPlanner ip = new ItineraryPlanner();
		
		Destination des1 = new Destination("Paris");
		des1.addActivities(new Activity("Visit Eiffel Tower","(Morning)"));
		des1.addActivities(new Activity("Louvre Museum", "(Afternoon)"));
		
		Destination des2 = new Destination("London");
		des2.addActivities(new Activity("British Museum", "(Morning)"));
		des2.addActivities(new Activity("London Eye","(Afternoon)"));

		
		ip.addDestination(des1);
		ip.addDestination(des2);
		
		ip.getDestinationList();
		
	}

}
