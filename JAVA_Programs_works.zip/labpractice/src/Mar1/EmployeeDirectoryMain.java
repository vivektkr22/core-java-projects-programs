package Mar1;

public class EmployeeDirectoryMain {

	public static void main(String[] args) {
		Directory d = new Directory();
		
		Employee e1 = new Employee("Alice", "Manager", 60000);
		d.addEmployee(e1);
	
		Employee e2 = new Employee("Bob", "Developer", 50000);
		d.addEmployee(e2);
		
		d.displayAllEmployees();
		System.out.println("-------------------------------");
		d.updateEmployee(1, "Sr. Developer", 80000);
		d.deleteEmployee(0);
		d.displayAllEmployees();
		
	}

}
