package Mar1;

import java.util.ArrayList;

public class Destination {
   private String DestinationName;
   private ArrayList<Activity> activityList = new ArrayList<>();
   
public Destination(String destinationName) {
	super();
	DestinationName = destinationName;
}

public void addActivities(Activity activity)
{
	activityList.add(activity);
}

public void getActivityList() {
	for(Activity a : activityList) {
		System.out.println(a);
	}
}

@Override
public String toString() {
	return "Destination:- " + DestinationName + "\nActivityList->" + activityList;
}
   
}
