package Mar1;

import java.util.ArrayList;

public class ItineraryPlanner {
    private ArrayList<Destination> destinationList = new ArrayList<>();
    
	public void addDestination(Destination des) {
		destinationList.add(des);
	}
	
	public void getDestinationList() {
		for(Destination d: destinationList) {
			System.out.println(d);
			System.out.println("------------------------------------------");
		}
	}
	
}
