package Mar1;

public class Activity {
    private String activityName;
    private String schedule;
    
    
	public Activity(String activityName, String schedule) {
		super();
		this.activityName = activityName;
		this.schedule = schedule;
	}
	public String getActivityName() {
		return activityName;
	}
	public String getSchedule() {
		return schedule;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}
	
	@Override
	public String toString() {
		return "\n"+ activityName + " " + schedule;
	}
    
    
}
