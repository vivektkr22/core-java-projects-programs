package Mar1;

import java.util.ArrayList;

public class Directory {
  private ArrayList<Employee> al = new ArrayList<>();
  
  
  public void addEmployee(Employee emp) {
	  al.add(emp);
  }
  
  public void displayAllEmployees() {
	  for(Employee emp : al) {
		  System.out.println(emp);
	  }
  }
  
  public void updateEmployee(int idx, String newPos, double newSal) {
     Employee empDetails = al.get(idx);
     empDetails.setEmployeePosition(newPos);
     empDetails.setEmployeeSalary(newSal);
  }
  public void deleteEmployee(int idx) {
	  al.remove(idx);
  }
}
